<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendors/autoload.php'; // Adjust the path as necessary

ob_start();
session_start();

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor' or 'head_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Include header and navbar files
include('../Staff/includes/headerlist.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if patient IC parameter is present in URL
if (isset($_GET['nurse_ic'])) {
    $nurse_ic = $_GET['nurse_ic'];
} else {
    $nurse_ic = "";
}

$message = "";
$stmt_insert = null; // Initialize $stmt_insert variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['full_name'];
    $ic_no = $_POST['ic_no'];
    $email = $_POST['email'];
    $address_home = $_POST['address_home'];
    $handphone_no = $_POST['handphone_no'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $salary = $_POST['salary'];
    $role = $_POST['role'];

    // Check if the IC number already exists in the doctor, patient, or nurse table
    $sql_check_ic = "SELECT 'doctor' AS source FROM doctor WHERE ic_no = ? UNION SELECT 'patient' FROM patient_basic_information WHERE patient_ic = ? UNION SELECT 'nurse' FROM nurse WHERE ic_no = ?";
    $stmt_check_ic = mysqli_prepare($conn, $sql_check_ic);
    if (!$stmt_check_ic) {
        die("Error in preparing statement: " . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check_ic, "sss", $ic_no, $ic_no, $ic_no);
    if (!mysqli_stmt_execute($stmt_check_ic)) {
        die("Error in executing statement: " . mysqli_error($conn));
    }
    $result_check_ic = mysqli_stmt_get_result($stmt_check_ic);

    // Debugging: Check the result of the IC number query
    if ($result_check_ic === false) {
        die("Error in fetching result: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result_check_ic) > 0) {
        $row = mysqli_fetch_assoc($result_check_ic);
        $source = $row['source'];
        // IC number already exists in doctor, patient, or nurse table
        $message = "IC number already exists in the $source table.";
    } else {
        // Check if the email already exists in the doctor, patient, or nurse table
        $sql_check_email = "SELECT 'doctor' AS source FROM doctor WHERE email = ? UNION SELECT 'patient' FROM patient_basic_information WHERE email = ? UNION SELECT 'nurse' FROM nurse WHERE email = ?";
        $stmt_check_email = mysqli_prepare($conn, $sql_check_email);
        if (!$stmt_check_email) {
            die("Error in preparing statement: " . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt_check_email, "sss", $email, $email, $email);
        if (!mysqli_stmt_execute($stmt_check_email)) {
            die("Error in executing statement: " . mysqli_error($conn));
        }
        $result_check_email = mysqli_stmt_get_result($stmt_check_email);

        // Debugging: Check the result of the email query
        if ($result_check_email === false) {
            die("Error in fetching result: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result_check_email) > 0) {
            $row = mysqli_fetch_assoc($result_check_email);
            $source = $row['source'];
            // Email already exists in doctor, patient, or nurse table
            $message = "Email already exists in the $source table.";
        } else {
            // Generate a unique dr_id
            $unique = false;
            do {
                $nurse_id = generateNurseID();
                $sql_check = "SELECT COUNT(*) FROM doctor WHERE dr_id = ?";
                $stmt_check = mysqli_prepare($conn, $sql_check);
                mysqli_stmt_bind_param($stmt_check, "i", $dr_id);
                mysqli_stmt_execute($stmt_check);
                mysqli_stmt_bind_result($stmt_check, $count);
                mysqli_stmt_fetch($stmt_check);
                mysqli_stmt_close($stmt_check);
                if ($count == 0) {
                    $unique = true;
                }
            } while (!$unique);

            // Prepare and execute the SQL query for insertion
            $sql_insert = "INSERT INTO nurse (nurse_id, full_name, ic_no, email, address_home, handphone_no, start_date, end_date, salary, role, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt_insert = mysqli_prepare($conn, $sql_insert);
            if (!$stmt_insert) {
                die("Prepare failed: " . mysqli_error($conn));
            }

            // Generate temporary password
            $temporary_password = generateTemporaryPassword();

            // Hash the temporary password for storage
            $hashed_password = password_hash($temporary_password, PASSWORD_DEFAULT);

            mysqli_stmt_bind_param($stmt_insert, "sssssssssss", $nurse_id, $name, $ic_no, $email, $address_home, $handphone_no, $start_date, $end_date, $salary, $role, $hashed_password);

            if (mysqli_stmt_execute($stmt_insert)) {
                $message = "Data stored in the database successfully.";
                $message = "Generated Nurse ID: $nurse_id";

                // Send the temporary password email
                if (sendTemporaryPasswordEmail($email, $temporary_password)) {
                    $message = "Temporary password sent to the nurse's email.";
                } else {
                    $message = "Failed to send the temporary password email.";
                }
            } else {
                echo "ERROR: Unable to execute $sql_insert. " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt_insert);
        }
    }
    mysqli_close($conn);
}

// Function to generate a 5-digit nurse ID
function generateNurseID() {
    return mt_rand(10000, 99999);
}

// Function to generate a temporary password
function generateTemporaryPassword() {
    $length = 8; // Length of the temporary password
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Function to send the temporary password email
function sendTemporaryPasswordEmail($email, $temporary_password) {
    $mail = require __DIR__ . "/Mailer.php";

    try {
        // Server settings
        $mail->setFrom('swpang1105@gmail.com', 'Mailer');           // Ensure the from email address is correct
        $mail->addAddress($email);                                  // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'Temporary Password';
        $mail->Body    = 'Your temporary password is: ' . $temporary_password;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

ob_end_flush();
?>

      

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Insert New Nurse Information</h1>
                    </div>

                    <hr>

                    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

                    <!-- Content Row -->
                    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4>Information Nurse</h4>
                    </div>
                    <form action="" method="post">
                        <div class="card-body">
                        
                            <div class="form-group row mb-3">
                                <label for="full_name" class="col-sm-3 col-form-label">Nurse's Name</label>
                                <div class="col-sm-6">
                                    <input name="full_name" type="text" id="full_name" class="form-control" placeholder="Please enter nurse's full name" required>
                                    <input type="hidden" name="dr_id" value="<?php echo $_SESSION['dr_id']; ?>">
<input type="hidden" name="nurse_id" value="<?php echo $_SESSION['nurse_id']; ?>">
                                </div>
                            </div>
                        
                                    

                            <div class="form-group row mb-3">
                                <label for="ic_no" class="col-sm-3 col-form-label">Identification number</label>
                                <div class="col-sm-6">
                                    <input name="ic_no" type="text" id="ic_no" class="form-control" value="<?php echo $nurse_ic; ?>" required>
                                </div>
                            </div>
    <div class="form-group row mb-3">
		<label for="email" class="col-sm-3 col-form-label">Email</label>
        <div class="col-sm-6">
		<input name="email" type ="text" id="email" class="form-control" placeholder="Please enter nurse's email" required>
	</div>
</div>
    <div class="form-group row mb-3">
		<label for="address_home" class="col-sm-3 col-form-label">Home Address</label>
        <div class="col-sm-6">
		<input name="address_home" type ="text" id="address_home" class="form-control" placeholder="Please enter nurse's home address" required>
	</div>
</div>
    <div class="form-group row mb-3">
		<label for="handphone_no" class="col-sm-3 col-form-label">Handphone Number</label>
        <div class="col-sm-6">
		<input name="handphone_no" type ="text" id="handphone_no" class="form-control" placeholder="Please enter nursr's handphone number" required>
	</div>
</div>
    <div class="form-group row mb-3">
		<label for="start_date" class="col-sm-3 col-form-label">Start Working Date</label>
        <div class="col-sm-6">
		<input name="start_date" type ="date" id="start_date" class="form-control" placeholder="Please enter starting work date" required>
	</div>
</div>
    <div class="form-group row mb-3">
		<label for="end_date" class="col-sm-3 col-form-label">End Working Date</label>
        <div class="col-sm-6">
		<input name="end_date" type ="date" id="end_date" class="form-control" placeholder="Please enter ending work date" required>
	</div>
</div>
    <div class="form-group row mb-3">
		<label for="salary" class="col-sm-3 col-form-label">Salary</label>
        <div class="col-sm-6">
		<input name="salary" type ="number" id="salary" class="form-control" placeholder="Please enter nurse's salary" required>
	</div>
</div>
<div class="form-group row mb-3">
    <label for="role" class="col-sm-3 col-form-label">Role</label>
    <div class="col-sm-6">
        <select class="form-control" id="role" name="role">
            <option value="head_nurse">Head Nurse</option>
            <option value="general_nurse">General Nurse</option>
        </select>
    </div>
</div>

<div class="form-group row mb-3">
<div class="col-sm-12">
		<button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit"> Submit </button>
</div>
</div>
                           
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
            <!-- End of Main Content -->

            <?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scriptslist.php');
    ?>
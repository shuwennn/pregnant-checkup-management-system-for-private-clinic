<?php
// Initialize session
session_start();

// Include configuration file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'head_nurse'
if ($_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Assuming the doctor IC is submitted via a form POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ic_no'])) {
    $ic_no = $_POST['ic_no'];
    
    // Redirect to DoctorInformation.php with ic_no parameter
    header("Location: /FYP/Staff/DoctorInformation.php?ic_no=$ic_no");
    exit();
}

// Include header and navbar files
include('../Staff/includes/headerlist.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Doctor Section</h1>                   
    
    <!-- Insert Doctor Form -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Insert New Doctor</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="patient_ic">Doctor IC</label>
                    <input type="text" class="form-control" id="patient_ic" name="ic_no" required>
                </div>
                <button type="submit" class="btn btn-primary">Insert</button>
            </form>
            <?php if ($message != ""): ?>
                <div class="alert alert-info mt-2">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Doctor List</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Doctor Name</th>
                            <th>Doctor Identification Number</th>
                            <th>Doctor ID</th>
                            <th>Action</th>                              
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch all doctors from the database
                        $con = mysqli_connect("localhost", "root", "", "pregnant_system");
                        if (!$con) {
                            die("Connection failed: " . mysqli_connect_error());
                        }

                        $query = "SELECT * FROM doctor";
                        $query_run = mysqli_query($con, $query);

                        if (mysqli_num_rows($query_run) > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                                echo "<tr>";
                                echo "<td>" . $row['full_name'] . "</td>";
                                echo "<td>" . $row['ic_no'] . "</td>";
                                echo "<td>" . $row['dr_id'] . "</td>";
                                echo "<td>";
                                echo "<a href='../Staff/ViewDoctor.php?ic_no=" . $row['ic_no'] . "' class='btn btn-primary btn-sm mr-1'>View</a>";
                                echo "<a href='../Staff/UpdateDoctor.php?ic_no=" . $row['ic_no'] . "' class='btn btn-info btn-sm mr-1'>Update</a>";
                                echo "<a href='../Staff/DeleteDoctor.php?ic_no=" . $row['ic_no'] . "' class='btn btn-danger btn-sm'>Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            $message = "<tr><td colspan='4'>No records found</td></tr>";
                        }

                        mysqli_close($con);
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include('../Staff/includes/footer.php');
include('../Staff/includes/scriptslist.php');
?>

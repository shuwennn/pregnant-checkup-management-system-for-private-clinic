<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Fetch nurse IC from query parameter
if (isset($_GET['nurse_ic'])) {
    $nurse_ic = $_GET['nurse_ic'];

    $sql_select_nurse = "SELECT * FROM nurse WHERE ic_no = ?";
    $stmt_select_nurse = mysqli_prepare($conn, $sql_select_nurse);
    if (!$stmt_select_nurse) {
        die("Prepare failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt_select_nurse, "s", $nurse_ic);
    mysqli_stmt_execute($stmt_select_nurse);

    $result_nurse = mysqli_stmt_get_result($stmt_select_nurse);

    if ($row_nurse = mysqli_fetch_assoc($result_nurse)) {
        // Fetch nurse information
        $nurse_id = $row_nurse['nurse_id']; // Assuming nurse_id is retrieved from the database
        $full_name = $row_nurse['full_name'];
        $email = $row_nurse['email'];
        $handphone_no = $row_nurse['handphone_no'];
        $address_home = $row_nurse['address_home'];
        $start_date = $row_nurse['start_date'];
        $end_date = $row_nurse['end_date'];
        $salary = $row_nurse['salary'];
        $ic_no = $row_nurse['ic_no'];
        $role = $row_nurse['role'];
        
        // Set nurse_ic in session
        $_SESSION['nurse_ic'] = $nurse_ic;
    } else {
        $message = "No nurse found with the given IC.";
    }

    mysqli_stmt_close($stmt_select_nurse);
} else {
    $message = "Nurse IC is not set in the URL.";
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Nurse Details Information</h1>

    <?php if ($message != ""): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php else: ?>
        <!-- Nurse Information -->
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Nurse Information</h6>
                    </div>
                    <div class="card-body">
                    <div class="profile-picture">
                            <!-- Replace this with your profile picture implementation -->
                            <img src="../img/female_profile.jpg" alt="Profile Picture" style="max-width: 30%; height: 30%; display: block; border-radius: 50%;">
                        </div>
                        <table class="table table-bordered" width="100%" cellspacing="0">
                        <tr>
                                <th>Nurse ID</th>
                                <td><?php echo $nurse_id; ?></td>
                            </tr>    
                        <tr>
                                <th>Full Name</th>
                                <td><?php echo $full_name; ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo $email; ?></td>
                            </tr>
                            <tr>
                                <th>Handphone Number</th>
                                <td><?php echo $handphone_no; ?></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><?php echo $address_home; ?></td>
                            </tr>
                            <tr>
                                <th>Start Date</th>
                                <td><?php echo $start_date; ?></td>
                            </tr>
                            <tr>
                                <th>End Date</th>
                                <td><?php echo $end_date; ?></td>
                            </tr>
                            <tr>
                                <th>Salary</th>
                                <td><?php echo $salary; ?></td>
                            </tr>
                            <tr>
                                <th>IC Number</th>
                                <td><?php echo $ic_no; ?></td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td><?php echo $role; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>
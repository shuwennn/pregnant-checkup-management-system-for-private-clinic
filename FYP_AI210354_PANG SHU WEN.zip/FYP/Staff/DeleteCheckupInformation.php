<?php
session_start();

// Include the database connection file
require_once("../Config.php");

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Initialize patient_ic
$patient_ic = '';

// Check if the patient_ic parameter is set in the URL
if (isset($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];

    // Fetch checkup records for the specified patient
    $result = mysqli_query($mysqli, "SELECT * FROM checkup_information WHERE patient_ic = '$patient_ic'");

    if (!$result) {
        echo "Error fetching records: " . mysqli_error($mysqli);
        exit;
    }
} else {
    echo "Patient IC not specified.";
    exit;
}

// Check if the delete button is clicked and confirmation is received
if(isset($_POST['delete_confirm']) && $_POST['delete_confirm'] == 'Yes') {
    // Get date parameter value from URL
    $date = $_GET['date'];

    // Delete specific record from checkup_information table
    $delete_result = mysqli_query($mysqli, "DELETE FROM checkup_information WHERE patient_ic = '$patient_ic' AND date = '$date'");

    if ($delete_result) {
        // Redirect to the main display page (HomePageStaff.php in this case)
        header("Location: /FYP/Staff/CheckupList.php");
    } else {
        // Display error message if deletion fails
        echo "Error deleting record: " . mysqli_error($mysqli);
    }

    // Close the database connection
    mysqli_close($mysqli);
    exit; // Exit to prevent further execution
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

?>
        
                <!-- Begin Page Content -->
                <div class="container-fluid">

                   <!-- Page Heading -->
                   <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">DELETE CHECKUP INFORMATION</h1>                     
                    </div>

                    <hr>

                    <!-- Content Row -->
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header text-black-400">
                                <h4>Checkup Records for Patient IC: <?php echo $patient_ic; ?></h4>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $row['date'] . "</td>";
                                            echo "<td><a href='/FYP/Staff/Delete.php?patient_ic=" . $patient_ic . "&date=" . $row['date'] . "' class='btn btn-danger'>Delete</a></td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End of Main Content -->


            <?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>
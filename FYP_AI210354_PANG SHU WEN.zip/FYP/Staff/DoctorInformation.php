<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendors/autoload.php';
session_start();

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'head_nurse'
if ($_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check if patient IC parameter is present in URL
if (isset($_GET['ic_no'])) {
    $ic_no = $_GET['ic_no'];
} else {
    $ic_no = "";
}

$message = ""; // Initialize an empty variable to hold the message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if form fields are empty
    if (empty($_POST['full_name']) || empty($_POST['ic_no']) || empty($_POST['email']) || empty($_POST['address_home']) || empty($_POST['handphone_no'])) {
        $message = "Please fill in all the fields.";
    } else {
        // Get form data
        $full_name = $_POST['full_name'];
        $ic_no = $_POST['ic_no'];
        $email = $_POST['email'];
        $address_home = $_POST['address_home'];
        $handphone_no = $_POST['handphone_no'];

        // Check if the IC number already exists in the doctor, patient, or nurse table
        $sql_check_ic = "SELECT 'doctor' AS source FROM doctor WHERE ic_no = ? UNION SELECT 'patient' FROM patient_basic_information WHERE patient_ic = ? UNION SELECT 'nurse' FROM nurse WHERE ic_no = ?";
        $stmt_check_ic = mysqli_prepare($conn, $sql_check_ic);
        if (!$stmt_check_ic) {
            die("Error in preparing statement: " . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt_check_ic, "sss", $ic_no, $ic_no, $ic_no);
        if (!mysqli_stmt_execute($stmt_check_ic)) {
            die("Error in executing statement: " . mysqli_error($conn));
        }
        $result_check_ic = mysqli_stmt_get_result($stmt_check_ic);

        // Debugging: Check the result of the IC number query
        if ($result_check_ic === false) {
            die("Error in fetching result: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result_check_ic) > 0) {
            $row = mysqli_fetch_assoc($result_check_ic);
            $source = $row['source'];
            // IC number already exists in doctor, patient, or nurse table
            $message = "IC number already exists in the $source table.";
        } else {
            // Check if the email already exists in the doctor, patient, or nurse table
            $sql_check_email = "SELECT 'doctor' AS source FROM doctor WHERE email = ? UNION SELECT 'patient' FROM patient_basic_information WHERE email = ? UNION SELECT 'nurse' FROM nurse WHERE email = ?";
            $stmt_check_email = mysqli_prepare($conn, $sql_check_email);
            if (!$stmt_check_email) {
                die("Error in preparing statement: " . mysqli_error($conn));
            }
            mysqli_stmt_bind_param($stmt_check_email, "sss", $email, $email, $email);
            if (!mysqli_stmt_execute($stmt_check_email)) {
                die("Error in executing statement: " . mysqli_error($conn));
            }
            $result_check_email = mysqli_stmt_get_result($stmt_check_email);

            // Debugging: Check the result of the email query
            if ($result_check_email === false) {
                die("Error in fetching result: " . mysqli_error($conn));
            }

            if (mysqli_num_rows($result_check_email) > 0) {
                $row = mysqli_fetch_assoc($result_check_email);
                $source = $row['source'];
                // Email already exists in doctor, patient, or nurse table
                $message = "Email already exists in the $source table.";
            } else {
                // Generate a unique dr_id
                $unique = false;
                do {
                    $dr_id = generateDoctorID();
                    $sql_check = "SELECT COUNT(*) FROM doctor WHERE dr_id = ?";
                    $stmt_check = mysqli_prepare($conn, $sql_check);
                    mysqli_stmt_bind_param($stmt_check, "i", $dr_id);
                    mysqli_stmt_execute($stmt_check);
                    mysqli_stmt_bind_result($stmt_check, $count);
                    mysqli_stmt_fetch($stmt_check);
                    mysqli_stmt_close($stmt_check);
                    if ($count == 0) {
                        $unique = true;
                    }
                } while (!$unique);

                // Prepare and execute the SQL query for insertion
                $role = "doctor"; // Assuming "Doctor" is the predefined role for new doctors
                $sql_insert = "INSERT INTO doctor (dr_id, full_name, ic_no, email, address_home, handphone_no, role, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt_insert = mysqli_prepare($conn, $sql_insert);
                if (!$stmt_insert) {
                    die("Prepare failed: " . mysqli_error($conn));
                }

                // Generate temporary password
                $temporary_password = generateTemporaryPassword();

                // Hash the temporary password for storage
                $hashed_password = password_hash($temporary_password, PASSWORD_DEFAULT);

                mysqli_stmt_bind_param($stmt_insert, "isssssss", $dr_id, $full_name, $ic_no, $email, $address_home, $handphone_no, $role, $hashed_password);

                if (mysqli_stmt_execute($stmt_insert)) {
                    $message = "New doctor added successfully.";
                    
                    // Send temporary password email
                    require '../Staff/Mailer.php'; // Adjust path to Mailer.php
                    if (sendTemporaryPasswordEmail($email, $temporary_password)) {
                        $message .= " Temporary password sent to the doctor's email.";
                    } else {
                        $message .= " Failed to send the temporary password email.";
                    }

                } else {
                    $message = "ERROR: Unable to execute $sql_insert. " . mysqli_error($conn);
                }
                mysqli_stmt_close($stmt_insert);
            }
        }
    }
    mysqli_close($conn);
}

// Function to generate a 5-digit doctor ID
function generateDoctorID() {
    return mt_rand(10000, 99999);
}

// Function to generate a temporary password
function generateTemporaryPassword() {
    $length = 8; // Length of the temporary password
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Function to send the temporary password email
function sendTemporaryPasswordEmail($email, $temporary_password) {
    $mail = require __DIR__ . "/Mailer.php";

    try {
        // Server settings
        $mail->setFrom('swpang1105@gmail.com', 'Mailer');           // Ensure the from email address is correct
        $mail->addAddress($email);                                  // Add a recipient

        // Content
        $mail->isHTML(true);                                        // Set email format to HTML
        $mail->Subject = 'Temporary Password';
        $mail->Body    = 'Your temporary password is: ' . $temporary_password;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading --> 
            <h1 class="h3 mb-0 text-gray-800">Insert New Doctor Information</h1>    
        <hr>

        <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

        <!-- Content Row -->
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Doctor Information</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="form-group row">
                                <label for="full_name" class="col-sm-3 col-form-label">Doctor's Name</label>
                                <div class="col-sm-9">
                                    <input name="full_name" type="text" id="full_name" class="form-control" placeholder="Please enter doctor's full name" required>
                                    <input type="hidden" name="dr_id" value="<?php echo $_SESSION['dr_id']; ?>">
                                    <input type="hidden" name="nurse_id" value="<?php echo $_SESSION['nurse_id']; ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="ic_no" class="col-sm-3 col-form-label">Doctor Identification Number</label>
                                <div class="col-sm-9">
                                    <input name="ic_no" type="text" id="ic_no" class="form-control" value="<?php echo $ic_no; ?>" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" class="col-sm-3 col-form-label">Email</label>
                                <div class="col-sm-9">
                                    <input name="email" type="email" id="email" class="form-control" placeholder="Please enter doctor's email" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="address_home" class="col-sm-3 col-form-label">Home Address</label>
                                <div class="col-sm-9">
                                    <input name="address_home" type="text" id="address_home" class="form-control" placeholder="Please enter doctor's home address" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="handphone_no" class="col-sm-3 col-form-label">Handphone Number</label>
                                <div class="col-sm-9">
                                    <input name="handphone_no" type="text" id="handphone_no" class="form-control" placeholder="Please enter doctor's handphone number" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 text-center">
                                    <button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">Insert</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Main Content -->

    </div>




<?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>  
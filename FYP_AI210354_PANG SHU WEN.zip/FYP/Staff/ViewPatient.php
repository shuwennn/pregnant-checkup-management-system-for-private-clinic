<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];

    // Initialize variables
$name = '';
$email = '';
$citizen = '';
$race = '';
$level_education = '';
$job = '';
$address = '';
$handphone_no = '';
$lnmp = '';
$edp = '';
$re_edd = '';
$gr = '';
$p = '';
$born_date = '';
$age = '';
$risk_factors = '';

    $sql_select_basic = "SELECT * FROM patient_basic_information WHERE patient_ic = ?";
    $stmt_select_basic = mysqli_prepare($conn, $sql_select_basic);
    if (!$stmt_select_basic) {
        die("Prepare failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt_select_basic, "s", $patient_ic);
    mysqli_stmt_execute($stmt_select_basic);

    $result_basic = mysqli_stmt_get_result($stmt_select_basic);

    if ($row_basic = mysqli_fetch_assoc($result_basic)) {
        // Fetch patient information
        $patient_ic = $row_basic['patient_ic'];
        $name = $row_basic['name'];
        $email = $row_basic['email'];
        $citizen = $row_basic['citizen'];
        $race = $row_basic['race'];
        $level_education = $row_basic['level_education'];
        $job = $row_basic['job'];
        $address = $row_basic['address'];
        $handphone_no = $row_basic['handphone_no'];
        $lnmp = $row_basic['lnmp'];
        $edp = $row_basic['edp'];
        $re_edd = $row_basic['re_edd'];
        $gr = $row_basic['gr'];
        $p = $row_basic['p'];
        $born_date = $row_basic['born_date'];
        $age = $row_basic['age'];
        $risk_factors = $row_basic['risk_factors'];

        // Close statement
        mysqli_stmt_close($stmt_select_basic);

        // Initialize variables
$husband_ic = '';
$husband_name = '';
$husband_job = '';
$husband_address = '';
$husband_handphone= '';

        // Fetch patient husband information
        $sql_select_husband = "SELECT * FROM patient_husband_information WHERE patient_ic = ?";
        $stmt_select_husband = mysqli_prepare($conn, $sql_select_husband);
        if (!$stmt_select_husband) {
            die("Prepare failed: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt_select_husband, "s", $patient_ic);
        mysqli_stmt_execute($stmt_select_husband);

        $result_husband = mysqli_stmt_get_result($stmt_select_husband);

        if ($row_husband = mysqli_fetch_assoc($result_husband)) {
            // Fetch husband information
            $husband_ic = $row_husband['husband_ic'];
            $husband_name = $row_husband['husband_name'];
            $husband_job = $row_husband['husband_job'];
            $husband_address = $row_husband['husband_address'];
            $husband_handphone = $row_husband['husband_handphone'];

            // Close statement
            mysqli_stmt_close($stmt_select_husband);

            // Initialize variables
$test_id = '';
$date = '';
$height = '';
$blood_group = '';
$vdrl = '';
$hb = '';
$hbs_ag = '';
$hb_antibody = '';
$rubella_antibody = '';
$hiv_1 = '';
$hiv_2 = '';
$att = '';
$others = '';

            // Fetch antenatal screening test information
            $sql_select_test = "SELECT * FROM antenatal_screening_test WHERE patient_ic = ?";
            $stmt_select_test = mysqli_prepare($conn, $sql_select_test);
            if (!$stmt_select_test) {
                die("Prepare failed: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt_select_test, "s", $patient_ic);
            mysqli_stmt_execute($stmt_select_test);

            $result_test = mysqli_stmt_get_result($stmt_select_test);

            if ($row_test = mysqli_fetch_assoc($result_test)) {
                // Fetch test information
                $test_id = $row_test['test_id'];
                $date = $row_test['date'];
                $height = $row_test['height'];
                $blood_group = $row_test['blood_group'];
                $vdrl = $row_test['vdrl'];
                $hb = $row_test['hb'];
                $hbs_ag = $row_test['hbs_ag'];
                $hb_antibody = $row_test['hb_antibody'];
                $rubella_antibody = $row_test['rubella_antibody'];
                $hiv_1 = $row_test['hiv_1'];
                $hiv_2 = $row_test['hiv_2'];
                $att = $row_test['att'];
                $others = $row_test['others'];

                // Close statement
                mysqli_stmt_close($stmt_select_test);
            } else {
                echo "No patient found with the given IC.";
                exit();
            }
        } else {
            echo "Invalid request.";
            exit();
        }
    } else {
        echo "Invalid request.";
        exit();
    }
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

mysqli_close($conn);
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Patient Information</h1>

    <?php if ($message != ""): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php else: ?>
         <!-- Display Main Patient Information -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Patient Basic Details</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="profile-picture">
                            <!-- Replace this with your profile picture implementation -->
                            <img src="../img/female_profile.jpg" alt="Profile Picture" style="max-width: 50%; height: 50%; display: block; border-radius: 50%;">
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <table class="table table-bordered vertical-header-table" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Patient IC</th>
                                    <td><?php echo $patient_ic; ?></td>
                                </tr>
                                <tr>
                                    <th>Patient Name</th>
                                    <td><?php echo $name; ?></td>
                                </tr>
                                <tr>
                                    <th>Home Address</th>
                                    <td><?php echo $address; ?></td>
                                </tr>
                                <tr>
                                    <th>Contact Number</th>
                                    <td><?php echo $handphone_no; ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo $email; ?></td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Display Additional Information in Two Columns -->
        <div class="row">
            <!-- First Column -->
            <div class="col-lg-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Additional Patient Information</h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <tr>
                                <th>Citizen</th>
                                <td><?php echo $citizen; ?></td>
                            </tr>
                            <tr>
                                <th>Race</th>
                                <td><?php echo $race; ?></td>
                            </tr>
                            <tr>
                                <th>Level of Education</th>
                                <td><?php echo $level_education; ?></td>
                            </tr>
                            <tr>
                                <th>Job</th>
                                <td><?php echo $job; ?></td>
                            </tr>
                            <tr>
                                <th>Date of Birth</th>
                                <td><?php echo $born_date; ?></td>
                            </tr>
                            <tr>
                                <th>Age</th>
                                <td><?php echo $age; ?></td>
                            </tr>
                            <tr>
                                <th>Last Normal Menstrual Period (LNMP)</th>
                                <td><?php echo $lnmp; ?></td>
                            </tr>
                            <tr>
                                <th>Estimated Date Delivery (EDP)</th>
                                <td><?php echo $edp; ?></td>
                            </tr>
                            <tr>
                                <th>Revised Expected Date Delivery (RE EDD)</th>
                                <td><?php echo $re_edd; ?></td>
                            </tr>
                            <tr>
                                <th>Gravida</th>
                                <td><?php echo $gr; ?></td>
                            </tr>
                            <tr>
                                <th>Para</th>
                                <td><?php echo $p; ?></td>
                            </tr>
                            <tr>
                                <th>Risk Factors</th>
                                <td><?php echo $risk_factors; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Second Column -->
            <div class="col-lg-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Patient Husband Information</h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <tr>
                                <th>Husband IC</th>
                                <td><?php echo $husband_ic; ?></td>
                            </tr>
                            <tr>
                            <th>Husband Name</th>
                                <td><?php echo $husband_name; ?></td>
                            </tr>
                            <tr>
                                <th>Husband Job</th>
                                <td><?php echo $husband_job; ?></td>
                            </tr>
                            <tr>
                                <th>Husband Address</th>
                                <td><?php echo $husband_address; ?></td>
                            </tr>
                            <tr>
                                <th>Husband Contact Number</th>
                                <td><?php echo $husband_handphone; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

           <!-- Display Antenatal Screening Test Information -->
           <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Antenatal Screening Test Information</h6>
            </div>
            <div class="card-body">
               <!-- First Table -->
        <table class="table table-bordered" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Test ID</th>
                    <th>Date</th>
                    <th>Height</th>
                    <th>Blood Group</th>
                    <th>Venereal Disease Research Laboratory (VDRL)</th>
                    <th>Hemoglobin (g/dL)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $test_id; ?></td>
                    <td><?php echo $date; ?></td>
                    <td><?php echo $height; ?></td>
                    <td><?php echo $blood_group; ?></td>
                    <td><?php echo $vdrl; ?></td>
                    <td><?php echo $hb; ?></td>
                </tr>
            </tbody>
        </table>

        <!-- Second Table -->
        <table class="table table-bordered" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Hepatitis B Surface Antigen</th>
                    <th>Hepatitis B Surface Antibody</th>
                    <th>Rubella Antibody</th>
                    <th>Human Immunodeficiency Virus 1</th>
                    <th>Human Immunodeficiency Virus 2</th>
                    <th>Anti Tetanus Toxoid</th>
                    <th>Others</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $hbs_ag; ?></td>
                    <td><?php echo $hb_antibody; ?></td>
                    <td><?php echo $rubella_antibody; ?></td>
                    <td><?php echo $hiv_1; ?></td>
                    <td><?php echo $hiv_2; ?></td>
                    <td><?php echo $att; ?></td>
                    <td><?php echo $others; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
    <?php endif; ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>
<?php
session_start();
// Start output buffering
ob_start();

// Include the database connection file
require_once("../Config.php");


// Initialize patient_ic and date
$patient_ic = '';
$date = '';

// Check if the patient_ic and date parameters are set in the URL
if (isset($_GET['patient_ic']) && isset($_GET['date'])) {
    $patient_ic = $_GET['patient_ic'];
    $date = $_GET['date'];
} else {
    echo "Patient IC or Date not specified.";
    exit;
}

// Check if the delete button is clicked and confirmation is received
if(isset($_POST['delete_confirm']) && $_POST['delete_confirm'] == 'Yes') {
    // Delete specific record from checkup_information table
    $delete_result = mysqli_query($mysqli, "DELETE FROM checkup_information WHERE patient_ic = '$patient_ic' AND date = '$date'");

    if ($delete_result) {
        // Redirect to the main display page (HomePageStaff.php in this case)
        header("Location: /FYP/Staff/HomePage.php");
        exit; // Exit to prevent further execution
    } else {
        // Display error message if deletion fails
        echo "Error deleting record: " . mysqli_error($mysqli);
    }

    // Close the database connection
    mysqli_close($mysqli);
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

// End output buffering and flush the output
ob_end_flush();
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">DELETE CHECKUP INFORMATION DATE</h1>                     
</div>

<hr>

<!-- Content Row -->  
<div class="row justify-content-center"  >     
 <div class="card shadow mb-4">
            <div class="card-header py-3 ju">
                <h4 class="m-0 font-weight-bold text-primary">Are You Sure Want To Delete?</h4>
            </div>
            <div class="card-body">
            <form method="post" class="text-center my-3">
<input type="submit" name="delete_confirm" class="btn btn-danger btn-lg mx-2" value="Yes">
<a href="/FYP/Staff/CheckupList.php" class="btn btn-secondary btn-lg mx-2">No</a>
</form>
            </div>
        </div>
        </div>

<!-- End of Main Content -->


            <?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>

<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'head_nurse'
if ($_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";
$dr_id = ""; // Initialize doctor ID variable

// Fetch doctor details based on doctor IC
if (isset($_GET['ic_no'])) { // Change here
    $doctor_ic = $_GET['ic_no']; // Change here
    $sql_fetch = "SELECT * FROM doctor WHERE ic_no = ?";
    $stmt_fetch = mysqli_prepare($conn, $sql_fetch);
    mysqli_stmt_bind_param($stmt_fetch, "s", $doctor_ic);
    mysqli_stmt_execute($stmt_fetch);
    $result_fetch = mysqli_stmt_get_result($stmt_fetch);
    $doctor = mysqli_fetch_assoc($result_fetch);
    mysqli_stmt_close($stmt_fetch);

    if (!$doctor) {
        echo "No doctor found with IC: $doctor_ic";
        exit();
    }
    // Set dr_id based on the fetched doctor record
    $dr_id = $doctor['dr_id'];
} else {
    echo "No doctor IC provided.";
    exit();
}

// Update doctor details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['full_name'];
    $ic_no = $_POST['ic_no'];
    $email = $_POST['email'];
    $address_home = $_POST['address_home'];
    $handphone_no = $_POST['handphone_no'];

    // Check if the IC number already exists in the nurse or patient table, excluding the current doctor
    $sql_check_ic = "SELECT ic_no FROM nurse WHERE ic_no = ? UNION SELECT patient_ic FROM patient_basic_information WHERE patient_ic = ?";
    $stmt_check_ic = mysqli_prepare($conn, $sql_check_ic);
    mysqli_stmt_bind_param($stmt_check_ic, "ss", $ic_no, $ic_no);
    mysqli_stmt_execute($stmt_check_ic);
    $result_check_ic = mysqli_stmt_get_result($stmt_check_ic);

    if (mysqli_num_rows($result_check_ic) > 0 && $ic_no != $doctor['ic_no']) {
        // IC number already exists in nurse or patient table
        $message = "IC number already exists in the database.";
    } else {
        // Prepare and execute the SQL query for update
        $sql_update = "UPDATE doctor SET full_name = ?, ic_no = ?, email = ?, address_home = ?, handphone_no = ? WHERE dr_id = ?";
        $stmt_update = mysqli_prepare($conn, $sql_update);
        if (!$stmt_update) {
            die("Prepare failed: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt_update, "ssssss", $name, $ic_no, $email, $address_home, $handphone_no, $dr_id);

        if (mysqli_stmt_execute($stmt_update)) {
            $message = "Data updated in the database successfully.";
        } else {
            echo "ERROR: Unable to execute $sql_update. " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt_update);
    }
    mysqli_close($conn);
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Update Doctor Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Update Doctor Information Form -->
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Doctor Details Information</h6>
                </div>
                <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?ic_no=' . urlencode($doctor_ic); ?>" method="post">

                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($doctor['full_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="ic_no">IC Number</label>
                            <input type="text" class="form-control" id="ic_no" name="ic_no" value="<?php echo htmlspecialchars($doctor['ic_no']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($doctor['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="address_home">Address</label>
                            <input type="text" class="form-control" id="address_home" name="address_home" value="<?php echo htmlspecialchars($doctor['address_home']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="handphone_no">Handphone Number</label>
                            <input type="text" class="form-control" id="handphone_no" name="handphone_no" value="<?php echo htmlspecialchars($doctor['handphone_no']); ?>">
                        </div>
                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary" name="update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
?>

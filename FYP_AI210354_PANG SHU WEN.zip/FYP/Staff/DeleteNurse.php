<?php
session_start();
// Start output buffering
ob_start();

// Include the database connection file
require_once("../Config.php");

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor' or 'head_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Initialize alert message variable
$alertMessage = "";

// Check if the delete button is clicked and confirmation is received
if (isset($_POST['delete_confirm']) && $_POST['delete_confirm'] == 'Yes') {
    // Get nurse_ic parameter value from URL
    if (isset($_GET['nurse_ic'])) {
        $ic_no = $_GET['nurse_ic']; // Corrected to use nurse_ic
        
        // Proceed with deleting the record from the nurse table
        $result = mysqli_query($mysqli, "DELETE FROM nurse WHERE ic_no = '$ic_no'");
        if ($result) {
            $alertMessage = "Nurse deleted successfully!";
            // JavaScript for alert and redirection
            echo "<script>
                    alert('$alertMessage');
                    window.location.href='/FYP/Staff/NurseList.php';
                  </script>";
            exit; // Exit to prevent further execution
        } else {
            // Display error message if deletion fails
            $alertMessage = "Error deleting record: " . mysqli_error($mysqli);
            echo "<script>
                    alert('$alertMessage');
                    window.history.back();
                  </script>";
        }
    } else {
        $alertMessage = "Nurse IC is not set in the URL.";
        echo "<script>
                alert('$alertMessage');
                window.history.back();
              </script>";
    }

    // Close the database connection
    mysqli_close($mysqli);
}

// Include header and navbar files
include('../Staff/includes/header.php');
include('../Staff/includes/navbar.php');
include('../Staff/includes/topbar.php');

// End output buffering and flush the output
ob_end_flush();
?>


                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">DELETE PATIENT</h1>                     
                    </div>

                    <hr>

                    <!-- Content Row -->  
                    <div class="row justify-content-center"  >     
                     <div class="card shadow mb-4">
                                <div class="card-header py-3 ju">
                                    <h4 class="m-0 font-weight-bold text-primary">Are You Sure Want To Delete?</h4>
                                </div>
                                <div class="card-body">
                                <form method="post" class="text-center my-3">
                <input type="submit" name="delete_confirm" class="btn btn-danger btn-lg mx-2" value="Yes">
                <a href="/FYP/Staff/NurseList.php" class="btn btn-secondary btn-lg mx-2">No</a>
                </form>
                                </div>
                            </div>
                            </div>
                   
            <!-- End of Main Content -->


            <?php
    include('../Staff/includes/footer.php');
    include('../Staff/includes/scripts.php');
    ?>
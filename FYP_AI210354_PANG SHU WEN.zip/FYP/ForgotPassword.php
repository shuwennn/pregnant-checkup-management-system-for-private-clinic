<?php 
// Include header and navbar files
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

?>

       

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">FORGOT PASSWORD PAGE</h1>                       
                    </div>

                    <hr>
<!-- Display the message -->
<?php if (!empty($message)): ?>
                    <div class="message-box">
                     <?php echo $message; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Content Row -->
                    <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h1>Forgot Password</h1>
                            </div>
                            <form action="SendPasswordReset.php" method="post">
                                <div class="card-body">                       
                                    <div class="form-group row mb-3 justify-content-center">
                                        <label for="email" class="col-sm-3 col-form-label">Email</label>
                                        <input name="email" type ="text" id="email" class="form-control" placeholder="Please enter email to reset" required>
                                    </div>
                                    <div class="form-group row mb-3">
                                        <div class="col-sm-12">
                                            <button class="btn btn-primary" type="submit"> Send </button>
                                        </div>
                                    </div>                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>     
<?php
session_start();

// Include the database connection file
include_once '../Config.php';

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Initialize variables to hold form data
$husband_ic = $husband_name = $husband_job = $husband_address = $husband_handphone = "";

// Check if form is submitted for updating patient information
if (isset($_POST['update'])) {
    // Retrieve form data
    $husband_ic = $_POST['husband_ic'];
    $husband_name = $_POST['husband_name'];
    $husband_job = $_POST['husband_job'];
    $husband_address = $_POST['husband_address'];
    $husband_handphone = $_POST['husband_handphone'];

    // Update the patient information in the database
    $query = "UPDATE patient_husband_information SET husband_name=?, husband_ic=?, husband_job=?, husband_address=?, husband_handphone=? WHERE patient_ic=?";

    // Retrieve patient_ic from URL
    $patient_ic = $_GET['patient_ic'];

    // Prepare the statement
    $stmt = mysqli_prepare($mysqli, $query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ssssss", $husband_name, $husband_ic, $husband_job, $husband_address, $husband_handphone, $patient_ic);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Check if the update was successful
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        $message = "Patient's husband information updated successfully!";
    } else {
        $message = "Failed to update patient's husband information!";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Fetch the data from the database and assign it to variables
$query = "SELECT * FROM patient_husband_information WHERE patient_ic=?";
$stmt = mysqli_prepare($mysqli, $query);
mysqli_stmt_bind_param($stmt, "s", $_GET['patient_ic']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    // Assign fetched data to variables
    $husband_ic = $row['husband_ic'];
    $husband_name = $row['husband_name'];
    $husband_job = $row['husband_job'];
    $husband_address = $row['husband_address'];
    $husband_handphone = $row['husband_handphone'];
} else {
    // Handle case where no records were found
    $message = "No records found.";
}

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');


// Close the statement
mysqli_stmt_close($stmt);
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Update Patient's Husband Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Update Patient's Husband Information Form -->
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Husband's Details</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?patient_ic=' . urlencode($_GET['patient_ic']); ?>" method="post">
                        <div class="form-group">
                            <label for="husband_ic">Husband's IC</label>
                            <input type="text" class="form-control" id="husband_ic" name="husband_ic" value="<?php echo htmlspecialchars($husband_ic); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="husband_name">Husband's Name</label>
                            <input type="text" class="form-control" id="husband_name" name="husband_name" value="<?php echo htmlspecialchars($husband_name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="husband_job">Husband's Job</label>
                            <input type="text" class="form-control" id="husband_job" name="husband_job" value="<?php echo htmlspecialchars($husband_job); ?>">
                        </div>
                        <div class="form-group">
                            <label for="husband_address">Husband's Address</label>
                            <textarea class="form-control" id="husband_address" name="husband_address" rows="3"><?php echo htmlspecialchars($husband_address); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="husband_handphone">Husband's Contact Number</label>
                            <input type="text" class="form-control" id="husband_handphone" name="husband_handphone" value="<?php echo htmlspecialchars($husband_handphone); ?>">
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary" name="update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scripts.php');
    ?>
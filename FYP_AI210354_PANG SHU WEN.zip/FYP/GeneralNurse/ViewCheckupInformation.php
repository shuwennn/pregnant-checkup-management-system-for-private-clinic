<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Retrieve patient_ic from GET parameters or POST parameters
$patient_ic = isset($_GET['patient_ic']) ? $_GET['patient_ic'] : (isset($_POST['patient_ic']) ? $_POST['patient_ic'] : '');

// Retrieve the patient's name from the database
$patient_name = '';
if (!empty($patient_ic)) {
    $sql_patient = "SELECT name FROM patient_basic_information WHERE patient_ic = ?";
    $stmt_patient = mysqli_prepare($conn, $sql_patient);
    if ($stmt_patient) {
        mysqli_stmt_bind_param($stmt_patient, "s", $patient_ic);
        mysqli_stmt_execute($stmt_patient);
        mysqli_stmt_bind_result($stmt_patient, $patient_name);
        mysqli_stmt_fetch($stmt_patient);
        mysqli_stmt_close($stmt_patient);
    }
}

// Check if patient_ic parameter is provided
if (!isset($_GET['patient_ic'])) {
    $message = "Invalid request. Please ensure that patient_ic parameter is provided.";
    exit();
}

$patient_ic = $_GET['patient_ic'];

// Define the number of records per page
$records_per_page = 1;

// Set default page to 1 if not provided
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Validate page number
if ($page < 1) {
    $page = 1;
}

// Calculate the offset for the SQL query
$offset = ($page - 1) * $records_per_page;

// Retrieve total number of records for the patient
$sql_count_records = "SELECT COUNT(*) AS total_records FROM checkup_information WHERE patient_ic = ?";
$stmt_count_records = mysqli_prepare($conn, $sql_count_records);
mysqli_stmt_bind_param($stmt_count_records, "s", $patient_ic);
mysqli_stmt_execute($stmt_count_records);
$result_count_records = mysqli_stmt_get_result($stmt_count_records);
$row_count_records = mysqli_fetch_assoc($result_count_records);
$total_records = $row_count_records['total_records'];

// Calculate total pages
$total_pages = ceil($total_records / $records_per_page);

// Initialize variables
$checkup_id = '';
$date = '';
$lr_lk = '';
$poa_pog = '';
$urin_alb = '';
$urin_sugar = '';
$hb = '';
$weight = '';
$bp = '';
$pulse = '';
$oed = '';
$fund_height = '';
$presentation = '';
$fetal_heart = '';
$movement = '';
$remark = '';
$image = '';
$fbs1 = '';
$hpp2 = '';
$pre_breakfast2 = '';
$pre_post_lunch2 = '';
$pre_post_dinner2 = '';
$prebed_dinner2 = '';

// Retrieve checkup records for the current page
$sql_select_checkup = "SELECT * FROM checkup_information WHERE patient_ic = ? ORDER BY date ASC LIMIT ?, ?";
$stmt_select_checkup = mysqli_prepare($conn, $sql_select_checkup);
if (!$stmt_select_checkup) {
    die("Prepare failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_select_checkup, "sii", $patient_ic, $offset, $records_per_page);
mysqli_stmt_execute($stmt_select_checkup);
$result_checkup = mysqli_stmt_get_result($stmt_select_checkup);

// Check if there are any checkup records
if (mysqli_num_rows($result_checkup) > 0) {
    // Fetch data from the result set
    $row = mysqli_fetch_assoc($result_checkup);
    $checkup_id = $row['checkup_id'];
    $date = $row['date'];
    $lr_lk = $row['lr_lk'];
    $poa_pog = $row['poa_pog'];
    $urin_alb = $row['urin_alb'];
    $urin_sugar = $row['urin_sugar'];
    $hb = $row['hb'];
    $weight = $row['weight'];
    $bp = $row['bp'];
    $pulse = $row['pulse'];
    $oed = $row['oed'];
    $fund_height = $row['fund_height'];
    $presentation = $row['presentation'];
    $fetal_heart = $row['fetal_heart'];
    $movement = $row['movement'];
    $remark = $row['remark'];
    $image = $row['image'];
    
    $fbs1 = $row['fbs1'];
    $hpp2 = isset($row['hpp2']) ? $row['hpp2'] : ''; // Initialize $hpp2 with an empty string if it's not set
    $pre_breakfast2 = $row['pre_breakfast2'];
    $pre_post_lunch2 = $row['pre_post_lunch2'];
    $pre_post_dinner2 = $row['pre_post_dinner2'];
    $prebed_dinner2 = $row['prebed_dinner2'];
} else {
$message = "No checkup records found.";
}

// Close statement
mysqli_stmt_close($stmt_select_checkup);

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');

mysqli_close($conn);
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Patient Checkup Information-<span style="color:blue;font-weight:bold"><?php echo htmlspecialchars($patient_name); ?></span></h1>

    <?php if ($message != ""): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php else: ?>
        <!-- Display Checkup Information -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Checkup Information</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-bordered mb-0">
                            <tbody>
                            <tr>
                                    <th scope="row">Checkup ID:</th>
                                    <td><?php echo $checkup_id; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Date:</th>
                                    <td><?php echo $date; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Home Visits/Clinic Visits (LR/LK):</th>
                                    <td><?php echo $lr_lk; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Period of Amenorrhea & Gestation (Week/Day):</th>
                                    <td><?php echo $poa_pog; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Urine Albumin:</th>
                                    <td><?php echo $urin_alb; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Urine Sugar:</th>
                                    <td><?php echo $urin_sugar; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Hemoglobin (gm%):</th>
                                    <td><?php echo $hb; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Weight (kg):</th>
                                    <td><?php echo $weight; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Blood Pressure:</th>
                                    <td><?php echo $bp; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Patient's Pulse (1 minute):</th>
                                    <td><?php echo $pulse; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Oedema:</th>
                                    <td><?php echo $oed; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Fundal Height:</th>
                                    <td><?php echo $fund_height; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-bordered mb-0">
                            <tbody>
                                <tr>
                                    <th scope="row">Presentation:</th>
                                    <td><?php echo $presentation; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Fetal Heart:</th>
                                    <td><?php echo $fetal_heart; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Movement:</th>
                                    <td><?php echo $movement; ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Any Remark:</th>
                                    <td><?php echo $remark; ?></td>
                                </tr>
                                <tr>
    <th scope="row">Image:</th>
    <td>
    <?php
    // Check if the BLOB data is not empty
    if (!empty($image)) {
        // Convert the BLOB data to base64 encoding
        $image_data = base64_encode($image);

        // Generate the data URI for embedding the image
        $image_src = 'data:image/jpeg;base64,' . $image_data;

        // Display the image
        echo "<img src='$image_src' alt='Latest Checkup Image' style='max-width: 50%; height: auto;'>";
    } else {
        // If the BLOB data is empty, display a placeholder message
        echo "<p>No image available</p>";
    }
    ?>
    </td>
</tr>

                                <tr>
                                <?php if ($fbs1 != 0) { ?>
                                    <th scope="row">FBS1:</th>
                                    <td><?php echo $fbs1; ?></td>
                                    <?php } ?>
                                </tr>
                                <tr>
                                <?php if (!empty($hpp2)) { ?>
                                    <th scope="row">HPP2:</th>
                                    <td><?php echo $hpp2; ?></td>
                                    <?php } ?>
                                </tr>
                                <tr>
                                <?php if ($pre_breakfast2 != 0) { ?>
                                    <th scope="row">Pre Breakfast 2:</th>
                                    <td><?php echo $pre_breakfast2; ?></td>
                                    <?php } ?>
                                </tr>
                                <tr>
                                <?php if ($pre_post_lunch2 != 0) { ?>
                                    <th scope="row">Pre Post Lunch 2:</th>
                                    <td><?php echo $pre_post_lunch2; ?></td>
                                    <?php } ?>
                                </tr>
                                <tr>
                                <?php if ($pre_post_dinner2 != 0) { ?>
                                    <th scope="row">Pre Post Dinner 2:</th>
                                    <td><?php echo $pre_post_dinner2; ?></td>
                                    <?php } ?>
                                </tr>
                                <tr>
                                <?php if ($prebed_dinner2 != 0) { ?>
                                    <th scope="row">Pre Bed Dinner 2:</th>
                                    <td><?php echo $prebed_dinner2; ?></td>
                                    <?php } ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<!-- /.container-fluid -->

   <!-- Add the update button below the existing content -->
   <p>
    <a href='UpdateCheckupInformation.php?checkup_id=<?php echo $checkup_id; ?>' class='btn btn-warning'>Update</a>
</p>

            </div>
            <!-- End of Main Content -->

           <!-- Pagination -->
<div class="pagination">
    <?php
    // Generate pagination buttons
    if ($page > 1) {
        echo "<a href='ViewCheckupInformation.php?patient_ic=$patient_ic&page=".($page - 1)."' class='btn btn-secondary'>Previous</a> ";
    }
    for ($i = 1; $i <= $total_pages; $i++) {
        echo "<a href='ViewCheckupInformation.php?patient_ic=$patient_ic&page=$i' class='btn btn-primary'";
        if ($i === $page) {
            echo " class='active'";
        }
        echo ">$i</a> ";
    }
    if ($page < $total_pages) {
        echo "<a href='ViewCheckupInformation.php?patient_ic=$patient_ic&page=".($page + 1)."' class='btn btn-secondary'>Next</a>";
    }
    ?>
</div>
<?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scripts.php');
    ?>
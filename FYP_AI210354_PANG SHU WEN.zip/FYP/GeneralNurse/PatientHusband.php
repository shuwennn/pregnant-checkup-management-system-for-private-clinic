<?php
session_start();

// Include the database connection file
require('../Config.php');

// Function to check if husband_ic exists in any of the specified tables
function checkUniqueHusbandIC($conn, $husband_ic) {
    $tables = ['doctor', 'nurse', 'patient_basic_information'];
    foreach ($tables as $table) {
        if ($table === 'patient_basic_information') {
            $column = 'patient_ic'; // Adjust column name for patient_basic_information table
        } else {
            $column = 'ic_no'; // Default column name for other tables
        }
        $query = "SELECT 1 FROM $table WHERE $column = ?";
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
            die("Prepare failed: " . mysqli_error($conn)); // Handle prepare error
        }
        mysqli_stmt_bind_param($stmt, "s", $husband_ic);
        if (!mysqli_stmt_execute($stmt)) {
            die("Execute failed: " . mysqli_error($conn)); // Handle execute error
        }
        mysqli_stmt_store_result($stmt);
        $count = mysqli_stmt_num_rows($stmt);
        mysqli_stmt_close($stmt);
        
        if ($count > 0) {
            return false; // Not unique if found in any table
        }
    }
    return true; // Unique if not found in any table
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Retrieve 'patient_ic' from URL parameter
if(isset($_GET['patient_ic']) && !empty($_GET['patient_ic'])) {
    $patient_ic = (string)$_GET['patient_ic'];
} else {
    die("ERROR: Patient IC not provided.");
}

$message = "";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize form data
    $husband_ic = mysqli_real_escape_string($mysqli, $_POST['husband_ic']);
    $husband_name = mysqli_real_escape_string($mysqli, $_POST['husband_name']);
    $husband_job = mysqli_real_escape_string($mysqli, $_POST['husband_job']);
    $husband_address = mysqli_real_escape_string($mysqli, $_POST['husband_address']);
    $husband_handphone = mysqli_real_escape_string($mysqli, $_POST['husband_handphone']);

    // Check uniqueness of husband_ic
    if (!checkUniqueHusbandIC($mysqli, $husband_ic)) {
        $message = "Husband IC already exists in the database.";
    } else {
        // Prepare and execute the SQL query for insertion
        $sql_insert = "INSERT INTO patient_husband_information (patient_ic, husband_ic, husband_name, husband_job, husband_address, husband_handphone) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_insert = mysqli_prepare($mysqli, $sql_insert);
        if (!$stmt_insert) {
            die("Prepare failed: " . mysqli_error($mysqli));
        }
        mysqli_stmt_bind_param($stmt_insert, "ssssss", $patient_ic, $husband_ic, $husband_name, $husband_job, $husband_address, $husband_handphone);
        if (!mysqli_stmt_execute($stmt_insert)) {
            die("Execute failed: " . mysqli_error($mysqli));
        }
        $message = "Data stored in the database successfully.";
        mysqli_stmt_close($stmt_insert);
    }
}

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Insert Patient Husband Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Husband Information Form -->
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Patient Husband Information</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?patient_ic=' . urlencode($patient_ic); ?>" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="husband_ic">Husband Identification Number</label>
                                    <input type="text" class="form-control" id="husband_ic" name="husband_ic" placeholder="Please enter patient's husband identification number" required>
                                </div>
                                <div class="form-group">
                                    <label for="husband_name">Name</label>
                                    <input type="text" class="form-control" id="husband_name" name="husband_name" placeholder="Please enter patient's husband name" required>
                                </div>
                                <div class="form-group">
                                    <label for="husband_job">Job</label>
                                    <input type="text" class="form-control" id="husband_job" name="husband_job" placeholder="Please enter job" required>
                                </div>
                            
                           
                                <div class="form-group">
                                    <label for="husband_address">Address</label>
                                    <input type="text" class="form-control" id="husband_address" name="husband_address" placeholder="Please enter home address" required>
                                </div>
                                <div class="form-group">
                                    <label for="husband_handphone">Handphone Number</label>
                                    <input type="text" class="form-control" id="husband_handphone" name="husband_handphone" placeholder="Please enter handphone number" required>
                                </div>
                           
                       

                        <!-- Submit Button -->
                        <div class="form-group row mb-3">
                            <div class="col-sm-12">
                            <a href="PatientInformation.php?patient_ic=<?php echo urlencode($patient_ic); ?>" class="btn btn-back">Back</a>
                                <button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">Submit</button>
                                <a href="AntenatalScreeningTest.php?patient_ic=<?php echo urlencode($patient_ic); ?>" class="btn btn-next">Next</a>
                            </div>
                        </div>  
                        </div>
                        </div> 
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->


<?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scripts.php');
    ?>
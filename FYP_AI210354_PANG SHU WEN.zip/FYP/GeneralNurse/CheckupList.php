<?php
// Initialize session
session_start();

// Include configuration file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

if (isset($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];

    $query = "SELECT * FROM patient_basic_information WHERE id='$patient_ic'";
    $query_run = mysqli_query($con, $query);

    if (mysqli_num_rows($query_run) > 0) {
        echo "<h2>Patients List:</h2>";
        echo "<ul>";
        while ($row = mysqli_fetch_assoc($query_run)) {
            echo "<li>Patient IC: " . $row['patient_ic'] . " - Name: " . $row['name'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No Record Found";
    }
}

// Include header and navbar files
include('../GeneralNurse/includes/headerlist.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');

?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Checkup Section</h1>                  

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Checkup List</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>                                           
                                            <th>Patient Identification Number</th>
                                            <th>Patient Name</th>
                                            <th>Action</th>                              
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                // Fetch all patients from the database
                $con = mysqli_connect("localhost", "root", "", "pregnant_system");
                if (!$con) {
                    die("Connection failed: " . mysqli_connect_error());
                }

                $query = "SELECT * FROM patient_basic_information";
                $query_run = mysqli_query($con, $query);

                if (mysqli_num_rows($query_run) > 0) {
                    while ($row = mysqli_fetch_assoc($query_run)) {
                        echo "<tr>";
                        echo "<td>" . $row['patient_ic'] . "</td>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>";
                        echo "<a href='../GeneralNurse/CheckupInformation.php?patient_ic=" . $row['patient_ic'] . "' class='btn btn-primary btn-sm mr-1'>Insert</a>";
                        echo "<a href='../GeneralNurse/ViewCheckupInformation.php?patient_ic=" . $row['patient_ic'] . "' class='btn btn-success btn-sm mr-1'>View</a>";
                        echo "<a href='../GeneralNurse/DeleteCheckupInformation.php?patient_ic=" . $row['patient_ic'] . "' class='btn btn-danger btn-sm'>Delete</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    $message = "<tr><td colspan='2'>No records found</td></tr>";
                }

                mysqli_close($con);
                ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scriptslist.php');
    ?>

   
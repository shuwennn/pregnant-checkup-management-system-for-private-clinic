<?php
ob_start();
// Start session
session_start();

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');

// Include the database connection file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Fetch existing appointment slots from the database
function fetchAppointmentSlots($mysqli) {
    $sql = "SELECT * FROM appointment";
    $result = $mysqli->query($sql);

    if (!$result) {
        // Handle query error
        die("ERROR: Query execution failed - " . $mysqli->error);
    }

    $existingSlots = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $startDateTime = $row['date'] . 'T' . $row['start_time'];
            $endDateTime = $row['date'] . 'T' . $row['end_time'];
            $existingSlots[] = [
                'title' => ($row['availability'] == 1) ? 'Available' : 'Booked',
                'start' => $startDateTime,
                'end' => $endDateTime,
                'status' => ($row['availability'] == 1) ? 'available' : 'booked'
            ];
        }
    }
    
    return $existingSlots;
}

$existingSlots = fetchAppointmentSlots($mysqli);
$slotsJson = json_encode($existingSlots);

$mysqli->close();

ob_end_flush();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Event Calendar</title>

     <!-- Include necessary CSS files -->
     <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css/sb-admin-2.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />

    <!-- Include jQuery and FullCalendar scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
 
</head>
<body>
    
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Topbar Search -->
        <form
            class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
                <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                    aria-label="Search" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                    </button>
                </div>
            </div>
        </form>

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-search fa-fw"></i>
                </a>
                <!-- Dropdown - Messages -->
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                    aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto w-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="Search for..." aria-label="Search"
                                aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>


        </ul>

    </nav>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Appointment Calendar</h1>
</div>

<hr>

<!-- Content Row -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#event_entry_modal">Create Appointment Slot</button>
            <div id="calendar"></div>
        </div>
    </div>
</div>

  <!-- Modal for adding new event -->
<div class="modal fade" id="event_entry_modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Add Appointment Slot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="event_date">Appointment Date</label>
                    <input type="date" name="event_date" id="event_date" class="form-control" placeholder="Appointment Date">
                </div>
                <div class="form-group">
                    <label for="time_slots_per_day">Number of Appointment Slot</label>
                    <input type="number" name="time_slots_per_day" id="time_slots_per_day" class="form-control" min="1" value="1">
                </div>
                <div class="form-group">
<label for="start_time">Appointment start time</label>
<input type="time" name="start_time" id="start_time" class="form-control" placeholder="Appointment start time">
</div>
<div class="form-group">
<label for="end_time">Appointment end time</label>
<input type="time" name="end_time" id="end_time" class="form-control" placeholder="Appointment end time">
</div>
<div class="form-group">
    <label for="duration">Appointment Duration (in minutes)</label>
    <input type="number" name="duration" id="duration" class="form-control" min="1" value="30">
</div>
                <div id="time_slots"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="generateTimeSlots()">Generate Time Slots</button>
                <button type="button" id="save_appointment_btn" class="btn btn-primary">Save Slot</button>
            </div>
        </div>
    </div>
</div>
     
<script>
    
    var existingSlots = <?php echo json_encode($existingSlots); ?>; // Existing appointment slots

$(document).ready(function() {
    // Initialize FullCalendar with existing appointment slots
    $('#calendar').fullCalendar({
        defaultView: 'month',
        timeZone: 'local', // Set the time zone to local
        editable: true,
        selectable: true,
        events: existingSlots, // Existing appointment slots from the database
        eventRender: function(event, element, view) {
          // Set the event's title to 'Available' or 'Booked' based on availability status
          if (event.status === 'available') {
                element.find('.fc-title').html('Available');
                element.css('background-color', '#4CAF50'); // Green background for available slots
                element.css('border-color', '#4CAF50'); // Border color for available slots
            } else {
                element.find('.fc-title').html('Booked');
                element.css('background-color', '#FF5733'); // Red background for booked slots
                element.css('border-color', '#FF5733'); // Border color for booked slots
            }
            element.find('.fc-time').remove(); // Remove the time from the event element
        }
    });
});

      // Inside the generateTimeSlots() function
      function generateTimeSlots() {
    // Clear existing time slots
    timeSlots = [];

    var appointmentDate = $('#event_date').val();
    var startTime = $('#start_time').val();
    var endTime = $('#end_time').val();
    var numSlots = parseInt($('#time_slots_per_day').val());
    var duration = parseInt($('#duration').val());

    // Define lunch break start and end times
    var lunchBreakStart = moment('12:00', 'HH:mm');
    var lunchBreakEnd = moment('14:00', 'HH:mm');

    // Validate input
    if (!appointmentDate || !startTime || !endTime || numSlots < 1 || isNaN(numSlots) || !duration || isNaN(duration)) {
        alert("Please enter valid appointment date, start time, end time, number of slots, and duration.");
        return;
    }

    var startMoment = moment(startTime, "HH:mm");
    var endMoment = moment(endTime, "HH:mm");

    // Calculate total duration in minutes excluding lunch break
    var totalDuration = endMoment.diff(startMoment, 'minutes') - (lunchBreakEnd.diff(lunchBreakStart, 'minutes'));

    // Calculate the duration per slot
    var durationPerSlot = duration;

    // Generate time slots for the selected date only, skipping lunch break
    var currentMoment = startMoment.clone();
    var lunchBreakSkipped = false; // Flag to track if lunch break has been skipped
    while (timeSlots.length < numSlots) {
        // Skip lunch break
        if (!lunchBreakSkipped && currentMoment.isSameOrAfter(lunchBreakStart) && currentMoment.isBefore(lunchBreakEnd)) {
            currentMoment = lunchBreakEnd.clone(); // Move to the end of lunch break
            lunchBreakSkipped = true; // Set the flag to true
        }

        // Calculate slot end time
        var slotEndTime = currentMoment.clone().add(duration, 'minutes');

        // Ensure slot end time does not exceed end time
        if (slotEndTime.isAfter(endMoment)) {
            slotEndTime = endMoment.clone(); // Adjust slot end time to end time
        }

        // Add slot to time slots array
        timeSlots.push({
            title: 'Available',
            start: currentMoment.format('YYYY-MM-DDTHH:mm:ss'),
            end: slotEndTime.format('YYYY-MM-DDTHH:mm:ss'),
            available: true,
            status: ''
        });

        // Move to the next slot start time
        currentMoment.add(durationPerSlot, 'minutes');
    }

    // Clear existing time slots from the calendar
    $('#calendar').fullCalendar('removeEventSources');

    // Add the generated time slots to the FullCalendar events array
    $('#calendar').fullCalendar('addEventSource', timeSlots);
}

// Inside the saveAppointment() function
function saveAppointment() {
    var appointmentDate = $('#event_date').val();
    var timeSlots = getTimeSlots();

    // Validate input
    if (!appointmentDate || !timeSlots || timeSlots.length === 0) {
        alert("No time slots generated. Please generate time slots.");
        return;
    }

    // Construct data object to send to server
    var eventData = {
        date: appointmentDate,
        timeSlots: timeSlots
    };

    // Send data to server using AJAX
    $.ajax({
        url: "save_appointment.php",
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(eventData),
        contentType: "application/json; charset=utf-8",
        success: function(response) {
            // Handle success response
            if (response.status) {
                alert(response.msg);
                // Clear timeSlots array and close modal
                $('#event_entry_modal').modal('hide');
                // Refresh calendar to display updated status
                $('#calendar').fullCalendar('refetchEvents');
            } else {
                alert(response.msg);
            }
        },
        error: function(xhr, status, error) {
            // Handle error response
            console.log(xhr.responseText);
            alert("Error saving appointment. Please try again later.");
        }
    });
}

function getTimeSlots() {
    var timeSlots = [];
    // Your logic to retrieve time slots from the calendar
    // Example:
    $('#calendar').fullCalendar('clientEvents', function(event) {
        if (event.start && event.end) {
            timeSlots.push({
                title: event.title,
                start: event.start.format(),
                end: event.end.format(),
                available: event.available
            });
        }
    });
    return timeSlots;
}

  // Attach event listener to the "Generate Time Slots" button
  $('#generate_time_slots_btn').on('click', function() {
        generateTimeSlots();
    });

    // Attach event listener to the "Save Appointment" button
    $('#save_appointment_btn').on('click', function() {
        saveAppointment();
    });

</script>


  <!-- Include other necessary scripts -->
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../js/sb-admin-2.min.js"></script>
<?php
    
    include('../GeneralNurse/includes/footer.php');
    ?>
</body>
</html>
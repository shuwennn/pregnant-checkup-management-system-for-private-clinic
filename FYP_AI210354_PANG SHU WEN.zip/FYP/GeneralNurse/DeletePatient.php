<?php
session_start();
// Start output buffering
ob_start();

// Include the database connection file
require_once("../Config.php");

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check if the delete button is clicked and confirmation is received
if(isset($_POST['delete_confirm']) && $_POST['delete_confirm'] == 'Yes') {
    // Get id parameter value from URL
    $patient_ic = $_GET['patient_ic'];

    // Delete associated records from antenatal_screening_test table
    $deleteAssociatedAntenatal = mysqli_query($mysqli, "DELETE FROM antenatal_screening_test WHERE patient_ic = '$patient_ic'");

    // Delete associated records from husband_information table
    $deleteAssociatedHusband = mysqli_query($mysqli, "DELETE FROM patient_husband_information WHERE patient_ic = '$patient_ic'");

    // Delete associated records from checkup_information table
    $deleteAssociatedCheckup = mysqli_query($mysqli, "DELETE FROM checkup_information WHERE patient_ic = '$patient_ic'");

    // Delete associated records from appointment table
    $deleteAssociatedAppointment = mysqli_query($mysqli, "DELETE FROM appointment WHERE patient_ic = '$patient_ic'");

    if ($deleteAssociatedAntenatal && $deleteAssociatedHusband && $deleteAssociatedCheckup && $deleteAssociatedAppointment) {
        // Proceed with deleting the record from patient_basic_information
        $result = mysqli_query($mysqli, "DELETE FROM patient_basic_information WHERE patient_ic = '$patient_ic'");
        if ($result) {
            // Redirect to the main display page (index.php in our case)
            header("Location:/FYP/GeneralNurse/PatientList.php");
            exit; // Exit to prevent further execution
        } else {
            // Display error message if deletion fails
            echo "Error deleting record: " . mysqli_error($mysqli);
        }
    } else {
        // Display error message if deletion of associated records fails
        echo "Error deleting associated records: " . mysqli_error($mysqli);
    }

    // Close the database connection
    mysqli_close($mysqli);
}

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');

// End output buffering and flush the output
ob_end_flush();
?>


                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">DELETE PATIENT</h1>                     
                    </div>

                    <hr>

                    <!-- Content Row -->  
                    <div class="row justify-content-center"  >     
                     <div class="card shadow mb-4">
                                <div class="card-header py-3 ju">
                                    <h4 class="m-0 font-weight-bold text-primary">Are You Sure Want To Delete?</h4>
                                </div>
                                <div class="card-body">
                                <form method="post" class="text-center my-3">
                <input type="submit" name="delete_confirm" class="btn btn-danger btn-lg mx-2" value="Yes">
                <a href="/FYP/GeneralNurse/PatientList.php" class="btn btn-secondary btn-lg mx-2">No</a>
                </form>
                                </div>
                            </div>
                            </div>
                   
            <!-- End of Main Content -->


            <?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scripts.php');
    ?>
<?php
// Initialize session
session_start();

// Include header and navbar files
include('../GeneralNurse/includes/headerlist.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');

$con = mysqli_connect("localhost", "root", "", "pregnant_system");

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}


$message = "";

if (isset($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];

    $query = "SELECT * FROM patient_basic_information WHERE id='$patient_ic'";
    $query_run = mysqli_query($con, $query);

    if (mysqli_num_rows($query_run) > 0) {
        echo "<h2>Patients List:</h2>";
        echo "<ul>";
        while ($row = mysqli_fetch_assoc($query_run)) {
            echo "<li>Patient IC: " . $row['patient_ic'] . " - Name: " . $row['name'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No Record Found";
    }
}
?>

             <!-- Begin Page Content -->
             <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Report List</h1>

        
<?php if ($message != ""): ?>
<div class="alert alert-info mt-2">
<?php echo $message; ?>
</div>
<?php endif; ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Report List</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                    <th>Patient Identification Number</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Action</th>                            
                    </tr>
                </thead>
                <tbody>
                <?php
// Fetch all patients from the database
$con = mysqli_connect("localhost", "root", "", "pregnant_system");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM patient_basic_information";
$query_run = mysqli_query($con, $query);

if (mysqli_num_rows($query_run) > 0) {
    while ($row = mysqli_fetch_assoc($query_run)) {
        $patient_ic = $row['patient_ic'];
        $checkup_query = "SELECT date FROM checkup_information WHERE patient_ic='$patient_ic'";
        $checkup_query_run = mysqli_query($con, $checkup_query);
        
        if (mysqli_num_rows($checkup_query_run) > 0) {
            while ($checkup_row = mysqli_fetch_assoc($checkup_query_run)) {
                echo "<tr>";
                echo "<td>" . $row['patient_ic'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $checkup_row['date'] . "</td>";
                echo "<td><a href='../GeneralNurse/ReportPatient.php?patient_ic=" . $row['patient_ic'] . "&checkup_date=" . $checkup_row['date'] . "' class='btn btn-primary btn-sm mr-1'>View</a></td>";
                echo "</tr>";
            }
        }else {
            echo "<tr>";
            echo "<td>" . $row['patient_ic'] . "</td>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>N/A</td>";
            echo "<td><a href='../GeneralNurse/ReportPatient.php?patient_ic=" . $row['patient_ic'] . "' class='btn btn-primary btn-sm mr-1'>View</a></td>"; // Removed the checkup_date parameter
            echo "</tr>";
        }
        
    }
} else {
    echo "<tr><td colspan='4'>No records found</td></tr>";
}

mysqli_close($con);
?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scriptslist.php');
    ?>
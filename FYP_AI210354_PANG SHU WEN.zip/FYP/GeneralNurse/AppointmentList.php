<!-- Modal for updating appointment -->
<div class="modal fade" id="updateAppointmentModal" tabindex="-1" role="dialog" aria-labelledby="updateAppointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateAppointmentModalLabel">Update Appointment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="updateAppointmentForm">
                    <div class="form-group">
                        <label for="patient_ic">Patient IC</label>
                        <input type="text" class="form-control" id="patient_ic" name="patient_ic">
                    </div>
                    <div class="form-group">
                        <label for="remark">Remark</label>
                        <input type="text" class="form-control" id="remark" name="remark">
                    </div>
                    <!-- Hidden input field for appointment ID -->
                    <input type="hidden" id="appointmentId" name="appointmentId">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php
// Start session
session_start();

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Include header and navbar files
include('../GeneralNurse/includes/header.php');
include('../GeneralNurse/includes/navbar.php');
include('../GeneralNurse/includes/topbar.php');

// Include the database connection file
require('../Config.php');


// Check for status message
$status_message = isset($_GET['status']) ? $_GET['status'] : "";


// Establish database connection
$connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch appointment data from the database
$sql = "SELECT patient_ic, appoint_id, date, start_time, end_time, remark FROM appointment ORDER BY start_time DESC";
$result = mysqli_query($connection, $sql);

// Close the database connection
mysqli_close($connection);
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">APPOINTMENT LIST</h1>
    </div>

    <hr>

    <!-- Display the message -->
<?php if (!empty($status_message)) : ?>
    <div class="message-box">
        <?php echo $status_message; ?>
    </div>
<?php endif; ?>


    <!-- Content Row -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">  
                    <div class="card-body">
    <table class="table">
        <thead>
            <tr>
                <th>Patient Identification Number</th>
                <th>Appointment ID</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Remark</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through each row of data
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?php echo $row['patient_ic']; ?></td>
                    <td><?php echo $row['appoint_id']; ?></td>
                    <td><?php echo $row['date']; ?></td>
                    <td><?php echo $row['start_time']; ?></td>
                    <td><?php echo $row['end_time']; ?></td>
                    <td><?php echo $row['remark']; ?></td>
                    <td>
                        <div class="d-flex">
                        <div style="height: 100px;">
                        <button type="button" class="btn btn-primary btn-sm mr-1" onclick="openUpdateModal(<?php echo $row['appoint_id']; ?>);">
                                                        <i class="fas fa-edit"></i> Update
                                                    </button>
                                                    </div>
                                                    <div style="height: 100px;">             
                            <form action="../Staff/DeleteAppointment.php" method="post" onsubmit="return confirmDelete(<?php echo $row['appoint_id']; ?>);">
                                <input type="hidden" name="appoint_id" value="<?php echo $row['appoint_id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash-alt"></i> Delete
                                </button>
                            </form>
                        </div>
                        </div>
                    </td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
</div>
</div>
</div>
</div>


<!-- Include jQuery first -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Your other JavaScript code that uses jQuery -->


<script>
    function openUpdateModal(appointmentId) {
        $('#updateAppointmentModal').modal('show');
        // Fetch appointment details and populate form fields
        $.ajax({
            url: 'FetchAppointmentDetails.php',
            type: 'POST',
            data: { appointmentId: appointmentId },
            success: function(response) {
                var appointment = JSON.parse(response);
                if (appointment) {
                    $('#patient_ic').val(appointment.patient_ic);
                    $('#remark').val(appointment.remark);
                    $('#appointmentId').val(appointment.appoint_id);
                }
            },
            error: function(error) {
                console.error("Error fetching appointment details: ", error);
            }
        });
    }

    // Function to handle form submission for updating appointment
    $('#updateAppointmentForm').on('submit', function(event) {
        event.preventDefault();  // Prevent default form submission

        var patientIC = $('#patient_ic').val();
        var remark = $('#remark').val();
        var appointmentId = $('#appointmentId').val();

        $.ajax({
            url: 'UpdateAppointment.php',
            type: 'POST',
            data: {
                patientIC: patientIC,
                remark: remark,
                appointmentId: appointmentId
            },
            success: function(response) {
                var result = JSON.parse(response);
                if (result.success) {
                    alert("Appointment updated successfully!");
                    $('#updateAppointmentModal').modal('hide');
                    location.reload();  // Reload the page to update the appointment list
                } else {
                    alert(result.error);
                }
            },
            error: function(error) {
                console.error("Error updating appointment: ", error);
                alert("An error occurred while updating the appointment. Please try again later.");
            }
        });
    });

    function confirmDelete(appointmentId) {
        return confirm("Are you sure you want to delete this appointment?");
    }

</script>

<?php
    include('../GeneralNurse/includes/footer.php');
    include('../GeneralNurse/includes/scripts.php');
    ?>
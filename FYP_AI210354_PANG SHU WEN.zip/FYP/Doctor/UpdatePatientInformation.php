<?php
session_start();

// Include the database connection file
include_once '../Config.php';

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Initialize variables to hold form data
$patient_ic = $name = $age = $email = $citizen = $race = $level_education = $job = $address = $handphone_no = $lnmp = $edp = $re_edd = $gr = $p = $born_date = $risk_factors = "";

// Fetch the patient IC from the URL parameter
if (isset($_GET['patient_ic']) && !empty($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];
} else {
    // Redirect or display an error message if patient_ic is not provided
    header("Location: /FYP/Staff/PatientInformation.php");
    exit();
}

// Fetch the data from the database and assign it to variables
$query = "SELECT * FROM patient_basic_information WHERE patient_ic=?";
$stmt = mysqli_prepare($mysqli, $query);
mysqli_stmt_bind_param($stmt, "s", $patient_ic);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    // Assign fetched data to variables
    $name = $row['name'];
    $age = $row['age'];
    $email = $row['email'];
    $citizen = $row['citizen'];
    $race = $row['race'];
    $level_education = $row['level_education'];
    $job = $row['job'];
    $address = $row['address'];
    $handphone_no = $row['handphone_no'];
    $lnmp = $row['lnmp'];
    $edp = $row['edp'];
    $re_edd = $row['re_edd'];
    $gr = $row['gr'];
    $p = $row['p'];
    $born_date = $row['born_date'];
    $risk_factors = $row['risk_factors'];
} else {
    // Handle case where no records were found
    $message = "No records found.";
}

// Close the statement
mysqli_stmt_close($stmt);

// Check if form is submitted for updating patient information
if(isset($_POST['update'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $citizen = $_POST['citizen'];
    $race = $_POST['race'];
    $level_education = $_POST['level_education'];
    $job = $_POST['job'];
    $address = $_POST['address'];
    $handphone_no = $_POST['handphone_no'];
    $lnmp = $_POST['lnmp'];
    $edp = $_POST['edp'];
    $re_edd = $_POST['re_edd'];
    $gr = $_POST['gr'];
    $p = $_POST['p'];
    $born_date = $_POST['born_date'];
    $risk_factors = $_POST['risk_factors'];

    // Update the patient information in the database
    $query = "UPDATE patient_basic_information SET name=?, age=?, email=?, citizen=?, race=?, level_education=?, job=?, address=?, handphone_no=?, lnmp=?, edp=?, re_edd=?, gr=?, p=?, born_date=?, risk_factors=? WHERE patient_ic=?";
    
    // Prepare the statement
    $stmt = mysqli_prepare($mysqli, $query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "sisssssssssssssss", $name, $age, $email, $citizen, $race, $level_education, $job, $address, $handphone_no, $lnmp, $edp, $re_edd, $gr, $p, $born_date, $risk_factors, $patient_ic);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Check if the update was successful
    if(mysqli_stmt_affected_rows($stmt) > 0) {
        $message = "Patient information updated successfully!";
    } else {
        $message = "Failed to update patient information!";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">

     <!-- Page Heading and Cards Section -->
     <div class="row">
        <div class="col-lg-12">
            <div class="d-flex align-items-center mb-4">
                <h1 class="h3 text-gray-800 mr-auto">Update Patient Information</h1>
                <!-- Collapsible Card - Update Patient Husband Information -->
                <div class="card shadow mx-2">
                    <a href="../Staff/UpdatePatientHusband.php?patient_ic=<?php echo urlencode($row['patient_ic']); ?>" class="d-block card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Update Patient Husband Information</h6>
                    </a>
                </div>
                <!-- Collapsible Card - Update Antenatal Screening Test -->
                <div class="card shadow mx-2">
                    <a href="../Staff/UpdateScreeningTest.php?patient_ic=<?php echo urlencode($row['patient_ic']); ?>" class="d-block card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Update Antenatal Screening Test</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Update Patient Information Form -->
    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Patient Basic Details</h6>
                </div>
                <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?patient_ic=<?php echo htmlspecialchars($patient_ic); ?>" method="post">
                        <div class="form-group">
                            <label for="patient_ic">Patient Identification Number</label>
                            <input type="text" class="form-control" id="patient_ic" name="patient_ic" value="<?php echo htmlspecialchars($patient_ic); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="age">Age</label>
                            <input type="number" class="form-control" id="age" name="age" value="<?php echo htmlspecialchars($age); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="citizen">Citizen</label>
                            <input type="text" class="form-control" id="citizen" name="citizen" value="<?php echo htmlspecialchars($citizen); ?>">
                        </div>
                        <div class="form-group">
                            <label for="race">Race</label>
                            <input type="radio" id="malay" name="race" value="MALAY" <?php echo ($race == 'MALAY') ? 'checked' : ''; ?>>
        <label for="malay">Malay</label><br>
        <input type="radio" id="chinese" name="race" value="CHINESE" <?php echo ($race == 'CHINESE') ? 'checked' : ''; ?>>
        <label for="chinese">Chinese</label><br>
        <input type="radio" id="india" name="race" value="INDIA" <?php echo ($race == 'INDIA') ? 'checked' : ''; ?>>
        <label for="india">India</label><br>
        <input type="radio" id="otherRadio" name="race" value="OTHER" <?php echo ($race == 'OTHER') ? 'checked' : ''; ?>>
        <label for="otherRadio">Other</label>
        <input name="other_race" type="text" id="otherInput" class="form-control" placeholder="Other..." <?php echo ($race == 'OTHER') ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                        </div>

                        <script>
    // Get the radio button and input field
    var raceRadio = document.querySelectorAll('input[name="race"]');
    var otherInput = document.getElementById('otherInput');

    // Add event listener to each radio button
    raceRadio.forEach(function(radio) {
        radio.addEventListener('change', function() {
            // If the "Other" radio button is checked, show the input field, otherwise hide it
            if (radio.value === 'OTHER') {
                otherInput.style.display = 'block';
                otherInput.required = true; // Make the input field required
            } else {
                otherInput.style.display = 'none';
                otherInput.required = false; // Make the input field not required
            }
        });
    });
</script>

                        <div class="form-group">
                            <label for="level_education">Level of Education</label>
                            <select id="level_education" name="level_education">
            <option value="upsr" <?php echo ($level_education == 'upsr') ? 'selected' : ''; ?>>UPSR</option>
            <option value="pt3" <?php echo ($level_education == 'pt3') ? 'selected' : ''; ?>>PT3</option>
            <option value="spm" <?php echo ($level_education == 'spm') ? 'selected' : ''; ?>>SPM</option>
            <option value="stpm" <?php echo ($level_education == 'stpm') ? 'selected' : ''; ?>>STPM</option>
            <option value="bachelor_degree" <?php echo ($level_education == 'bachelor_degree') ? 'selected' : ''; ?>>BACHELOR DEGREE</option>
            <option value="master_degree" <?php echo ($level_education == 'master_degree') ? 'selected' : ''; ?>>MASTER DEGREE</option>
            <option value="phd" <?php echo ($level_education == 'phd') ? 'selected' : ''; ?>>PHD</option>
            <option value="no" <?php echo ($level_education == 'no') ? 'selected' : ''; ?>>No Education</option>
        </select>
                        </div>
                        <div class="form-group">
                            <label for="job">Job</label>
                            <input type="text" class="form-control" id="job" name="job" value="<?php echo htmlspecialchars($job); ?>">
                        </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="form-group">
                        <label for="address">Home Address</label>
                        <textarea class="form-control" id="address" name="address" rows="4"><?php echo htmlspecialchars($address); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="handphone_no">Handphone Number</label>
                        <input type="text" class="form-control" id="handphone_no" name="handphone_no" value="<?php echo htmlspecialchars($handphone_no); ?>">
                    </div>
                    <div class="form-group">
                        <label for="lnmp">Last Normal Menstrual Period (LNMP)</label>
                        <input type="date" class="form-control" id="lnmp" name="lnmp" value="<?php echo htmlspecialchars($lnmp); ?>">
                    </div>
                    <div class="form-group">
                        <label for="edp">Estimated Date Delivery (EDP)</label>
                        <input type="date" class="form-control" id="edp" name="edp" value="<?php echo htmlspecialchars($edp); ?>">
                    </div>
                    <div class="form-group">
                        <label for="re_edd">Revised Expected Date Delivery (RE EDD)</label>
                        <input type="date" class="form-control" id="re_edd" name="re_edd" value="<?php echo htmlspecialchars($re_edd); ?>">
                    </div>
                    <div class="form-group">
                        <label for="gr">Gravida</label>
                        <input type="number" class="form-control" id="gr" name="gr" value="<?php echo htmlspecialchars($gr); ?>">
                    </div>
                    <div class="form-group">
                        <label for="p">Para</label>
                        <input type="text" class="form-control" id="p" name="p" value="<?php echo htmlspecialchars($p); ?>">
                    </div>
                    <div class="form-group">
                        <label for="born_date">Born Date</label>
                        <input type="date" class="form-control" id="born_date" name="born_date" value="<?php echo htmlspecialchars($born_date); ?>">
                    </div>
                    <div class="form-group">
                        <label for="risk_factors">Risk Factors</label>
                        <textarea class="form-control" id="risk_factors" name="risk_factors" rows="3"><?php echo htmlspecialchars($risk_factors); ?></textarea>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary" name="update">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
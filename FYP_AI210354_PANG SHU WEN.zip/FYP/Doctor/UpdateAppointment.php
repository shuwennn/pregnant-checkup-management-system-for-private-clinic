<?php
// Include the database connection file
require('../Config.php');

// Start the session
session_start();

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check if all required data is provided
if (isset($_POST['patientIC'], $_POST['remark'], $_POST['appointmentId'])) {
    // Sanitize and fetch form data
    $patientIC = $_POST['patientIC'];
    $remark = $_POST['remark'];
    $appointmentId = $_POST['appointmentId'];

    // Establish database connection
    $connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

    // Check if the connection was successful
    if (!$connection) {
        echo json_encode(array('error' => 'Database connection failed: ' . mysqli_connect_error()));
        exit();
    }

    // Begin a transaction
    mysqli_begin_transaction($connection);

    // Prepare and bind
    $stmt = $connection->prepare("UPDATE appointment SET patient_ic = ?, remark = ?, availability = '0' WHERE appoint_id = ?");
    $stmt->bind_param("ssi", $patientIC, $remark, $appointmentId);

    // Execute the query to update the appointment
    if ($stmt->execute()) {
        // Commit the transaction
        mysqli_commit($connection);
        echo json_encode(array('success' => 'Appointment updated successfully'));
    } else {
        // Rollback the transaction if updating appointment fails
        mysqli_rollback($connection);
        echo json_encode(array('error' => 'Error updating appointment: ' . $stmt->error));
    }

    // Close the statement and database connection
    $stmt->close();
    mysqli_close($connection);
} else {
    echo json_encode(array('error' => 'Required data is missing'));
}
?>

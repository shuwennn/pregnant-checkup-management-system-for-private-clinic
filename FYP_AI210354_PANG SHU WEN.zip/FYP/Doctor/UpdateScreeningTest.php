<?php
session_start();

// Include the database connection file
include_once '../Config.php';

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Initialize variables to hold form data
$date = $height = $blood_group = $vdrl = $hb = $hbs_ag = $hb_antibody = $rubella_antibody = $hiv_1 = $hiv_2 = $att = $others = "";

// Check if form is submitted for updating patient information
if (isset($_POST['update'])) {
    // Retrieve form data
    $date = $_POST['date'];
    $height = $_POST['height'];
    $blood_group = $_POST['blood_group'];
    $vdrl = $_POST['vdrl'];
    $hb = $_POST['hb'];
    $hbs_ag = $_POST['hbs_ag'];
    $hb_antibody = $_POST['hb_antibody'];
    $rubella_antibody = $_POST['rubella_antibody'];
    $hiv_1 = $_POST['hiv_1'];
    $hiv_2 = $_POST['hiv_2'];
    $att = $_POST['att'];
    $others = $_POST['others'];

    // Retrieve patient_ic from URL
    $patient_ic = $_GET['patient_ic'];

    // Update the patient information in the database
    $query = "UPDATE antenatal_screening_test SET date=?, height=?, blood_group=?, vdrl=?, hb=?, hbs_ag=?, hb_antibody=?, rubella_antibody=?, hiv_1=?, hiv_2=?, att=?, others=? WHERE patient_ic=?";

    // Prepare the statement
    if ($stmt = mysqli_prepare($mysqli, $query)) {
        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sssssssssssss", $date, $height, $blood_group, $vdrl, $hb, $hbs_ag, $hb_antibody, $rubella_antibody, $hiv_1, $hiv_2, $att, $others, $patient_ic);

        // Execute the statement
        mysqli_stmt_execute($stmt);

        // Check if the update was successful
        if (mysqli_stmt_affected_rows($stmt) > 0) {
            $message = "Screening test information updated successfully!";
        } else {
            $message = "Failed to update screening test information!";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        // Handle prepare statement failure
        $message = "Failed to prepare the SQL statement.";
    }
}

// Fetch the data from the database and assign it to variables
$query = "SELECT * FROM antenatal_screening_test WHERE patient_ic=?";
if ($stmt = mysqli_prepare($mysqli, $query)) {
    mysqli_stmt_bind_param($stmt, "s", $_GET['patient_ic']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Assign fetched data to variables
        $date = $row['date'];
        $height = $row['height'];
        $blood_group = $row['blood_group'];
        $vdrl = $row['vdrl'];
        $hb = $row['hb'];
        $hbs_ag = $row['hbs_ag'];
        $hb_antibody = $row['hb_antibody'];
        $rubella_antibody = $row['rubella_antibody'];
        $hiv_1 = $row['hiv_1'];
        $hiv_2 = $row['hiv_2'];
        $att = $row['att'];
        $others = $row['others'];
    } else {
        // Handle case where no records were found
        $message = "No records found.";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Handle prepare statement failure
    $message = "Failed to prepare the SQL statement.";
}

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Update Antenatal Screening Test Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Update Antenatal Screening Test Information Form -->
    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Antenatal Screening Test Details</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?patient_ic=' . urlencode($_GET['patient_ic']); ?>" method="post">
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($date); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="height">Height (cm)</label>
                            <input type="number" class="form-control" id="height" name="height" value="<?php echo htmlspecialchars($height); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="blood_group">Blood Group</label>
                            <input type="radio" id="A+" name="blood_group" value="A+" <?php if($blood_group == 'A+') echo 'checked'; ?>>
<label for="A+">A+</label><br>
<input type="radio" id="A-" name="blood_group" value="A-" <?php if($blood_group == 'A-') echo 'checked'; ?>>
<label for="A-">A-</label><br>
<input type="radio" id="B+" name="blood_group" value="B+" <?php if($blood_group == 'B+') echo 'checked'; ?>>
<label for="B+">B+</label><br>
<input type="radio" id="AB+" name="blood_group" value="AB+" <?php if($blood_group == 'AB+') echo 'checked'; ?>>
<label for="AB+">AB+</label><br>
<input type="radio" id="AB-" name="blood_group" value="AB-" <?php if($blood_group == 'AB-') echo 'checked'; ?>>
<label for="AB-">AB-</label><br>
<input type="radio" id="O+" name="blood_group" value="O+" <?php if($blood_group == 'O+') echo 'checked'; ?>>
<label for="O+">O+</label><br>
<input type="radio" id="O-" name="blood_group" value="O-" <?php if($blood_group == 'O-') echo 'checked'; ?>>
<label for="O-">O-</label><br>
                        </div>
                        <div class="form-group">
                            <label for="vdrl">Venereal Disease Research Laboratory (VDRL)</label>
                            <select name="vdrl" id="vdrl" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive" <?php if($vdrl == 'positive') echo 'selected'; ?>>positive</option>
            <option value="negative" <?php if($vdrl == 'negative') echo 'selected'; ?>>negative</option>
        </select>
                        </div>
                        <div class="form-group">
                            <label for="hb">Hemoglobin (g/dL)</label>
                            <input type="text" class="form-control" id="hb" name="hb" value="<?php echo htmlspecialchars($hb); ?>">
                        </div>
                        <div class="form-group">
                            <label for="hbs_ag">Hepatitis B Surface Antigen</label>
                            <select name="hbs_ag" id="hbs_ag" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive/reactive" <?php if($hbs_ag == 'positive/reactive') echo 'selected'; ?>>positive/reactive</option>
            <option value="negative/nonreactive" <?php if($hbs_ag == 'negative/nonreactive') echo 'selected'; ?>>negative/nonreactive</option>
        </select>
                        </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card shadow mb-4">   
                <div class="card-body">
                        <div class="form-group">
                            <label for="hb_antibody">Hepatitis B Surface Antibody</label>
                            <select name="hb_antibody" id="hb_antibody" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive/reactive" <?php if($hb_antibody == 'positive/reactive') echo 'selected'; ?>>positive/reactive</option>
            <option value="negative/nonreactive" <?php if($hb_antibody == 'positive/reactive') echo 'selected'; ?>>negative/nonreactive</option>
        </select>
                        </div>
                        <div class="form-group">
                            <label for="rubella_antibody">Rubella Antibody</label>
                            <input type="text" class="form-control" id="rubella_antibody" name="rubella_antibody" value="<?php echo htmlspecialchars($rubella_antibody); ?>">
                        </div>
                        <div class="form-group">
                            <label for="hiv_1">HIV 1</label>
                            <input type="text" class="form-control" id="hiv_1" name="hiv_1" value="<?php echo htmlspecialchars($hiv_1); ?>">
                        </div>
                        <div class="form-group">
                            <label for="hiv_2">HIV 2</label>
                            <input type="text" class="form-control" id="hiv_2" name="hiv_2" value="<?php echo htmlspecialchars($hiv_2); ?>">
                        </div>
                        <div class="form-group">
                            <label for="att">ATT</label>
                            <input type="text" class="form-control" id="att" name="att" value="<?php echo htmlspecialchars($att); ?>">
                        </div>
                        <div class="form-group">
                            <label for="others">Others</label>
                            <textarea class="form-control" id="others" name="others" rows="3"><?php echo htmlspecialchars($others); ?></textarea>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary" name="update">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
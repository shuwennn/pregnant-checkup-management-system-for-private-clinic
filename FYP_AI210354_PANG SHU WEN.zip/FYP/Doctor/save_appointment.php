<?php
// Establish database connection
$mysqli = new mysqli("localhost", "root", "", "pregnant_system");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the appointment data from the request body
    $postData = json_decode(file_get_contents("php://input"), true);

    // Extract appointment date and time slots
    $appointmentDate = $postData['date'];
    $timeSlots = $postData['timeSlots'];

    // Check if the appointment date is in the past
    $currentDate = date('Y-m-d');
    if ($appointmentDate < $currentDate) {
        // Appointment date is in the past, return error response
        $response = array(
            'status' => false,
            'msg' => 'Cannot create appointment slots for past dates.'
        );
        echo json_encode($response);
        exit;
    }

    // Disable foreign key checks
    $mysqli->query("SET foreign_key_checks = 0");

    // Prepare SQL statement to insert appointment data
    $stmt = $mysqli->prepare("INSERT INTO appointment (start_time, end_time, date) VALUES (?, ?, ?)");

    if ($stmt === false) {
        // Error occurred while preparing the statement
        $response = array(
            'status' => false,
            'msg' => 'Error preparing SQL statement: ' . $mysqli->error
        );
        echo json_encode($response);
        exit;
    }

    // Loop through each time slot and insert into the database
    foreach ($timeSlots as $slot) {
        // Extract start time and end time from the time slot
        $startTime = strtotime($slot['start']);
        $endTime = strtotime($slot['end']);

        // Bind parameters
        $result = $stmt->bind_param("sss", $slot['start'], $slot['end'], $appointmentDate);

        if ($result === false) {
            // Error occurred while binding parameters
            $response = array(
                'status' => false,
                'msg' => 'Error binding parameters: ' . $stmt->error
            );
            echo json_encode($response);
            exit;
        }

        // Execute the prepared statement
        $result = $stmt->execute();
        if ($result === false) {
            // Error occurred while executing the statement
            $response = array(
                'status' => false,
                'msg' => 'Error saving appointment data: ' . $stmt->error
            );
            echo json_encode($response);
            exit;
        }
    }

    // Close the prepared statement
    $stmt->close();

    // Re-enable foreign key checks
    $mysqli->query("SET foreign_key_checks = 1");

    // Appointment slots saved successfully
    $response = array(
        'status' => true,
        'msg' => 'Appointment slots saved successfully!'
    );
    echo json_encode($response);
} else {
    // Invalid request method
    $response = array(
        'status' => false,
        'msg' => 'Invalid request method.'
    );
    echo json_encode($response);
}

// Close the database connection
$mysqli->close();
?>

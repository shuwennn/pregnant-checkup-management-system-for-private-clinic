<?php
// Initialize session
session_start();

// Include configuration file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor' or 'head_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Include header and navbar files
include('../Doctor/includes/headerlist.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Nurse Section</h1>

    <!-- Insert Nurse Form -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Insert New Nurse</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="NurseInformation.php">
                <div class="form-group">
                    <label for="nurse_ic">Nurse IC</label>
                    <input type="text" class="form-control" id="nurse_ic" name="nurse_ic" required>
                </div>
                <button type="submit" class="btn btn-primary">Insert</button>
            </form>
            <?php if ($message != ""): ?>
                <div class="alert alert-info mt-2">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Nurse List</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nurse Identification Number</th>
                            <th>Nurse Name</th>
                            <th>Nurse ID</th> 
                            <th>Role</th> 
                            <th>Action</th>                              
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        // Fetch all nurses from the database
                        $query = "SELECT * FROM nurse";
                        $query_run = mysqli_query($mysqli, $query);

                        if ($query_run) {
                            if (mysqli_num_rows($query_run) > 0) {
                                while ($row = mysqli_fetch_assoc($query_run)) {
                                    echo "<tr>";
                                    echo "<td>" . $row['ic_no'] . "</td>";
                                    echo "<td>" . $row['full_name'] . "</td>";
                                    echo "<td>" . $row['nurse_id'] . "</td>";
                                    echo "<td>" . $row['role'] . "</td>";
                                    echo "<td>";
                                    echo "<a href='../Doctor/ViewNurse.php?nurse_ic=" . $row['ic_no'] . "' class='btn btn-primary btn-sm mr-1'>View</a>";
                                    echo "<a href='../Doctor/UpdateNurse.php?nurse_ic=" . $row['ic_no'] . "' class='btn btn-info btn-sm mr-1'>Update</a>";
                                    echo "<a href='../Doctor/DeleteNurse.php?nurse_ic=" . $row['ic_no'] . "' class='btn btn-danger btn-sm'>Delete</a>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5'>No records found</td></tr>";
                            }
                        } else {
                            echo "Error executing query: " . mysqli_error($mysqli);
                        }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scriptslist.php');
    ?>

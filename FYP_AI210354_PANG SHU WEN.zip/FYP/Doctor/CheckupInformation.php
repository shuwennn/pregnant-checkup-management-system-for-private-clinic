<?php
ob_start();
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');

// Retrieve patient_ic from GET parameters or POST parameters
$patient_ic = isset($_GET['patient_ic']) ? $_GET['patient_ic'] : (isset($_POST['patient_ic']) ? $_POST['patient_ic'] : '');

// Retrieve the patient's name from the database
$patient_name = '';
if (!empty($patient_ic)) {
    $sql_patient = "SELECT name FROM patient_basic_information WHERE patient_ic = ?";
    $stmt_patient = mysqli_prepare($conn, $sql_patient);
    if ($stmt_patient) {
        mysqli_stmt_bind_param($stmt_patient, "s", $patient_ic);
        mysqli_stmt_execute($stmt_patient);
        mysqli_stmt_bind_result($stmt_patient, $patient_name);
        mysqli_stmt_fetch($stmt_patient);
        mysqli_stmt_close($stmt_patient);
    }
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Check if an image is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Retrieve file details
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageName = $_FILES['image']['name'];
        $imageSize = $_FILES['image']['size'];
        $imageType = $_FILES['image']['type'];

        // Read the file content
        $imageData = file_get_contents($imageTmpName);

        // Retrieve 'patient_ic' from the form
        if (isset($_POST['patient_ic']) && !empty($_POST['patient_ic'])) {
            $patient_ic = $_POST['patient_ic'];
        } else {
            die("ERROR: Patient IC not provided.");
        }


        // Get form data
        $date = $_POST['date'];
        $poa_pog = $_POST['poa_pog'];
        $urin_alb = $_POST['urin_alb'];
        $urin_sugar = $_POST['urin_sugar'];
        $hb = $_POST['hb'];
        $weight = $_POST['weight'];
        $bp = $_POST['bp'];
        $pulse = $_POST['pulse'];
        $oed = $_POST['oed'];
        $fund_height = $_POST['fund_height'];
        $presentation = $_POST['presentation'];
        $fetal_heart = $_POST['fetal_heart'];
        $movement = $_POST['movement'];
        $remark = $_POST['remark'];
        $lr_lk = $_POST['lr_lk'];
        $fbs1 = isset($_POST['fbs1']) ? $_POST['fbs1'] : null;
        $hpp1 = isset($_POST['hpp1']) ? $_POST['hpp1'] : null;
        $pre_breakfast2 = isset($_POST['pre_breakfast2']) ? $_POST['pre_breakfast2'] : null;
        $pre_post_lunch2 = isset($_POST['pre_post_lunch2']) ? $_POST['pre_post_lunch2'] : null;
        $pre_post_dinner2 = isset($_POST['pre_post_dinner2']) ? $_POST['pre_post_dinner2'] : null;
        $prebed_dinner2 = isset($_POST['prebed_dinner2']) ? $_POST['prebed_dinner2'] : null;

   // Handle fetal heart rate conditionally
   if ($fetal_heart === 'Positive (+)' && isset($_POST['fetal_heart_rate'])) {
    $fetal_heart = $_POST['fetal_heart_rate'];
}



        // Generate checkup_id
        $checkup_id = generateCheckupID();


        // Prepare and execute the SQL statement
        $sql_insert = "INSERT INTO checkup_information (checkup_id, patient_ic, date, poa_pog, urin_alb, urin_sugar, hb, weight, bp, pulse, oed, fund_height, presentation, fetal_heart, movement, remark, lr_lk, image, fbs1, hpp1, pre_breakfast2, pre_post_lunch2, pre_post_dinner2, prebed_dinner2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt_insert = mysqli_prepare($conn, $sql_insert);
        if (!$stmt_insert) {
            die("Prepare failed: " . mysqli_error($conn));
        }

        // Bind parameters including image details
        mysqli_stmt_bind_param($stmt_insert, "ssssssssssssssssssssssss", 
            $checkup_id, $patient_ic, $date, $poa_pog, $urin_alb, $urin_sugar, $hb, $weight, $bp, $pulse, 
            $oed, $fund_height, $presentation, $fetal_heart, $movement, $remark, $lr_lk, 
            $imageData, $fbs1, $hpp1, $pre_breakfast2, $pre_post_lunch2, $pre_post_dinner2, $prebed_dinner2);

        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt_insert)) {
            $message = "Data stored in the database successfully.";
        } else {
            $message = "ERROR: Unable to execute $sql_insert. " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt_insert);
    } else {
        $message = "ERROR: Image upload failed.";
    }
}

// Function to generate a 5-digit checkup ID
function generateCheckupID()
{
    return mt_rand(10000, 99999);
}
ob_end_flush();
?>


       <!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Insert New Checkup Information-<span style="color:blue;font-weight:bold"><?php echo htmlspecialchars($patient_name); ?></span></h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Antenatal Screening Test Form -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Checkup Information</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="patient_ic" value="<?php echo isset($_GET['patient_ic']) ? htmlspecialchars($_GET['patient_ic']) : ''; ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="date">Date</label>
                                    <input type="date" class="form-control" id="date" name="date" placeholder="Please enter date" required>
                                </div>
                                <div class="form-group">
                                <label for="lr_lk">Home Visits/Clinic Visits (LR/LK)</label>                               
                                <select name="lr_lk" id="lr_lk" class="form-control" required>
                            <option value="" disabled selected>Please select result</option>
                            <option value="LR (Home Visits)">LR (Home Visits)</option>
                            <option value="LK (Clinic Visits)">LK (Clinic Visits)</option>
                            </select>
                                </div>
                                <div class="form-group">
                                    <label for="poa_pog">Period of Amenorrhea & Gestation (Week/Day)</label>
                                    <input type="text" class="form-control" id="poa_pog" name="poa_pog" placeholder="Please enter POA / POG" required>
                                </div>
                                <div class="form-group">
                                    <label for="urin_alb">Urin Albumin</label>
                                    <select name="urin_alb" id="urin_alb" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="+">+</option>
            <option value="++">++</option>
            <option value="+++">+++</option>
            <option value="-">-</option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="urin_sugar">Urin Sugar</label>
                                    <select name="urin_sugar" id="urin_sugar" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="Blue">Blue</option>
            <option value="Green">Green</option>
            <option value="Dark Green">Dark Green</option>
            <option value="Yellow">Yellow</option>
            <option value="Bick Red">Bick Red</option>
            <option value="-">-</option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="hb">Hemoglobin (gm%)</label>
                                    <input type="text" class="form-control" id="hb" name="hb" placeholder="Please enter Hemoglobin" required min="0" step="0.01">
                                </div>
                                <div class="form-group">
                                    <label for="weight">Weight (kg)</label>
                                    <input type="number" class="form-control" id="weight" name="weight" placeholder="Please enter Weight" required min="0">
                                </div>
                                <div class="form-group">
                                    <label for="bp">Blood Pressure</label>
                                    <input type="text" class="form-control" id="bp" name="bp" placeholder="Please enter Blood Pressure" required min="0" step="0.01">
                                </div>                                          
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                    <label for="pulse">Patient's Pulse (1 minute)</label>
                                    <input type="text" class="form-control" id="pulse" name="pulse" placeholder="Please enter Pulse" required min="0" step="0.01">
                                </div>
                                <div class="form-group">
                                    <label for="oed">Oedema</label>
                                    <select name="oed" id="oed" class="form-control" required>
            <option value="" disabled selected>Please select oedema</option>
            <option value="Positive (+)">Positive (+) </option>
            <option value="Negative (-)">Negative (-) </option>
            <option value="None">None</option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="fund_height">Fundal Height</label>
                                    <input type="number" class="form-control" id="fund_height" name="fund_height" placeholder="Please enter Fundal Height" required min="0">
                                </div>
                                <div class="form-group">
                                    <label for="presentation">Presentation</label>
                                    <select name="presentation" id="presentation" class="form-control" required>
            <option value="" disabled selected>Please select oedema</option>
            <option value="Cephalic">Cephalic</option>
            <option value="Breech">Breech</option>
            <option value="Oblique">Oblique</option>
            <option value="Transverse">Transverse</option>
            <option value="-">-</option>
        </select>
                                </div>            
                            <div class="form-group">
                                    <label for="fetal_heart">Fetal Heart</label>
                                    <select name="fetal_heart" id="fetal_heart" class="form-control" required onchange="toggleFetalHeartRateInput()">
                                    <option value="" disabled selected>Please select Fetal Heart</option>
                                        <option value="Positive (+)">Positive (+)</option>
                                        <option value="Negative (-)">Negative (-)</option>
                                    </select>
                                    </div>
                                    <div class="form-group" id="fetal_heart_rate_group" style="display: none;">
                            <label for="fetal_heart_rate">Enter Fetal Heart Rate</label>
                            <div class="col-sm-6">
                                <input name="fetal_heart_rate" type="number" id="fetal_heart_rate" class="form-control" placeholder="Enter fetal heart rate" min="0" step="0.01">
                            </div>
                        </div>
                        <input type="hidden" name="final_fetal_heart" id="final_fetal_heart">
                                <div class="form-group">
                                    <label for="movement">Movement</label>
                                    <select name="movement" id="movement" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="Have (+)">Have (+) </option>
            <option value="No (-)">No (-) </option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="remark">Any Remark</label>
                                    <input type="text" class="form-control" id="remark" name="remark" placeholder="Please enter Remark" required>
                                    <i class="fas fa-exclamation-circle" data-toggle="tooltip" data-placement="right" title="For example, high blood pressure, diabetes, asthma and so on..."></i>
                                </div>                          
                                <div class="form-group">
                                    <label for="image">Image</label>
                                    <input type="file" class="form-control" id="image" name="image">
                                </div>
                            <div class="form-group row mb-3">
     <!-- Checkbox to toggle blood sugar input field -->
     <label for="toggleCheckbox1" class="col-sm-3 col-form-label">Modified GTT</label>
     <div class="col-sm-6">
    <input type="checkbox" id="toggleCheckbox1" name="toggleCheckbox1" onclick="toggleInputField(1)"><br><br>
    </div>
    </div>

    <!-- Conditional input field, initially hidden -->
    <div id="conditionalInput1" class="col-sm-3 col-form-label" style="display: none;">
        <label for="blood_sugar">Blood Sugar</label><br>
        <label for="fbs1">FBS : </label>
        <input type="number" id="fbs1" name="fbs1" min="0" step="0.01"><br><br>
        <label for="hpp1">2HPP : </label>
        <input type="number" id="hpp1" name="hpp1" min="0" step="0.01"><br><br>
    </div>

 <!-- Section 2: Timing SMBG -->
 <div class="form-group row mb-3">
            <label for="toggleCheckbox2" class="col-sm-3 col-form-label">Timing SMBG</label>
            <div class="col-sm-6">
            <input type="checkbox" id="toggleCheckbox2" name="toggleCheckbox2" onclick="toggleInputField(2)"><br><br>
</div>
</div>
            <!-- Conditional input field, initially hidden -->
            <div id="conditionalInput2" class="col-sm-3 col-form-label" style="display: none;">
                <table>
                    <thead>
                        <tr>
                            <th>Measurement</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Pre Breakfast: </td>
                            <td><input type="number" id="pre_breakfast2" name="pre_breakfast2" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Pre/Post Lunch: </td>
                            <td><input type="number" id="pre_post_lunch2" name="pre_post_lunch2" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Pre/Post Dinner: </td>
                            <td><input type="number" id="pre_post_dinner2" name="pre_post_dinner2" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Prebed Dinner: </td>
                            <td><input type="number" id="prebed_dinner2" name="prebed_dinner2" min="0" step="0.01"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row mb-3">
                            <div class="col-sm-12">
                            <button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit"> Submit </button>
                            </div>
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<script>
    function toggleFetalHeartRateInput() {
    var selectElement = document.getElementById('fetal_heart');
    var fetalHeartRateGroup = document.getElementById('fetal_heart_rate_group');
    var fetalHeartRateInput = document.getElementById('fetal_heart_rate');
    var finalFetalHeartInput = document.getElementById('final_fetal_heart');

    if (selectElement.value === 'Positive (+)') {
        fetalHeartRateGroup.style.display = 'flex';
        finalFetalHeartInput.value = fetalHeartRateInput.value;
    } else {
        fetalHeartRateGroup.style.display = 'none';
        finalFetalHeartInput.value = selectElement.value;
    }
}

document.getElementById('fetal_heart_rate').addEventListener('input', function() {
    document.getElementById('final_fetal_heart').value = this.value;
});

    function toggleInputField(section) {
            var checkbox = document.getElementById('toggleCheckbox' + section);
            var conditionalInput = document.getElementById('conditionalInput' + section);
            if (checkbox.checked) {
                conditionalInput.style.display = 'block';
            } else {
                conditionalInput.style.display = 'none';
                // Optionally clear the input fields if hidden
                var inputs = conditionalInput.getElementsByTagName('input');
                for (var i = 0; i < inputs.length; i++) {
                    inputs[i].value = '';
                }
            }
        }

</script>


<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
<?php
// Include the database connection file
require('../Config.php');

// Define the query to fetch data from the 'appointment' table
$display_query = "SELECT appoint_id, start_time, end_time, availability FROM appointment";

// Execute the query
$results = $mysqli->query($display_query);

// Check if the query was successful
if ($results) {
    $data_arr = array();
    // Fetch data and format it
    while ($data_row = $results->fetch_assoc()) {
        // Format start and end times as ISO 8601 datetime strings
        $start_datetime = date('Y-m-d', strtotime($data_row['start_time'])) . 'T' . date('H:i:s', strtotime($data_row['start_time']));
        $end_datetime = date('Y-m-d', strtotime($data_row['end_time'])) . 'T' . date('H:i:s', strtotime($data_row['end_time']));
        
        $data_arr[] = array(
            'id' => $data_row['appoint_id'],
            'title' => 'Appointment Slot',
            'start' => $start_datetime,
            'end' => $end_datetime,
            'available' => (bool)$data_row['availability'] // Convert availability to boolean
        );
    }

    // Prepare the response
    $response = array(
        'status' => true,
        'msg' => 'Data fetched successfully!',
        'data' => $data_arr
    );
} else {
    // Query failed
    $response = array(
        'status' => false,
        'msg' => 'Error fetching appointments: ' . $mysqli->error
    );
}

// Encode response as JSON and output it
echo json_encode($response);

// Close the database connection
$mysqli->close();
?>

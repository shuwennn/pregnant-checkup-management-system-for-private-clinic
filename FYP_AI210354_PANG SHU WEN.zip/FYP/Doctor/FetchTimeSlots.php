<?php
// Include the database connection file
require('../Config.php');

// Check if date is provided
if (isset($_POST['date'])) {
    // Sanitize the date input
    $date = mysqli_real_escape_string($connection, $_POST['date']);

    // Establish database connection
    $connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

    // Check if the connection was successful
    if (!$connection) {
        echo json_encode(array('error' => 'Database connection failed: ' . mysqli_connect_error()));
        exit; // Exit the script if connection fails
    }

    // Prepare and execute SQL query to fetch available time slots
    $sql = "SELECT start_time, end_time
            FROM time_slots
            WHERE date = '$date' AND availability = 1
            ORDER BY CAST(start_time AS TIME) ASC";

    $result = mysqli_query($connection, $sql);

    if ($result) {
        // Fetch and return the available time slots as JSON
        $timeSlots = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $timeSlots[] = array(
                'start_time' => $row['start_time'],
                'end_time' => $row['end_time']
            );
        }
        echo json_encode($timeSlots);
    } else {
        // Handle database query error
        echo json_encode(array('error' => 'Error fetching time slots: ' . mysqli_error($connection)));
    }

    // Close the database connection
    mysqli_close($connection);
} else {
    // Handle missing date parameter
    echo json_encode(array('error' => 'Date parameter is missing'));
}
?>

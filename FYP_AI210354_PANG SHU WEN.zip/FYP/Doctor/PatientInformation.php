<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check if patient IC parameter is present in URL
if (isset($_GET['patient_ic'])) {
    $patient_ic = $_GET['patient_ic'];
} else {
    $patient_ic = "";
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to check if the patient IC exists in any of the three tables
function checkUniquePatientIC($conn, $patient_ic) {
    $query = "SELECT 1 FROM patient_basic_information WHERE patient_ic = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $patient_ic);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_patient_basic = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    $query = "SELECT 1 FROM nurse WHERE ic_no = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $patient_ic);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_nurse = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    $query = "SELECT 1 FROM doctor WHERE ic_no = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $patient_ic);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_doctor = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    // If any table has a record with this patient_ic, return false (not unique)
    if ($result_patient_basic > 0 || $result_nurse > 0 || $result_doctor > 0) {
        return false;
    }
    return true; // If no records found, it's unique
}

// Function to check if the email exists in any of the three tables
function checkUniqueEmail($conn, $email) {
    $query = "SELECT 1 FROM patient_basic_information WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $email);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_patient_basic = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    $query = "SELECT 1 FROM nurse WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $email);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_nurse = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    $query = "SELECT 1 FROM doctor WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
    }
    mysqli_stmt_bind_param($stmt, "s", $email);
    if (!mysqli_stmt_execute($stmt)) {
        die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
    }
    mysqli_stmt_store_result($stmt);
    $result_doctor = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);

    // If any table has a record with this email, return false (not unique)
    if ($result_patient_basic > 0 || $result_nurse > 0 || $result_doctor > 0) {
        return false;
    }
    return true; // If no records found, it's unique
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data and perform basic validation
    $patient_ic = $_POST['patient_ic'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $citizen = $_POST['citizen'];

    // Correctly capture the race field based on the selected option
    if (isset($_POST['race'])) {
        $race = $_POST['race'];
        if ($race === 'OTHER') {
            $race = isset($_POST['other_race']) ? $_POST['other_race'] : ""; // If "Other" is selected, use the value from the text input field
        }
    } else {
        $race = ""; // Default value if race is not set
    }

    $level_education = $_POST['level_education'];
    $job = $_POST['job'];
    $address = $_POST['address'];
    $handphone_no = $_POST['handphone_no'];
    $lnmp = $_POST['lnmp'];
    $edp = $_POST['edp'];
    $re_edd = $_POST['re_edd'];
    $gr = $_POST['gr'];
    $p = $_POST['p'];
    $born_date = $_POST['born_date'];
    $age = $_POST['age'];
    $risk_factors = isset($_POST['risk_factors']) ? $_POST['risk_factors'] : ""; // Capture risk factors correctly

    // Check uniqueness
    if (!checkUniquePatientIC($conn, $patient_ic)) {
        $message = "Patient IC already exists in the database.";
    } elseif (!checkUniqueEmail($conn, $email)) {
        $message = "Email already exists in the database.";
    } else {
        // Proceed with inserting/updating the record

        // Check if the patient exists
        $query = "SELECT * FROM patient_basic_information WHERE patient_ic=?";
        $stmt = mysqli_prepare($conn, $query);
        if ($stmt === false) {
            die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
        }
        mysqli_stmt_bind_param($stmt, "s", $patient_ic);
        if (!mysqli_stmt_execute($stmt)) {
            die('Execution error: ' . mysqli_stmt_error($stmt)); // Check for errors
        }
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            // Patient exists, show an error message as this is an insert page
            $message = "Patient with IC '$patient_ic' already exists. Cannot insert new record.";
        } else {
            // Patient does not exist, insert the patient IC into the database
            $insert_query = "INSERT INTO patient_basic_information (patient_ic, name, email, citizen, race, level_education, job, address, handphone_no, lnmp, edp, re_edd, gr, p, born_date, age, risk_factors, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'patient')";
            $stmt_insert = mysqli_prepare($conn, $insert_query);
            if ($stmt_insert === false) {
                die('MySQL prepare error: ' . mysqli_error($conn)); // Check for errors
            }
            mysqli_stmt_bind_param($stmt_insert, "sssssssssssssssss", $patient_ic, $name, $email, $citizen, $race, $level_education, $job, $address, $handphone_no, $lnmp, $edp, $re_edd, $gr, $p, $born_date, $age, $risk_factors);

            if (mysqli_stmt_execute($stmt_insert)) {
                $message = "Data stored in the database successfully.";
            } else {
               
   

                $message = "ERROR: Unable to execute $insert_query. " . mysqli_error($conn);
            }

            mysqli_stmt_close($stmt_insert);
        }

        mysqli_stmt_close($stmt);
    }
}

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Insert New Patient Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Patient Information Form -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Patient Information</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="patient_ic">Patient Identification Number</label>
                                    <input type="text" class="form-control" id="patient_ic" name="patient_ic" value="<?php echo $patient_ic; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Please enter patient's full name" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email"  placeholder="Please enter patient's email" required>
                                </div>
                                <div class="form-group">
                                    <label for="citizen">Citizen</label>
                                    <input type="text" class="form-control" id="citizen" name="citizen" placeholder="Please enter patient's citizen" required>
                                </div>
                                <div class="form-group">
                                    <label for="race">Race</label>
                                    <div>
                                        <input type="radio" id="malay" name="race" value="MALAY">
                                        <label for="malay">Malay</label><br>
                                        <input type="radio" id="chinese" name="race" value="CHINESE">
                                        <label for="chinese">Chinese</label><br>
                                        <input type="radio" id="india" name="race" value="INDIA">
                                        <label for="india">India</label><br>
                                        <input type="radio" id="otherRadio" name="race" value="OTHER">
                                        <label for="otherRadio">Other</label>
                                        <input name="other_race" type="text" id="otherInput" class="form-control" placeholder="Other..." style="display:none;">
                                    </div>
                                </div>
                                <script>
    // Get the radio button and input field
    var raceRadio = document.querySelectorAll('input[name="race"]');
    var otherInput = document.getElementById('otherInput');

    // Add event listener to each radio button
    raceRadio.forEach(function(radio) {
        radio.addEventListener('change', function() {
            // If the "Other" radio button is checked, show the input field, otherwise hide it
            if (radio.value === 'OTHER') {
                otherInput.style.display = 'block';
                otherInput.required = true; // Make the input field required
            } else {
                otherInput.style.display = 'none';
                otherInput.required = false; // Make the input field not required
            }
        });
    });
</script>
                                <div class="form-group">
                                    <label for="level_education">Level of Education</label>
                                    <select id="level_education" name="level_education" class="form-control" required>
                                    <option value="" disabled selected>Please select education level</option>   
                                    <option value="upsr">UPSR</option>
                                        <option value="pt3">PT3</option>
                                        <option value="spm">SPM</option>
                                        <option value="stpm">STPM</option>
                                        <option value="bachelor_degree">BACHELOR DEGREE</option>
                                        <option value="master_degree">MASTER DEGREE</option>
                                        <option value="phd">PHD</option>
                                        <option value="no">No Education</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="job">Job</label>
                                    <input type="text" class="form-control" id="job" name="job" placeholder="Please enter patient's job" required>
                                </div>
                                <div class="form-group">
                                    <label for="address">Home Address</label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Please enter patient's home address" required>
                                </div>
                                <div class="form-group">
                                    <label for="handphone_no">Handphone Number</label>
                                    <input type="text" class="form-control" id="handphone_no" name="handphone_no" placeholder="Please enter patient's handphone number" required>
                                </div>
                                <div class="form-group">
                                    <label for="lnmp">Last Normal Menstrual Period (LNMP)</label>
                                    <input type="date" class="form-control" id="lnmp" name="lnmp" placeholder="Please enter patient's last normal menstrual period" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edp">Estimated Date Delivery (EDP)</label>
                                    <input type="date" class="form-control" id="edp" name="edp" placeholder="Please enter patient's estimated date delivery" required>
                                </div>
                                <div class="form-group">
                                    <label for="re_edd">Revised Expected Date Delivery (RE EDD)</label>
                                    <input type="date" class="form-control" id="re_edd" name="re_edd" placeholder="Please enter patient's revised expected date delivery" required>
                                </div>
                                <div class="form-group">
                                    <label for="gr">Gravida</label>
                                    <input type="number" class="form-control" id="gr" name="gr" placeholder="Please enter patient's gravida" required>
                                </div>
                                <div class="form-group">
                                    <label for="p">Para</label>
                                    <input type="text" class="form-control" id="p" name="p" placeholder="Please enter patient's para" required>
                                </div>
                                <div class="form-group">
                                    <label for="born_date">Born Date</label>
                                    <input type="date" class="form-control" id="born_date" name="born_date" placeholder="Please enter patient's born_date" required>
                                </div>
                                <div class="form-group">
                                    <label for="age">Age</label>
                                    <input type="number" class="form-control" id="age" name="age" placeholder="Please enter patient's age" required>
                                </div>
                                <div class="form-group">
                                    <label for="risk_factors">Risk Factors</label><br>
                                    <textarea name="risk_factors" type="text" id="risk_factors" class="form-control" placeholder="Please enter patient's risk factors" required></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row mb-3">
                            <div class="col-sm-12">
                                <button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">Submit</button>
                                <a href="PatientHusband.php?patient_ic=<?php echo urlencode($patient_ic); ?>" class="btn btn-next">Next</a>
                            </div>
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->


<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
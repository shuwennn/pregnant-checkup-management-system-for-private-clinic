<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$message = "";


// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check if checkup_id parameter is provided
if (!isset($_GET['checkup_id'])) {
    echo "Invalid request. Please ensure that checkup_id parameter is provided.";
    exit();
}

$checkup_id = $_GET['checkup_id'];

// Retrieve current checkup information
$sql_select_checkup = "SELECT * FROM checkup_information WHERE checkup_id = ?";
$stmt_select_checkup = mysqli_prepare($conn, $sql_select_checkup);
if (!$stmt_select_checkup) {
    die("Prepare failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_select_checkup, "i", $checkup_id);
mysqli_stmt_execute($stmt_select_checkup);
$result_checkup = mysqli_stmt_get_result($stmt_select_checkup);

if (mysqli_num_rows($result_checkup) > 0) {
    $row = mysqli_fetch_assoc($result_checkup);

    // Fetch all fields including image
    $date = $row['date'];
    $poa_pog = $row['poa_pog'];
    $urin_alb = $row['urin_alb'];
    $urin_sugar = $row['urin_sugar'];
    $hb = $row['hb'];
    $weight = $row['weight'];
    $bp = $row['bp'];
    $pulse = $row['pulse'];
    $oed = $row['oed'];
    $fund_height = $row['fund_height'];
    $presentation = $row['presentation'];
    $fetal_heart = $row['fetal_heart'];
    $movement = $row['movement'];
    $remark = $row['remark'];
    $image = $row['image'];
    $fbs1 = $row['fbs1'];
    $hpp1 = isset($row['hpp1']) ? $row['hpp1'] : '';
    $pre_breakfast2 = $row['pre_breakfast2'];
    $pre_post_lunch2 = $row['pre_post_lunch2'];
    $pre_post_dinner2 = $row['pre_post_dinner2'];
    $prebed_dinner2 = $row['prebed_dinner2'];
    $lr_lk = $row['lr_lk'];
} else {
    $message = "No checkup records found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_checkup'])) {
    $date = $_POST['date'];
    $poa_pog = $_POST['poa_pog'];
    $urin_alb = $_POST['urin_alb'];
    $urin_sugar = $_POST['urin_sugar'];
    $hb = $_POST['hb'];
    $weight = $_POST['weight'];
    $bp = $_POST['bp'];
    $pulse = $_POST['pulse'];
    $oed = $_POST['oed'];
    $fund_height = $_POST['fund_height'];
    $presentation = $_POST['presentation'];
    $fetal_heart = $_POST['fetal_heart']; // Use fetal_heart field for combined value
    $movement = $_POST['movement'];
    $remark = $_POST['remark'];
    $fbs1 = $_POST['fbs1'];
    $hpp1 = $_POST['hpp1'];
    $pre_breakfast2 = $_POST['pre_breakfast2'];
    $pre_post_lunch2 = $_POST['pre_post_lunch2'];
    $pre_post_dinner2 = $_POST['pre_post_dinner2'];
    $prebed_dinner2 = $_POST['prebed_dinner2'];
    $lr_lk = $_POST['lr_lk'];

    // Handle file upload
    if (isset($_FILES['new_image']) && $_FILES['new_image']['error'] === UPLOAD_ERR_OK) {
        $temp_new_image = $_FILES['new_image']['tmp_name'];
        $new_image_name = basename($_FILES['new_image']['name']); // Make sure to use basename for security
        $new_image_path = "../path/to/uploaded/images/" . $new_image_name;

        // Ensure the upload directory exists
        if (!file_exists('../path/to/uploaded/images/')) {
            mkdir('../path/to/uploaded/images/', 0777, true);
        }

        // Move the uploaded file to the destination directory
        if (move_uploaded_file($temp_new_image, $new_image_path)) {
            // Update image path in the database
            $image = $new_image_name;
        } else {
            $message = "Failed to upload image.";
        }
    }

    // Determine which value to store in fetal_heart based on fetal_heart select
    if ($_POST['fetal_heart'] === 'Positive (+)') {
        $fetal_heart = 'Positive (+)'; // Set fetal_heart to 'Positive (+)'
        $fetal_heart_rate = $_POST['fetal_heart_rate'];
    } else {
        $fetal_heart = $_POST['fetal_heart']; // Set fetal_heart to the selected value
        $fetal_heart_rate = NULL; // Set fetal_heart_rate to NULL or any default value as per your database schema
    }

    // Prepare SQL update statement
    $sql_update = "UPDATE checkup_information SET date=?, poa_pog=?, urin_alb=?, urin_sugar=?, hb=?, weight=?, bp=?, pulse=?, oed=?, fund_height=?, presentation=?, fetal_heart=?, movement=?, remark=?, lr_lk=?, image=?, fbs1=?, hpp1=?, pre_breakfast2=?, pre_post_lunch2=?, pre_post_dinner2=?, prebed_dinner2=? WHERE checkup_id=?";

    $stmt_update = mysqli_prepare($conn, $sql_update);
    if (!$stmt_update) {
        die("Prepare failed: " . mysqli_error($conn));
    }

    // Bind parameters including the new image
    mysqli_stmt_bind_param($stmt_update, "ssssssssssssssssssssssi", $date, $poa_pog, $urin_alb, $urin_sugar, $hb, $weight, $bp, $pulse, $oed, $fund_height, $presentation, $fetal_heart, $movement, $remark, $lr_lk, $image, $fbs1, $hpp1, $pre_breakfast2, $pre_post_lunch2, $pre_post_dinner2, $prebed_dinner2, $checkup_id);

    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt_update)) {
        $message = "Data updated successfully.";
    } else {
        $message = "ERROR: Unable to execute $sql_update. " . mysqli_error($conn);
    }

    // Close statement
    mysqli_stmt_close($stmt_update);

    // Close connection
    mysqli_close($conn);
}
// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Update Patient's Checkup Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Update Patient's Checkup Information Form -->
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Checkup Details</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?checkup_id=' . urlencode($_GET['checkup_id']); ?>" method="post" enctype="multipart/form-data">
                    <div class="row">
                            <div class="col-md-6">
                        <div class="form-group row">
                            <label for="date" class="col-sm-3 col-form-label">Date</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($date); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="lr_lk" class="col-sm-3 col-form-label">Home Visits/Clinic Visits (LR/LK)</label>
                            <div class="col-sm-9">
                            <select name="lr_lk" id="lr_lk" class="form-control" required>
            <option value="" disabled>Please select result</option>
            <option value="LR (Home Visits)" <?php if ($lr_lk === 'LR (Home Visits)') echo 'selected'; ?>>LR (Home Visits)</option>
            <option value="LK (Clinic Visits)" <?php if ($lr_lk === 'LK (Clinic Visits)') echo 'selected'; ?>>LK (Clinic Visits)</option>
        </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="poa_pog" class="col-sm-3 col-form-label">Period of Amenorrhea & Gestation (Week/Day)</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="poa_pog" name="poa_pog" value="<?php echo htmlspecialchars($poa_pog); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="urin_alb" class="col-sm-3 col-form-label">Urine Albumin</label>
                            <div class="col-sm-9">
                            <select name="urin_alb" id="urin_alb" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="+" <?php if ($urin_alb === '+') echo 'selected'; ?>>+</option>
    <option value="++" <?php if ($urin_alb === '++') echo 'selected'; ?>>++</option>
    <option value="+++" <?php if ($urin_alb === '+++') echo 'selected'; ?>>+++</option>
    <option value="-" <?php if ($urin_alb === '-') echo 'selected'; ?>>-</option>
        </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="urin_sugar" class="col-sm-3 col-form-label">Urine Sugar</label>
                            <div class="col-sm-9">
                            <select name="urin_sugar" id="urin_sugar" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="Blue" <?php if ($urin_sugar === 'Blue') echo 'selected'; ?>>Blue</option>
    <option value="Green" <?php if ($urin_sugar === 'Green') echo 'selected'; ?>>Green</option>
    <option value="Dark Green" <?php if ($urin_sugar === 'Dark Green') echo 'selected'; ?>>Dark Green</option>
    <option value="Yellow" <?php if ($urin_sugar === 'Yellow') echo 'selected'; ?>>Yellow</option>
    <option value="Bick Red" <?php if ($urin_sugar === 'Bick Red') echo 'selected'; ?>>Bick Red</option>
    <option value="-" <?php if ($urin_sugar === '-') echo 'selected'; ?>>-</option>
        </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="hb" class="col-sm-3 col-form-label">Hemoglobin (gm%)</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="hb" name="hb" value="<?php echo htmlspecialchars($hb); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="weight" class="col-sm-3 col-form-label">Weight (kg)</label>
                            <div class="col-sm-9">
                                <input type="number" class="form-control" id="weight" name="weight" value="<?php echo htmlspecialchars($weight); ?>" min="0">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="bp" class="col-sm-3 col-form-label">Blood Pressure</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="bp" name="bp" value="<?php echo htmlspecialchars($bp); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="pulse" class="col-sm-3 col-form-label">Patient's Pulse (1 minute)</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="pulse" name="pulse" value="<?php echo htmlspecialchars($pulse); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="oed" class="col-sm-3 col-form-label">Oedema</label>
                            <div class="col-sm-9">
                            <select name="oed" id="oed" class="form-control" required>
            <option value="" disabled selected>Please select oedema</option>
            <option value="Positive (+)" <?php if ($oed === 'Positive (+)') echo 'selected'; ?>>Positive (+)</option>
    <option value="Negative (-)" <?php if ($oed === 'Negative (-)') echo 'selected'; ?>>Negative (-)</option>
    <option value="None" <?php if ($oed === 'None') echo 'selected'; ?>>None</option>
        </select>
                            </div>
                        </div>
                </div>
                

                <div class="col-lg-6">
                        <div class="form-group row">
                            <label for="fund_height" class="col-sm-3 col-form-label">Fundal Height</label>
                            <div class="col-sm-9">
                                <input type="number" class="form-control" id="fund_height" name="fund_height" value="<?php echo htmlspecialchars($fund_height); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="presentation" class="col-sm-3 col-form-label">Presentation</label>
                            <div class="col-sm-9">
                            <select name="presentation" id="presentation" class="form-control" required>
            <option value="" disabled selected>Please select presentation</option>
            <option value="Cephalic" <?php if ($presentation === 'Cephalic') echo 'selected'; ?>>Cephalic</option>
    <option value="Breech" <?php if ($presentation === 'Breech') echo 'selected'; ?>>Breech</option>
    <option value="Oblique" <?php if ($presentation === 'Oblique') echo 'selected'; ?>>Oblique</option>
    <option value="Transverse" <?php if ($presentation === 'Transverse') echo 'selected'; ?>>Transverse</option>
    <option value="-" <?php if ($presentation === '-') echo 'selected'; ?>>-</option>
        </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fetal_heart" class="col-sm-3 col-form-label">Fetal Heart</label>
                            <div class="col-sm-6">
                            <select name="fetal_heart" id="fetal_heart" class="form-control" required onchange="toggleFetalHeartRateInput()">
            <option value="" disabled>Please select result</option>
            <option value="Positive (+)" <?php if ($fetal_heart === 'Positive (+)') echo 'selected'; ?>>Positive (+)</option>
            <option value="Negative (-)" <?php if ($fetal_heart === 'Negative (-)' || $fetal_heart === 0) echo 'selected'; ?>>Negative (-)</option>
        </select>
                            </div>
                            </div>
                            <div class="form-group row " id="fetal_heart_rate_group" style="display: <?php echo ($fetal_heart === 'Positive (+)') ? 'flex' : 'none'; ?>">
    <label for="fetal_heart_rate" class="col-sm-3 col-form-label">Enter Fetal Heart Rate</label>
    <div class="col-sm-6">
        <input name="fetal_heart_rate" type="number" id="fetal_heart_rate" class="form-control" value="<?php echo ($fetal_heart === 'Positive (+)') ? htmlspecialchars($fetal_heart_rate) : htmlspecialchars($fetal_heart); ?>" min="0">
    </div>
</div>

<input type="hidden" name="final_fetal_heart" id="final_fetal_heart" value="<?php echo ($fetal_heart === 'Positive (+)') ? 'Positive (+)' : htmlspecialchars($fetal_heart); ?>">
                        <div class="form-group row">
                            <label for="movement" class="col-sm-3 col-form-label">Movement</label>
                            <div class="col-sm-9">
                            <select name="movement" id="movement" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="Have (+)" <?php if ($movement === 'Have (+)') echo 'selected'; ?>>Have (+)</option>
    <option value="No (-)" <?php if ($movement === 'No (-)') echo 'selected'; ?>>No (-)</option>
        </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="remark" class="col-sm-3 col-form-label">Any Remark</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="remark" name="remark" value="<?php echo htmlspecialchars($remark); ?>">
                            </div>
                            <i class="fas fa-exclamation-circle" data-toggle="tooltip" data-placement="right" title="For example, high blood pressure, diabetes, asthma and so on..."></i>
                        </div>
                        <div class="form-group row mb-3">
    <label for="existing_image" class="col-sm-3 col-form-label">Image</label>
    <div class="col-sm-6">
    <?php
// Retrieve the BLOB data from the database
$image_blob = $row['image'];

// Check if the BLOB data is not empty
if (!empty($image_blob)) {
    // Convert the BLOB data to base64 encoding
    $image_data = base64_encode($image_blob);

    // Generate the data URI for embedding the image
    $image_src = 'data:image/jpeg;base64,' . $image_data;

    // Display the image
    echo "<img src='$image_src' alt='Latest Checkup Image' style='max-width: 80%; height: 80%;'>";
} else {
    // If the BLOB data is empty, display a placeholder message
    echo "<p>No image available</p>";
}

?>
    </div>
</div>

<div class="form-group row mb-3">
     <!-- Checkbox to toggle blood sugar input field -->
     <label for="toggleCheckbox1">Modified GTT</label>
    <input type="checkbox" id="toggleCheckbox1" name="toggleCheckbox1" onclick="toggleInputField(1)"><br><br>

    <!-- Conditional input field, initially hidden -->
    <div id="conditionalInput1" style="display: none;">
        <label for="blood_sugar">Blood Sugar</label>
        <label for="fbs1">FBS : </label>
        <input type="number" id="fbs1" name="fbs1" value="<?php echo htmlspecialchars($fbs1); ?>" min="0" step="0.01"><br><br>
        <label for="hpp1">2HPP : </label>
        <input type="number" id="hpp1" name="hpp1" value="<?php echo htmlspecialchars($hpp1); ?>" min="0" step="0.01"><br><br>
    </div>
</div>

 <!-- Section 2: Timing SMBG -->
 <div class="form-group row mb-3">
            <label for="toggleCheckbox2">Timing SMBG</label>
            <input type="checkbox" id="toggleCheckbox2" name="toggleCheckbox2" onclick="toggleInputField(2)"><br><br>

            <!-- Conditional input field, initially hidden -->
            <div id="conditionalInput2" style="display: none;">
                <table>
                    <thead>
                        <tr>
                            <th>Measurement</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Pre Breakfast</td>
                            <td><input type="number" id="pre_breakfast2" name="pre_breakfast2" value="<?php echo htmlspecialchars($pre_breakfast2); ?>" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Pre/Post Lunch</td>
                            <td><input type="number" id="pre_post_lunch2" name="pre_post_lunch2" value="<?php echo htmlspecialchars($pre_post_lunch2); ?>" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Pre/Post Dinner</td>
                            <td><input type="number" id="pre_post_dinner2" name="pre_post_dinner2" value="<?php echo htmlspecialchars($pre_post_dinner2); ?>" min="0" step="0.01"></td>
                        </tr>
                        <tr>
                            <td>Prebed Dinner</td>
                            <td><input type="number" id="prebed_dinner2" name="prebed_dinner2" value="<?php echo htmlspecialchars($prebed_dinner2); ?>" min="0" step="0.01"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-sm-12 text-center">
                                <button type="submit" class="btn btn-primary" name="update_checkup">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<script>
     function toggleFetalHeartRateInput() {
        var fetalHeartSelect = document.getElementById("fetal_heart");
        var fetalHeartRateGroup = document.getElementById("fetal_heart_rate_group");
        var fetalHeartRateInput = document.getElementById("fetal_heart_rate");
        var finalFetalHeartInput = document.getElementById("final_fetal_heart");

        if (fetalHeartSelect.value === "Positive (+)") {
            fetalHeartRateGroup.style.display = "flex";
            fetalHeartRateInput.required = true;
            finalFetalHeartInput.value = "Positive (+)"; // Set final value to positive
        } else {
            fetalHeartRateGroup.style.display = "none";
            fetalHeartRateInput.required = false;
            fetalHeartRateInput.value = ""; // Clear the input value
            finalFetalHeartInput.value = fetalHeartSelect.value; // Set the final value to the selected fetal heart value
        }
    }

    // Initialize the fetal heart rate input on page load with existing value
    window.onload = function() {
        toggleFetalHeartRateInput();
    };


    function toggleInputField(section) {
            var checkbox = document.getElementById('toggleCheckbox' + section);
            var conditionalInput = document.getElementById('conditionalInput' + section);
            if (checkbox.checked) {
                conditionalInput.style.display = 'block';
            } else {
                conditionalInput.style.display = 'none';
                // Optionally clear the input fields if hidden
                var inputs = conditionalInput.getElementsByTagName('input');
                for (var i = 0; i < inputs.length; i++) {
                    inputs[i].value = '';
                }
            }
        }

</script>


<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
<?php
// Include the database connection file
require('../Config.php');

// Check if appointment ID is provided
if (isset($_POST['appointmentId'])) {
    // Establish database connection
    $connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

    // Check if the connection was successful
    if (!$connection) {
        die(json_encode(array('error' => 'Database connection failed: ' . mysqli_connect_error())));
    }

    // Sanitize and fetch appointment ID
    $appointmentId = mysqli_real_escape_string($connection, $_POST['appointmentId']);

    // Fetch appointment details from the database
    $sql = "SELECT patient_ic, appoint_id, date, start_time, end_time, remark FROM appointment WHERE appoint_id = '$appointmentId'";
    $result = mysqli_query($connection, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $appointment = mysqli_fetch_assoc($result);
        echo json_encode($appointment);
    } else {
        echo json_encode(array('error' => 'Appointment not found'));
    }

    // Close the database connection
    mysqli_close($connection);
} else {
    echo json_encode(array('error' => 'Appointment ID is missing'));
}
?>

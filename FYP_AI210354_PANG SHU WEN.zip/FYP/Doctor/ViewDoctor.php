<?php
session_start();

require('../Config.php');
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'doctor'
if ($_SESSION['role'] !== 'doctor') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Fetch doctor details based on the logged-in user's email
$email = $_SESSION['email'];

$sql_select_doctor = "SELECT * FROM doctor WHERE email = ?";
$stmt_select_doctor = mysqli_prepare($conn, $sql_select_doctor);
if (!$stmt_select_doctor) {
    die("Prepare failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_select_doctor, "s", $email);
mysqli_stmt_execute($stmt_select_doctor);

$result_doctor = mysqli_stmt_get_result($stmt_select_doctor);

if ($row_doctor = mysqli_fetch_assoc($result_doctor)) {
    // Fetch doctor information
    $dr_id = $row_doctor['dr_id'];
    $full_name = $row_doctor['full_name'];
    $email = $row_doctor['email'];
    $handphone_no = $row_doctor['handphone_no'];
    $address_home = $row_doctor['address_home'];
    $ic_no = $row_doctor['ic_no'];

    // Set doctor_ic in session
    $_SESSION['doctor_ic'] = $ic_no;
} else {
    $message = "No doctor found with the given email.";
}

mysqli_stmt_close($stmt_select_doctor);

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Your Details Information</h1>

    <?php if ($message != ""): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php else: ?>
        <!-- Doctor Information -->
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Doctor Information</h6>
                    </div>
                    <div class="card-body">
                    <div class="profile-picture">
                            <!-- Replace this with your profile picture implementation -->
                            <img src="../img/doctor.webp" alt="Profile Picture" style="max-width: 40%; height: 40%; display: block; border-radius: 50%; margin-bottom: 5%;">
                        </div>
                        <table class="table table-bordered" width="100%" cellspacing="0">
                        <tr>
                                <th>Doctor ID</th>
                                <td><?php echo $dr_id; ?></td>
                            </tr>    
                        <tr>
                                <th>Full Name</th>
                                <td><?php echo $full_name; ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo $email; ?></td>
                            </tr>
                            <tr>
                                <th>Handphone Number</th>
                                <td><?php echo $handphone_no; ?></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><?php echo $address_home; ?></td>
                            </tr>
                            <tr>
                                <th>IC Number</th>
                                <td><?php echo $ic_no; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>

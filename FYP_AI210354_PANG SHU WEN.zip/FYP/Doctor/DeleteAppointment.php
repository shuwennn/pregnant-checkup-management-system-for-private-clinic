<?php
session_start();

// Include the database connection file
require('../Config.php');

// Establish database connection
$connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Initialize status message
$status_message = "";

// Handle appointment deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['appoint_id'])) {
    $appoint_id = $_POST['appoint_id'];

    // Debug output to check the value of appoint_id
    $debug_output = "Appoint ID: " . $appoint_id;

    // Perform deletion query
    $delete_query = "DELETE FROM appointment WHERE appoint_id = ?";
    $stmt = mysqli_prepare($connection, $delete_query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $appoint_id);
        if (mysqli_stmt_execute($stmt)) {
            // Deletion successful
            $status_message = "Appointment deleted successfully. " . $debug_output;
        } else {
            // Deletion failed
            $status_message = "Failed to delete appointment: " . mysqli_error($connection) . ". " . $debug_output;
        }
        mysqli_stmt_close($stmt);
    } else {
        $status_message = "Failed to prepare statement: " . mysqli_error($connection) . ". " . $debug_output;
    }
} else {
    // If appoint_id is not set, indicate an error
    $status_message = "Error: appoint_id not set or invalid request.";
}

// Close the database connection
mysqli_close($connection);

// Redirect back to AppointmentList.php with status message
header("Location: AppointmentList.php?status=" . urlencode($status_message));
exit();
?>

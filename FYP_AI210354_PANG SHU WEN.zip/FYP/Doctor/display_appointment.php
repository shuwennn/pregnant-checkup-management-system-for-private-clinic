<?php
// Establish database connection
$mysqli = new mysqli("localhost", "root", "", "pregnant_system");

// Check connection
if ($mysqli->connect_error) {
    $response = array(
        'status' => false,
        'msg' => 'Database connection failed: ' . $mysqli->connect_error
    );
    echo json_encode($response);
    exit;
}

// Define the query to fetch data from the 'appointment' table
$display_query = "SELECT appoint_id, start_time, end_time FROM appointment";

// Execute the query
$results = $mysqli->query($display_query);

// Check if the query was successful
if ($results) {
    $data_arr = array();
    // Fetch data and format it
    while ($data_row = $results->fetch_assoc()) {
        $data_arr[] = array(
            'id' => $data_row['appoint_id'],
            'title' => 'Appointment Slot',
            'start' => $data_row['start_time'],
            'end' => $data_row['end_time'],
            'available' => true // Assuming all slots are initially available
        );
    }

    // Prepare the response
    $response = array(
        'status' => true,
        'msg' => 'Data fetched successfully!',
        'data' => $data_arr
    );
} else {
    // Query failed
    $response = array(
        'status' => false,
        'msg' => 'Error fetching appointments: ' . $mysqli->error
    );
}

// Encode response as JSON and output it
echo json_encode($response);

// Close the database connection
$mysqli->close();
?>

<?php
// Include necessary files and initiate session
include('../Config.php');
session_start();

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor' or 'head_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Fetch the current user's data based on their role
    $userEmail = $_SESSION['email'];
    $userRole = $_SESSION['role'];

    switch ($userRole) {
        case 'head_nurse':
            $table = 'nurse';
            $idField = 'email';
            break;
        case 'doctor':
            $table = 'doctor';
            $idField = 'email';
            break;
        default:
            die("Unauthorized user role.");
    }

    // Construct query to fetch current password
    $query = "SELECT password FROM $table WHERE $idField = ?";
    
    // Prepare statement
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, "s", $userEmail);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        die("Error fetching user data: " . mysqli_error($mysqli));
    }

    $row = mysqli_fetch_assoc($result);

    // Check if new password and confirm password match
    if ($newPassword == $confirmPassword) {
        // Hash the new password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update the password in the database
        $updateQuery = "UPDATE $table SET password = ? WHERE $idField = ?";
        
        // Prepare update statement
        $updateStmt = mysqli_prepare($mysqli, $updateQuery);
        mysqli_stmt_bind_param($updateStmt, "ss", $hashedPassword, $userEmail);

        if (mysqli_stmt_execute($updateStmt)) {
            echo "Password changed successfully!";
        } else {
            echo "Error updating password: " . mysqli_error($mysqli);
        }
    } else {
        echo "New password and confirm password do not match.";
    }
}
?>

<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
            </div>
            <div class="card-body">
                <form method="post" action="ChangePassword.php">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="new_password">New Password:</label>
                                <input type="password" id="new_password" name="new_password" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password:</label>
                                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>

<?php
// Start session
session_start();

// Include the database connection file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is either 'doctor', 'head_nurse', or 'general_nurse'
if ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'head_nurse' && $_SESSION['role'] !== 'general_nurse') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

$message = "";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve 'patient_ic' from the primary key of the patient_basic_information table
    if(isset($_POST['patient_ic']) && !empty($_POST['patient_ic'])) {
        $patient_ic = $_POST['patient_ic'];
    } else {
        die("ERROR: Patient IC not provided.");
    }

    // Retrieve form data and handle undefined index errors
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $height = isset($_POST['height']) ? $_POST['height'] : '';
    $blood_group = isset($_POST['blood_group']) ? $_POST['blood_group'] : '';
    $vdrl = isset($_POST['vdrl']) ? $_POST['vdrl'] : '';
    $hb = isset($_POST['hb']) ? $_POST['hb'] : '';
    $hbs_ag = isset($_POST['hbs_ag']) ? $_POST['hbs_ag'] : '';
    $hb_antibody = isset($_POST['hb_antibody']) ? $_POST['hb_antibody'] : '';
    $rubella_antibody = isset($_POST['rubella_antibody']) ? $_POST['rubella_antibody'] : '';
    $hiv_1 = isset($_POST['hiv_1']) ? $_POST['hiv_1'] : '';
    $hiv_2 = isset($_POST['hiv_2']) ? $_POST['hiv_2'] : '';
    $att = isset($_POST['att']) ? $_POST['att'] : '';
    $others = isset($_POST['others']) ? $_POST['others'] : '';

    // Generate test_id
    $test_id = generateTestID();

    // Prepare and execute the SQL query for insertion
    $sql_insert = "INSERT INTO antenatal_screening_test (test_id, patient_ic, date, height, blood_group, vdrl, hb, hbs_ag, hb_antibody, rubella_antibody, hiv_1, hiv_2, att, others) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = mysqli_prepare($mysqli, $sql_insert);
    if (!$stmt_insert) {
        die("Prepare failed: " . mysqli_error($mysqli));
    }
    mysqli_stmt_bind_param($stmt_insert, "isssssssssssss", $test_id, $patient_ic, $date, $height, $blood_group, $vdrl, $hb, $hbs_ag, $hb_antibody, $rubella_antibody, $hiv_1, $hiv_2, $att, $others);
    if (mysqli_stmt_execute($stmt_insert)) {
        $message = "Data stored in the database successfully.";
    } else {
        $message = "ERROR: Unable to execute $sql_insert. " . mysqli_error($mysqli);
    }
    mysqli_stmt_close($stmt_insert);
} 

// Function to generate a 5-digit test ID
function generateTestID() {
    return mt_rand(10000, 99999);
}
// Include header and navbar files
include('../Doctor/includes/header.php');
include('../Doctor/includes/navbar.php');
include('../Doctor/includes/topbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Insert Antenatal Screening Test Information</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info mt-2">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Antenatal Screening Test Form -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Antenatal Screening Test Information</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <input type="hidden" name="patient_ic" value="<?php echo isset($_GET['patient_ic']) ? htmlspecialchars($_GET['patient_ic']) : ''; ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="date">Date</label>
                                    <input type="date" class="form-control" id="date" name="date" placeholder="Please enter date" required>
                                </div>
                                <div class="form-group">
                                    <label for="height">Height</label>
                                    <input type="text" class="form-control" id="height" name="height" placeholder="Please enter height" required>
                                </div>
                                <div class="form-group">
                                    <label for="blood_group">Blood Group</label>
                                    <input type="radio" id="A+" name="blood_group" value="A+">
<label for="A+">A+</label><br>
<input type="radio" id="A-" name="blood_group" value="A-">
<label for="A-">A-</label><br>
<input type="radio" id="B+" name="blood_group" value="B+">
<label for="B+">B+</label><br>
<input type="radio" id="AB+" name="blood_group" value="AB+">
<label for="AB+">AB+</label><br>
<input type="radio" id="AB-" name="blood_group" value="AB-">
<label for="AB-">AB-</label><br>
<input type="radio" id="O+" name="blood_group" value="O+">
<label for="O+">O+</label><br>
<input type="radio" id="O-" name="blood_group" value="O-">
<label for="O-">O-</label><br>
                                </div>
                                <div class="form-group">
                                    <label for="vdrl">Venereal Disease Research Laboratory (VDRL)</label>
                                    <select name="vdrl" id="vdrl" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive">positive</option>
            <option value="negative">negative</option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="hb">Hemoglobin (g/dL)</label>
                                    <input type="text" class="form-control" id="hb" name="hb" placeholder="Please enter hb" required>
                                </div>
                                <div class="form-group">
                                    <label for="hbs_ag">Hepatitis B Surface Antigen</label>
                                    <select name="hbs_ag" id="hbs_ag" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive/reactive">positive/reactive</option>
            <option value="negative/nonreactive">negative/nonreactive</option>
        </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hb_antibody">Hepatitis B Surface Antibody</label>
                                    <select name="hb_antibody" id="hb_antibody" class="form-control" required>
            <option value="" disabled selected>Please select result</option>
            <option value="positive/reactive">positive/reactive</option>
            <option value="negative/nonreactive">negative/nonreactive</option>
        </select>
                                </div>
                                <div class="form-group">
                                    <label for="rubella_antibody">Rubella Antibody</label>
                                    <input type="text" class="form-control" id="rubella_antibody" name="rubella_antibody" placeholder="Please enter rubella antibody" required>
                                </div>
                                <div class="form-group">
                                    <label for="hiv_1">Human Immunodeficiency Virus 1</label>
                                    <input type="text" class="form-control" id="hiv_1" name="hiv_1" placeholder="Please enter hiv 1" required>
                                </div>
                                <div class="form-group">
                                    <label for="hiv_2">Human Immunodeficiency Virus 2</label>
                                    <input type="text" class="form-control" id="hiv_2" name="hiv_2"  placeholder="Please enter hiv 2" required>
                                </div>
                                <div class="form-group">
                                    <label for="att">Anti Tetanus Toxoid</label>
                                    <input type="text" class="form-control" id="att" name="att" placeholder="Please enter att" required>
                                </div>
                                <div class="form-group">
                                    <label for="others">Others</label>
                                    <textarea class="form-control" id="others" name="others" rows="5" placeholder="Please enter other remarks..."></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row mb-3">
                            <div class="col-sm-12">
                                <button type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">Submit</button>
                                
                            </div>
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Page Content -->

<?php
    include('../Doctor/includes/footer.php');
    include('../Doctor/includes/scripts.php');
    ?>
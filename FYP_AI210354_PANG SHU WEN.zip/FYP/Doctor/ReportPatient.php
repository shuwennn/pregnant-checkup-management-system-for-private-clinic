<?php

ob_start(); // Start output buffering
require('../fpdf/fpdf.php');
require('../Config.php');

// Custom PDF class with background image
class PDF extends FPDF
{
    // Override AddPage method to add background image
    function AddPage($orientation = '', $size = '', $rotation = 0)
    {
        parent::AddPage($orientation, $size, $rotation);
        $this->SetBackgroundImage();
    }

    // Method to set background image
    function SetBackgroundImage()
    {
        $imagePath = '../img/logo-2.png';
        if (file_exists($imagePath)) {
            list($imageWidth, $imageHeight) = getimagesize($imagePath);
            $maxWidth = $this->GetPageWidth(); // Maximum width of the background image
            $maxHeight = $this->GetPageHeight(); // Maximum height of the background image
            
            // Adjust these scaling factors as needed
            $scaleWidth = 0.5; // Scale width as 50% of the page width
            $scaleHeight = 0.5; // Scale height as 50% of the page height

            // Calculate scaled dimensions
            $scaledWidth = $maxWidth * $scaleWidth;
            $scaledHeight = $maxHeight * $scaleHeight;

            $centerX = ($this->GetPageWidth() - $scaledWidth) / 2;
            $centerY = ($this->GetPageHeight() - $scaledHeight) / 2;

            $this->Image($imagePath, $centerX, $centerY, $scaledWidth, $scaledHeight);
        } else {
            die('Background image not found. Please check the file path.');
        }
    }
}

// Check if patient_ic and checkup_date are provided in the URL
if (isset($_GET['patient_ic']) && isset($_GET['checkup_date'])) {
    // Get the patient_ic and checkup_date from the URL parameters
    $patient_ic = $_GET['patient_ic'];
    $checkup_date = $_GET['checkup_date'];

    // Add error handling for database connection
    $conn = mysqli_connect("localhost", "root", "", "pregnant_system");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Query database for patient basic information
    $sql_patient = "SELECT name, patient_ic FROM patient_basic_information WHERE patient_ic = '$patient_ic'";
    $result_patient = mysqli_query($conn, $sql_patient);
    if (!$result_patient) {
        die("Error in SQL query: " . mysqli_error($conn));
    }

    // Query database for checkup information
    $sql_checkup = "SELECT * FROM checkup_information WHERE patient_ic = '$patient_ic' AND date = '$checkup_date'";
    $result_checkup = mysqli_query($conn, $sql_checkup);
    if (!$result_checkup) {
        die("Error in SQL query: " . mysqli_error($conn));
    }

    // Fetch patient information
    $patient_info = mysqli_fetch_assoc($result_patient);
    $checkup_info = mysqli_fetch_assoc($result_checkup);

    // Create a new instance of the custom PDF class
    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->SetFont('Times', '', 12);

    // Output the logo and name
    $logoWidth = 5; // Width of the logo
    $logoPath = '../img/logo-1.png';
    $clinicName = 'Pusat Pakar Wanita Dan Perbidanan Johor';

    // Calculate positions
    $startX = ($pdf->GetPageWidth() - ($logoWidth + $pdf->GetStringWidth($clinicName))) / 2;
    $pdf->SetXY($startX, 10);
    $pdf->Image($logoPath, $startX, 10, $logoWidth);
    $pdf->SetXY($startX + $logoWidth + 3, 10);
    $pdf->Cell($pdf->GetStringWidth($clinicName), 10, $clinicName, 0, 0, 'L');

    // Draw a box for patient information
    $pdf->Rect(10, 25, 80, 50); // x, y, width, height

    // Output patient information inside the box
    $pdf->SetXY(15, 30);
    $pdf->Cell(0, 10, 'Name: ' . $patient_info['name'], 0, 1);
    $pdf->SetXY(15, 40);
    $pdf->Cell(0, 10, 'IC: ' . $patient_info['patient_ic'], 0, 1);
    $pdf->SetXY(15, 50);
    $pdf->Cell(0, 10, 'Checkup ID: ' . $checkup_info['checkup_id'], 0, 1);
    $pdf->SetXY(15, 60);
    $pdf->Cell(0, 10, 'Date: ' . $checkup_info['date'], 0, 1);

    // Draw a horizontal line below the box and patient information
    $pdf->Line(10, 85, $pdf->GetPageWidth() - 10, 85);

    // Define reference ranges for tests
    $referenceRanges = array(
        'LR/LK:' => array('min' => '-', 'max' => '-'),
        'POA/POG:' => array('min' => 0, 'max' => '-'),
        'Urin Albumin:' => array('min' => 0, 'max' => 30),
        'Urin Sugar:' => array('min' => 0, 'max' => 5.5),
        'Haemoglobin:' => array('min' => 12, 'max' => 16),
        'Weight:' => array('min' => '-', 'max' => '-'),
        'Blood Pressure:' => array('min' => '-', 'max' => '-'),
        'Pulse:' => array('min' => 60, 'max' => 100),
        'Oedema:' => array('min' => '-', 'max' => '-'),
        'Pregnant Period:' => array('min' => '-', 'max' => '-'),
        'Fundal Height:' => array('min' => '-', 'max' => '-'),
        'Presentation:' => array('min' => '-', 'max' => '-'),
        'Fetal Heart:' => array('min' => 110, 'max' => 160),
        'Movement Baby:' => array('min' => '-', 'max' => '-'),
        'Remark:' => array('min' => '-', 'max' => '-'),
        'FBS:' => array('min' => 70, 'max' => 100),
        '2HPP:' => array('min' => 70, 'max' => 140),
        'Pre Breakfast:' => array('min' => 70, 'max' => 100),
        'Pre/Post Lunch:' => array('min' => 70, 'max' => 140),
        'Pre/Post Dinner:' => array('min' => 70, 'max' => 140),
        'Prebed Dinner:' => array('min' => 70, 'max' => 100),
    );
    
    
    

    // Function to determine status based on reference range
    function getStatus($value, $range) {
        if ($range['min'] == '-' || $range['max'] == '-') {
            return 'N/A';
        }
        if ($value >= $range['min'] && $value <= $range['max']) {
            return 'Healthy';
        }
        return 'Not Healthy';
    }

    // Output checkup information in the PDF in a table format
    if ($checkup_info) {
        // Move the cursor to the new position for checkup information
        $pdf->SetXY(10, 95);

        // Define table headings
        $pdf->SetFont('Times', 'B', 12); // Set bold font for headings
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(100, 10, 'Test Name', 0);
        $pdf->Cell(30, 10, 'Result', 0);
        $pdf->Cell(20, 10, 'Unit', 0);
        $pdf->Cell(10, 10, 'Range', 0);
        $pdf->Cell(30, 10, 'Status', 0, 1, 'R');

        // Set regular font for data rows
        $pdf->SetFont('Times', '', 12);

        // Define data for the table
        $data = array(
            array('LR/LK:', $checkup_info["lr_lk"], '-', getStatus($checkup_info["lr_lk"], $referenceRanges['LR/LK:'])),
            array('POA/POG:', $checkup_info["poa_pog"], 'weeks', getStatus($checkup_info["poa_pog"], $referenceRanges['POA/POG:'])),
            array('Urin Albumin:', $checkup_info["urin_alb"], 'g/L', getStatus($checkup_info["urin_alb"], $referenceRanges['Urin Albumin:'])),
            array('Urin Sugar:', $checkup_info["urin_sugar"], 'mmol/L', getStatus($checkup_info["urin_sugar"], $referenceRanges['Urin Sugar:'])),
            array('Haemoglobin:', $checkup_info["hb"], 'g/dL', getStatus($checkup_info["hb"], $referenceRanges['Haemoglobin:'])),
            array('Weight:', $checkup_info["weight"], 'kg', getStatus($checkup_info["weight"], $referenceRanges['Weight:'])),
            array('Blood Pressure:', $checkup_info["bp"], 'mmHg', getStatus($checkup_info["bp"], $referenceRanges['Blood Pressure:'])),
            array('Pulse:', $checkup_info["pulse"], 'bpm', getStatus($checkup_info["pulse"], $referenceRanges['Pulse:'])),
            array('Oedema:', $checkup_info["oed"], '', getStatus($checkup_info["oed"], $referenceRanges['Oedema:'])),
            array('Fundal Height:', $checkup_info["fund_height"], 'cm', getStatus($checkup_info["fund_height"], $referenceRanges['Fundal Height:'])),
            array('Presentation:', $checkup_info["presentation"], '-', getStatus($checkup_info["presentation"], $referenceRanges['Presentation:'])),
            array('Fetal Heart:', $checkup_info["fetal_heart"], 'bpm', getStatus($checkup_info["fetal_heart"], $referenceRanges['Fetal Heart:'])),
            array('Movement Baby:', $checkup_info["movement"], '-', getStatus($checkup_info["movement"], $referenceRanges['Movement Baby:'])),
            array('Remark:', $checkup_info["remark"], '-', getStatus($checkup_info["remark"], $referenceRanges['Remark:'])),
            array('FBS:', $checkup_info["fbs1"], 'mg/dL', getStatus($checkup_info["fbs1"], $referenceRanges['FBS:'])),
            array('2HPP:', $checkup_info["hpp1"], 'mg/dL', getStatus($checkup_info["hpp1"], $referenceRanges['2HPP:'])),
            array('Pre Breakfast:', $checkup_info["pre_breakfast2"], 'mg/dL', getStatus($checkup_info["pre_breakfast2"], $referenceRanges['Pre Breakfast:'])),
            array('Pre/Post Lunch:', $checkup_info["pre_post_lunch2"], 'mg/dL', getStatus($checkup_info["pre_post_lunch2"], $referenceRanges['Pre/Post Lunch:'])),
            array('Pre/Post Dinner:', $checkup_info["pre_post_dinner2"], 'mg/dL', getStatus($checkup_info["pre_post_dinner2"], $referenceRanges['Pre/Post Dinner:'])),
            array('Prebed Dinner:', $checkup_info["prebed_dinner2"], 'mg/dL', getStatus($checkup_info["prebed_dinner2"], $referenceRanges['Prebed Dinner:']))
        );
        

         // Output the table
        foreach ($data as $row) {
            $pdf->Cell(100, 10, $row[0], 0);
            $pdf->Cell(30, 10, $row[1], 0);
            $pdf->Cell(20, 10, $row[2], 0);
            $pdf->Cell(10, 10, $referenceRanges[$row[0]]['min'].'-'.$referenceRanges[$row[0]]['max'], 0);
            $pdf->Cell(30, 10, $row[3], 0, 1, 'R');
        }
    } else {
        // If no checkup records found
        echo "No checkup records found for this patient";
    }

    // Close database connection
    mysqli_close($conn);

    // Output the PDF
    $pdf->Output();
} else {
    // If patient_ic is not provided in the URL, display an error message
    echo "No patient identification number provided";
}

ob_end_flush(); // Flush the output buffer
?>

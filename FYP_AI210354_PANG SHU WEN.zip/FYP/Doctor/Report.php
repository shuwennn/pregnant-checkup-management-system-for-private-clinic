<?php

require('../fpdf/fpdf.php'); // Include the FPDF library
require('../Config.php'); 

// Custom PDF class
class PDF extends FPDF
{
    // Header
    function Header()
    {
        // Logo
        $this->Image('../img/logo-1.png', 60, 6, 10);
        // Clinic name
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(60);
        $this->Cell(0, 10, 'Pusat Pakar Wanita Dan Perbidanan Johor', 0, 1, 'L');
        // Horizontal line
        $this->Line(10, 25, 200, 25);
        // Line break
        $this->Ln(10);
    }

    // Footer
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Select font
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

// Database connection
$conn = mysqli_connect("localhost", "root", "", "pregnant_system");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve the latest month and year from the checkup_information table
$sql_latest_date = "SELECT MAX(date) AS latest_date FROM checkup_information";
$result_latest_date = mysqli_query($conn, $sql_latest_date);
$row_latest_date = mysqli_fetch_assoc($result_latest_date);
$latest_date = $row_latest_date['latest_date'];

// Determine the month and year from the latest date
$month = date('m', strtotime($latest_date)); // Get the month (e.g., 01 for January)
$year = date('Y', strtotime($latest_date)); // Get the year

// Define report data as an associative array
$report_data = array(
    "Number of Doctors:" => getDoctorCount($conn),
    "Number of Nurses:" => getNurseCount($conn),
    "Number of Patients:" => getPatientCount($conn),
    "Number of Checkups for " . date('F Y', strtotime($latest_date)) . ":" => getCheckupCount($conn, $month, $year)
);


// Close database connection
mysqli_close($conn);

// Function to get the number of checkups for a specific month and year from the database
function getCheckupCount($conn, $month, $year)
{
    $start_date = "$year-$month-01";
    $end_date = date("Y-m-t", strtotime($start_date)); // Get the last day of the month

    $sql = "SELECT COUNT(*) AS checkup_count FROM checkup_information WHERE date BETWEEN '$start_date' AND '$end_date'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['checkup_count'];
}


// Instantiate PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Clinic name and logo
$pdf->Cell(0, 10, '', 0, 1);

// Print the report in table format
$pdf->SetFont('Arial', 'B', 12); // Set font to bold
$pdf->Cell(170, 10, 'Category', 0, 0);
$pdf->Cell(0, 10, 'Value', 0, 1);
$pdf->SetFont('Arial', '', 12); // Reset font
// Loop through report data and print each category-value pair
foreach ($report_data as $category => $value) {
    $pdf->Cell(170, 10, $category, 0, 0);
    $pdf->Cell(0, 10, $value, 0, 1);
}

// Output the PDF
$pdf->Output();

// Function to get the number of doctors from the database
function getDoctorCount($conn)
{
    $sql = "SELECT COUNT(*) AS doctor_count FROM doctor";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['doctor_count'];
}

// Function to get the number of nurses from the database
function getNurseCount($conn)
{
    $sql = "SELECT COUNT(*) AS nurse_count FROM nurse";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['nurse_count'];
}

// Function to get the number of patients from the database
function getPatientCount($conn)
{
    $sql = "SELECT COUNT(*) AS patient_count FROM patient_basic_information";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row['patient_count'];
}

?>

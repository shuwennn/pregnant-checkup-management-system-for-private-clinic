<?php 
// Include header and navbar files
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

?>

       

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Details Information</h1>                       
                    </div>

                    <hr>

                    <!-- Content Row -->
                     
                     <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Address</h6>
                                </div>
                                <div class="card-body">
                                    38, 40 & 42, Jalan Cantik,<br>
                                    86000 Kluang, Johor.
                                </div>
                            </div>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Contact Number</h6>
                                </div>
                                <div class="card-body">
                                    07-7713103
                                </div>
                            </div>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Opening Hours</h6>
                                </div>
                                <div class="card-body">
                                    <table style="width: 100%;">
                                        <tr>
                                        <th style="width: 20%;">Time</th>
                                        <th style="width: 20%;">8 AM - 12 PM</th>
                                        <th style="width: 20%;">2 PM - 4 PM</th>
                                        <th style="width: 20%;">4 PM - 6 PM</th>
                                        </tr>
                                        <tr>
                                            <td>Monday</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                        </tr>  
                                        <tr>
                                            <td>Tuesday</td>
                                            <td>Open</td>
                                            <td>Close</td>
                                            <td>Close</td>
                                        </tr>
                                        <tr>
                                            <td>Wednesday</td>
                                            <td>Open</td>
                                            <td>Close</td>
                                            <td>Close</td>
                                        </tr>  
                                        <tr>
                                            <td>Thursday</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                        </tr> 
                                        <tr>
                                            <td>Friday</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                            <td>Close</td>
                                        </tr> 
                                        <tr>
                                            <td>Saturday</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                            <td>Close</td>
                                        </tr>
                                        <tr>
                                            <td>Sunday</td>
                                            <td>Open</td>
                                            <td>Open</td>
                                            <td>Close</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>     
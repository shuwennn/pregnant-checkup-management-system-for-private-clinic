<?php
// Establish database connection
$mysqli = mysqli_connect("localhost", "root", "", "pregnant_system");

// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

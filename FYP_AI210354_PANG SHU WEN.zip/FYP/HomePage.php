<?php
// Start the session
session_start();

// Include header and navbar files
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>      

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">General HomePage</h1>
                    </div>

                    <hr>

<!-- Big Image -->

<div class="row mb-3" id="big-image-row">
<div class="col-md-12">
<img src="img/clinic.jpg" class="img-fluid-a small-big-image" alt="Big Image">
</div>
</div>
</div>



<!-- Content Row -->
<div class="row">
<!-- Info Box 1 -->
<div class="col-xl-3 col-md-6 mb-4">
<div class="card border-left-primary shadow h-100 py-2" data-toggle="modal" data-target="#infoModal1">
<div class="card-body">
<div class="row no-gutters align-items-center">
<div class="col mr-2">
  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Nutritional Guide for Pregnant Women with Anemia</div>
  <div class="h5 mb-0 font-weight-bold text-gray-800">Ways to Overcome Anemia (Iron Deficiency) During Pregnancy</div>
</div>
<div class="col-auto">
  <i class="fas fa-info-circle fa-2x text-gray-300"></i>
</div>
</div>
</div>
</div>
</div>

<!-- Info Box 2 -->
<div class="col-xl-3 col-md-6 mb-4">
<div class="card border-left-success shadow h-100 py-2" data-toggle="modal" data-target="#infoModal2">
<div class="card-body">
<div class="row no-gutters align-items-center">
<div class="col mr-2">
  <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Nutritional Guide for Pregnant Women with Anemia</div>
  <div class="h5 mb-0 font-weight-bold text-gray-800">Ways to Enhance Iron Absorption</div>
</div>
<div class="col-auto">
  <i class="fas fa-info-circle fa-2x text-gray-300"></i>
</div>
</div>
</div>
</div>
</div>

<!-- Info Box 3 -->
<div class="col-xl-3 col-md-6 mb-4">
<div class="card border-left-info shadow h-100 py-2" data-toggle="modal" data-target="#infoModal3">
<div class="card-body">
<div class="row no-gutters align-items-center">
<div class="col mr-2">
  <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Diabetes Disease</div>
  <div class="h5 mb-0 font-weight-bold text-gray-800">Who is at Risk of Getting Diabetes</div>
</div>
<div class="col-auto">
  <i class="fas fa-info-circle fa-2x text-gray-300"></i>
</div>
</div>
</div>
</div>
</div>

<!-- Info Box 4 -->
<div class="col-xl-3 col-md-6 mb-4">
<div class="card border-left-warning shadow h-100 py-2" data-toggle="modal" data-target="#infoModal4">
<div class="card-body">
<div class="row no-gutters align-items-center">
<div class="col mr-2">
  <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Diabetes Disease</div>
  <div class="h5 mb-0 font-weight-bold text-gray-800">What Needs to Be Done During Pregnancy</div>
</div>
<div class="col-auto">
  <i class="fas fa-info-circle fa-2x text-gray-300"></i>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- End of Content Row -->

<!-- Modals -->
<!-- Info Box 1 Modal -->
<div class="modal fade" id="infoModal1" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel1" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="infoModalLabel1">Ways to Overcome Anemia (Iron Deficiency) During Pregnancy</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
Way 1: Increase Blood with Hematinic Pills
<ul>
  <li>
  Take hematinic pills with plain water or fruit juice for optimal absorption.
  </li>
  <li>
  Avoid taking hematinic pills with coffee, tea, cola drinks, chocolate drinks, and milk.
  </li>
</ul>
Way 2: Increase Blood by Eating Iron-Rich Foods
<ul>
  <li>
  Good sources of iron-rich foods come from animal sources such as meat, chicken, fish, shellfish, squid, and anchovies. Green vegetables like pennywort, fiddlehead ferns, water spinach, spinach, and kale also contain iron.
  </li>
  <li>
  Eat at least one type of iron-rich animal food source every day.
  </li>
</ul>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Info Box 2 Modal -->
<div class="modal fade" id="infoModal2" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel2" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="infoModalLabel2">Ways to Enhance Iron Absorption</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
Way 1: Increase Consumption of Foods that Enhance Iron Absorption
<ul>
<li>
Eat more fruits and vegetables rich in Vitamin C, such as guava, oranges, papaya, mango, pennywort, mustard greens, kale, spinach, and water spinach.
</li>
</ul>
Way 2: Reduce Consumption of Foods that Inhibit Iron Absorption
<ul>
<li>
Limit intake of foods and beverages that inhibit iron absorption, such as coffee, tea, cola drinks, chocolate drinks, and milk. However, pregnant women need to drink 2-3 glasses of milk a day to get enough calcium. Therefore, drink milk between main meals.
</li>
</ul>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Info Box 3 Modal -->
<div class="modal fade" id="infoModal3" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel3" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="infoModalLabel3">Who is at Risk of Getting Diabetes</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<ul>
<li>There is sugar in the urine during routine check-ups.</li>
<li>Excessive body weight.</li>
<li>Having parents who have diabetes.</li>
<li>Have given birth to a baby weighing more than 4kg.</li>
<li>Have experienced consecutive miscarriages, stillbirths, or neonatal deaths, and babies born with defects.</li>
<li>Have had diabetes during a previous pregnancy.</li>
<li>Experience conditions such as hypertension and polyhydramnios (excessive amniotic fluid) during this pregnancy.</li>
<li>Have previously had a baby larger than the gestational age.</li>
</ul>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Info Box 4 Modal -->
<div class="modal fade" id="infoModal4" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel4" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="infoModalLabel4">What Needs to Be Done During Pregnancy</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<ul>
<li>During pregnancy, the mother will undergo a blood test (MGTT) if she has one or more risk factors.</li>
<li>Receive thorough pregnancy care from healthcare providers.</li>
<li>Adhere to scheduled appointments and prescribed treatments.</li>
<li>Practice personal hygiene.</li>
<li>Undergo recommended screenings for diabetes patients.</li>
<li>Regular glucose level checks at home.</li>
</ul>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<!-- Small Images and Definitions -->
<div class="row mt-4">
<!-- Small Image and Definition for Info Box 1 -->
<div class="col-md-3">
<img src="img/red.png" class="img-fluid" alt="Small Image 1">
<p>High risk. Immediate referral to the nearest hospital.<br>Follow-up: Obstetricians & Gynecologists (O&G) and Family Medicine Specialists.<br>
Examples: Heart disease, premature contractions.</p>
</div>
<div class="col-md-3">
<img src="img/yellow.png" class="img-fluid" alt="Small Image 2">
<p>At risk. Can give birth at any hospital, including district hospitals.<br>Follow-up: Requires monitoring by Specialist Doctors FMS/O&G<br>
Examples: Diabetes with insulin, high blood pressure in teenagers, unmarried mothers, and others.</p>
</div>
<div class="col-md-3">
<img src="img/green.png" class="img-fluid" alt="Small Image 3">
<p>At risk. Can deliver at any hospital, including district hospitals.<br>
Follow-up: Nurses under doctor's supervision.<br>
Examples: Primiparous, weighing 80kg, vacuum extraction, 3rd-degree tear, Cesarean section, asthma, and others.</p>
</div>
<div class="col-md-3">
<img src="img/white.png" class="img-fluid" alt="Small Image 3">
<p>No risk. Can deliver at any hospital, including district hospitals.<br>
Follow-up: Nurses.</p>
</div>
</div>

<hr>

                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>
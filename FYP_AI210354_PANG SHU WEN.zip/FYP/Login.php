<?php
session_start(); // Start session at the very beginning

require_once('Config.php'); // Include your database connection configuration

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get email and password from POST request
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Function to verify user credentials and return user information
    function verify_user($conn, $table, $email, $password) {
        $sql = "SELECT * FROM $table WHERE email = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            error_log('Prepare failed: ' . htmlspecialchars($conn->error));
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }

        $stmt->bind_param("s", $email);
        if (!$stmt->execute()) {
            error_log('Execute failed: ' . htmlspecialchars($stmt->error));
            die('Execute failed: ' . htmlspecialchars($stmt->error));
        }

        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            // Verify password
            if (password_verify($password, $row['password'])) {
                return $row; // Return user information
            } else {
                error_log("Password verification failed for email: $email");
                return null; // Password does not match
            }
        } else {
            error_log("No user found for email: $email in table: $table");
            return null; // No user found
        }
    }

    // Check user in different tables based on role
    $user = verify_user($mysqli, 'doctor', $email, $password);
    if (!$user) {
        $user = verify_user($mysqli, 'nurse', $email, $password);
    }
    if (!$user) {
        $user = verify_user($mysqli, 'patient_basic_information', $email, $password);
    }

    // If user is found
    if ($user) {
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];

        // Set patient_ic in session for patients
        if ($user['role'] === 'patient') {
            $_SESSION['patient_ic'] = $user['patient_ic'];
        }

        // Set patient_ic in session for general nurses
        if ($user['role'] === 'general_nurse') {
            $_SESSION['ic_no'] = $user['ic_no'];
        }

        // Set patient_ic in session for general nurses
        if ($user['role'] === 'doctor') {
            $_SESSION['ic_no'] = $user['ic_no'];
        }

        // Redirect based on role
        switch ($user['role']) {
            case 'doctor':
                header("Location: /FYP/Doctor/HomePage.php");
                exit();
            case 'head_nurse':
                header("Location: /FYP/Staff/HomePage.php");
                exit();
            case 'general_nurse':
                header("Location: /FYP/GeneralNurse/HomePage.php");
                exit();
            case 'patient':
                header("Location: /FYP/Patient/HomePage.php");
                exit();
            default:
                error_log("Unknown role: {$user['role']} for email: {$user['email']}");
                header("Location: /FYP/error.php");
                exit();
        }
    } else {
        // Invalid email or password
        $_SESSION['error'] = "Invalid email or password.";
        header("Location: /FYP/Login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>FYP - Login</title>
    <link href="/FYP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="/FYP/css/sb-admin-2.css" rel="stylesheet">
</head>
<body class="bg-gradient-primary">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-10">
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="p-5">
                                <div class="text-center mb-4">
    <div class="box p-3 mb-4 d-flex align-items-center justify-content-center" style="border: 1px solid #ddd; background-color: #f8f9fc; border-radius: 5px;">
        <img src="img/logo-1.png" alt="Clinic Logo" style="width: 10%; margin-right: 10px;">
        <h2 class="text-gray-900 mb-0">Pusat Pakar Wanita dan Perbidanan Johor</h2>
    </div>
</div>
<div class="text-center">
        <h1 class="h1 text-gray-900 mb-0">Login</h1>
        </div>
    
                                    <hr>
                                    <?php
                                    if (isset($_SESSION['error'])) {
                                        echo '<div class="alert alert-danger" role="alert">' . $_SESSION['error'] . '</div>';
                                        unset($_SESSION['error']);
                                    }
                                    ?>
                                    <form class="user" method="POST" action="/FYP/Login.php">
                                        <div class="form-group row">
                                            <label for="email" class="col-sm-5 col-form-label text-gray-900 text-large">Email</label>
                                            <div class="col-sm-12">
                                                <input type="email" class="form-control form-control-user" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter Email">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="password" class="col-sm-5 col-form-label text-gray-900 text-large">Password</label>
                                            <div class="col-sm-12">
                                                <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Enter Password">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <button type="submit" name="login" id="login" class="btn btn-primary btn-user btn-block" value="Login">Login</button>
                                            </div>
                                        </div>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="/FYP/ForgotPassword.php">Forgot Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="/FYP/Patient/Register.php">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/FYP/vendor/jquery/jquery.min.js"></script>
    <script src="/FYP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/FYP/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="/FYP/js/sb-admin-2.min.js"></script>
</body>
</html>

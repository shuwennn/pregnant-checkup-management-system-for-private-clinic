<?php
// Include Config.php to establish database connection
require_once "D:/Xampp/htdocs/V2/Config.php";

// Include header and navbar files
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

// Initialize message variable
$message = "";

// Check if message is provided in the URL
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Check if token is provided in the URL
if (!isset($_GET["token"])) {
    die("Token not found in the URL.");
}

// Get token from URL
$token = $_GET["token"];
$token_hash = hash("sha256", $token);

// Initialize role and user variables
$role = "";
$user = null;

// Check if role is provided in the URL
if (!isset($_GET["role"])) {
    die("Role not found in the URL.");
}

// Get role from URL
$role_param = $_GET["role"];

// Validate the role parameter against allowed roles
$allowed_roles = array("doctor", "head_nurse", "general_nurse", "patient", "nurse");
if (!in_array($role_param, $allowed_roles)) {
    die("Invalid role provided in the URL.");
}

// Assign role based on URL parameter
$role = $role_param;

// Prepare SQL statements to select user with the provided reset token and role
switch ($role) {
    case "doctor":
        $sql_select = "SELECT * FROM doctor WHERE reset_token_hash = ?";
        break;
    case "head_nurse":
        $sql_select = "SELECT * FROM nurse WHERE role = 'head_nurse' AND reset_token_hash = ?";
        break;
    case "general_nurse":
        $sql_select = "SELECT * FROM nurse WHERE role = 'general_nurse' AND reset_token_hash = ?";
        break;
    case "patient":
        $sql_select = "SELECT * FROM patient_basic_information WHERE reset_token_hash = ?";
        break;
    case "nurse":
        // This case is for handling the specific role "nurse"
        $sql_select = "SELECT * FROM nurse WHERE reset_token_hash = ?";
        break;
    default:
        die("Invalid role.");
}

// Prepare statement
$stmt_select = $mysqli->prepare($sql_select);

// Check if prepared statement is prepared successfully
if (!$stmt_select) {
    die("Database query preparation failed: " . $mysqli->error);
}

// Binding parameters
$stmt_select->bind_param("s", $token_hash);

// Execute query
$stmt_select->execute();

// Get result
$result = $stmt_select->get_result();

// Fetch the user data
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("No user found with the provided token and role.");
}

// Process password reset form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $password = trim($_POST["password"]);
    $password_confirmation = trim($_POST["password_confirmation"]);

    // Additional validation (e.g., password strength check, match confirmation)
    // For simplicity, let's assume basic validation and matching confirmation
    if ($password != $password_confirmation) {
        $message = "Passwords do not match.";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Update user's password based on role
        switch ($role) {
            case "doctor":
                $sql_update = "UPDATE doctor SET password = ? WHERE email = ?";
                break;
            case "head_nurse":
            case "general_nurse":
            case "nurse": // Include nurse here to update password for both head and general nurses
                $sql_update = "UPDATE nurse SET password = ? WHERE email = ?";
                break;
            case "patient":
                $sql_update = "UPDATE patient_basic_information SET password = ? WHERE email = ?";
                break;
            default:
                die("Invalid role.");
        }

        // Prepare update statement
        $stmt_update = $mysqli->prepare($sql_update);
        if ($stmt_update) {
            $stmt_update->bind_param("ss", $hashed_password, $user['email']);
            if ($stmt_update->execute()) {
                // Check if update was successful
                if ($stmt_update->affected_rows > 0) {
                    $message = "Password updated successfully.";
                } else {
                    $message = "Password update failed. Please try again.";
                }
            } else {
                die("Execute failed: (" . $stmt_update->errno . ") " . $stmt_update->error);
            }
            $stmt_update->close(); // Close statement
        } else {
            die("Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error);
        }
    }
}
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">RESET PASSWORD PAGE</h1>
            </div>

            <hr>
            <!-- Display the message -->
            <?php if (!empty($message)): ?>
            <div class="message-box">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>

            <!-- Display the reset password form -->
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h1>Reset Password</h1>
                            </div>
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?token=" . htmlspecialchars($token) . "&role=" . htmlspecialchars($role); ?>" method="post">
                                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                                <div class="card-body">
                                    <div class="form-group row mb-3 justify-content-center">
                                        <label for="password" class="col-sm-5 col-form-label">New Password</label>
                                        <input name="password" type="password" class="form-control"
                                            placeholder="Please enter new password to reset" required>
                                    </div>
                                    <div class="form-group row mb-3 justify-content-center">
                                        <label for="password_confirmation" class="col-sm-5 col-form-label">Confirm New Password</label>
                                        <input name="password_confirmation" type="password" class="form-control"
                                            placeholder="Please enter again new password" required>
                                    </div>
                                    <div class="form-group row mb-3">
                                        <div class="col-sm-12">
                                            <button class="btn btn-primary" type="submit"> Reset Password </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>

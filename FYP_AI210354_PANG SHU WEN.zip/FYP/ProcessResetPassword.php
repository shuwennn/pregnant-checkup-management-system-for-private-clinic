<?php
require_once "D:/Xampp/htdocs/FYP/Config.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Validate token presence
    if (!isset($_POST["token"])) {
        die("Token not found.");
    }

    // Sanitize and hash the token
    $token = $_POST["token"];
    $token_hash = hash("sha256", $token);

    // Validate and sanitize new password
    $new_password = $_POST["password"];
    $confirm_password = $_POST["password_confirmation"];

    if ($new_password !== $confirm_password) {
        die("Passwords do not match.");
    }

    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

    // Function to update password and clear token
    function update_password_and_clear_token($conn, $table, $password_hash, $token_hash) {
        $sql_update = "UPDATE $table
            SET password = ?,
                reset_token_hash = NULL,
                reset_token_expires_at = NULL
            WHERE reset_token_hash = ?";

        $stmt_update = $conn->prepare($sql_update);
        if (!$stmt_update) {
            die("Database query preparation failed: " . $conn->error);
        }

        $stmt_update->bind_param("ss", $password_hash, $token_hash);
        $stmt_update->execute();

        return $stmt_update->affected_rows;
    }

    // Check each user type table for the token
    $user_types = ['doctor', 'nurse', 'patient_basic_information'];
    foreach ($user_types as $table) {
        $sql_select = "SELECT * FROM $table WHERE reset_token_hash = ?";
        $stmt_select = $mysqli->prepare($sql_select);
        if (!$stmt_select) {
            die("Database query preparation failed: " . $mysqli->error);
        }

        $stmt_select->bind_param("s", $token_hash);
        $stmt_select->execute();

        $result = $stmt_select->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // Update password and clear token
            if (update_password_and_clear_token($mysqli, $table, $password_hash, $token_hash)) {
                // Redirect to login page after successful password reset
                header("Location: /FYP/Login.php");
                exit();
            } else {
                die("Password update failed. Token might be invalid.");
            }
        }
    }

    // If no user found with the token, display error
    die("No user found with the provided token.");
} else {
    header("Location: error.php");
    exit();
}
?>

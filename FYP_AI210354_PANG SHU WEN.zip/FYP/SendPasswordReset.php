<?php
// Ensure email is provided via POST request
if (!isset($_POST["email"])) {
    die("Email is required.");
}

$email = $_POST["email"];

// Generate a random token and hash it
$token = bin2hex(random_bytes(16));
$token_hash = hash("sha256", $token);

// Token expiry time (30 minutes from now)
$expiry = date("Y-m-d H:i:s", time() + 60 * 30);

// Include Config.php to establish database connection
require_once "D:/Xampp/htdocs/FYP/Config.php";

// Attempt to update the respective user table with reset token and expiry
// Attempt to update the doctor table
$sql = "UPDATE doctor
        SET reset_token_hash = ?,
            reset_token_expires_at = ?
        WHERE email = ?";

$stmt = $mysqli->prepare($sql);
if ($stmt === false) {
    // Handle prepare error
    die('Doctor prepare() failed: ' . htmlspecialchars($mysqli->error));
}

$stmt->bind_param("sss", $token_hash, $expiry, $email);
$stmt->execute();

if ($stmt->affected_rows) {
    // If update successful, send email with reset link
    sendPasswordResetEmail($email, $token, 'doctor'); // Pass 'doctor' as role
} else {
    // If not found in doctors table, check nurses table
    $sql = "UPDATE nurse
            SET reset_token_hash = ?,
                reset_token_expires_at = ?
            WHERE email = ?";
    
    $stmt = $mysqli->prepare($sql);
    if ($stmt === false) {
        // Handle prepare error
        die('Nurses prepare() failed: ' . htmlspecialchars($mysqli->error));
    }
    
    $stmt->bind_param("sss", $token_hash, $expiry, $email);
    $stmt->execute();

    if ($stmt->affected_rows) {
        // If update successful, send email with reset link
        sendPasswordResetEmail($email, $token, 'nurse'); // Pass 'nurse' as role
    } else {
        // If not found in nurses table, check patients table
        $sql = "UPDATE patient_basic_information
                SET reset_token_hash = ?,
                    reset_token_expires_at = ?
                WHERE email = ?";
        
        $stmt = $mysqli->prepare($sql);
        if ($stmt === false) {
            // Handle prepare error
            die('Patients prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
        
        $stmt->bind_param("sss", $token_hash, $expiry, $email);
        $stmt->execute();

        if ($stmt->affected_rows) {
            // If update successful, send email with reset link
            sendPasswordResetEmail($email, $token, 'patient'); // Pass 'patient' as role
        } else {
            // If email not found in any table, redirect with error message
            redirectWithMessage("No matching email found or update failed.");
        }
    }
}

// Function to send password reset email
function sendPasswordResetEmail($email, $token, $role) {
    // Assuming mailer.php contains the mailer configuration and setup
    $mail = require __DIR__ . "/mailer.php";

    $mail->setFrom("noreply@example.com");
    $mail->addAddress($email);
    $mail->Subject = "Password Reset";
    $mail->Body = <<<END
    Click <a href="http://localhost/FYP/ResetPassword.php?token=$token&role=$role">here</a> 
    to reset your password.
    END;

    try {
        $mail->send();
        // Redirect with success message
        redirectWithMessage("Message sent, please check your inbox.");
    } catch (Exception $e) {
        // Redirect with error message
        redirectWithMessage("Message could not be sent. Mailer error: {$mail->ErrorInfo}");
    }
}

// Function to redirect with message
function redirectWithMessage($message) {
    header("Location: /FYP/ForgotPassword.php?message=" . urlencode($message));
    exit();
}

// Close statement and connection
$stmt->close();
$mysqli->close();

exit();
?>

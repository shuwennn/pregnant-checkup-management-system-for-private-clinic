<?php
require('../Config.php');

// Establish database connection
$mysqli = mysqli_connect("localhost", "root", "", "pregnant_system");

// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the patient with the given email or IC exists in the database and return true if found
function isPatientRegistered($con, $patient_ic, $email) {
    $query = "SELECT COUNT(*) FROM patient_basic_information WHERE patient_ic = ? OR email = ?";
    $stmt = mysqli_prepare($con, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $patient_ic, $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $count);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);

        // If count > 0, patient is registered; otherwise, not registered
        return $count > 0;
    } else {
        // Handle statement preparation error
        echo "Error preparing statement: " . mysqli_error($con);
        return false;
    }
}

// Check if form is submitted
if (isset($_POST['register'])) {
    // Retrieve and sanitize input
    $patient_ic = isset($_POST['patient_ic']) ? mysqli_real_escape_string($mysqli, $_POST['patient_ic']) : '';
    $email = isset($_POST['email']) ? mysqli_real_escape_string($mysqli, $_POST['email']) : '';
    $password = isset($_POST['password']) ? mysqli_real_escape_string($mysqli, $_POST['password']) : '';
    $confirm_password = isset($_POST['confirm_password']) ? mysqli_real_escape_string($mysqli, $_POST['confirm_password']) : '';

    // Validate input
    if (empty($patient_ic) || empty($email) || empty($password) || empty($confirm_password)) {
        // Handle empty fields
        echo '<script>alert("Please fill in all the fields.");';
        echo 'window.location.href = "/FYP/Patient/Register.php";</script>';
        exit;
    }

    // Check if the patient is registered by staff
    if (!isPatientRegistered($mysqli, $patient_ic, $email)) {
        // Handle patient not registered by staff
        echo '<script>alert("This identification number or email is not registered by staff.");';
        echo 'window.location.href = "/FYP/Patient/Register.php";</script>';
        exit;
    }

    // Validate password
if ($password !== $confirm_password) {
    // Handle password mismatch
    echo '<script>alert("Passwords do not match.");window.location.href = "/V2/Patient/Register.php";</script>';
    exit;
}

if (strlen($password) < 8 || !preg_match("/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,}$/", $password)) {
    // Handle insufficient password complexity
    echo '<script>alert("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");';
    echo 'window.location.href = "/FYP/Patient/Register.php";</script>';
    exit;
}


    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Update patient password in the database
    $update_query = "UPDATE patient_basic_information SET password = ? WHERE patient_ic = ?";
    $update_stmt = mysqli_prepare($mysqli, $update_query);

    if ($update_stmt) {
        mysqli_stmt_bind_param($update_stmt, "ss", $hashed_password, $patient_ic);
        $update_result = mysqli_stmt_execute($update_stmt);

        if ($update_result) {
            // Handle successful password update
            echo '<script>alert("Password successfully registered. Redirecting to login page.");';
            echo 'window.location.href = "/FYP/Login.php";</script>';
        } else {
            // Handle database error
            echo '<script>alert("Error: ' . mysqli_error($mysqli) . '");';
            echo 'window.location.href = "/FYP/Patient/Register.php";</script>';
        }

        mysqli_stmt_close($update_stmt);
    } else {
        // Handle statement preparation error
        echo '<script>alert("Error preparing statement: ' . mysqli_error($mysqli) . '");';
        echo 'window.location.href = "/FYP/Patient/Register.php";</script>';
    }

    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>FYP- Register</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">
    <div class="row justify-content-center align-items-center">

<div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="p-5">
                        <div class="text-center mb-4">
    <div class="box p-3 mb-4 d-flex align-items-center justify-content-center" style="border: 1px solid #ddd; background-color: #f8f9fc; border-radius: 5px;">
        <img src="../img/logo-1.png" alt="Clinic Logo" style="width: 10%; margin-right: 10px;">
        <h2 class="text-gray-900 mb-0">Pusat Pakar Wanita dan Perbidanan Johor</h2>
    </div>
</div>

                            <div class="text-center">
                                <h1 class="h1 text-gray-900 mb-4">Registration</h1>
                            </div>
                            <form class="user" action="" method="post">
                                <div class="form-group row">
                                <label for="patient_ic" class="col-sm-10 col-form-label text-gray-900 text-large">Identification Number</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control form-control-user" id="patient_ic" name="patient_ic"
                                            placeholder="Enter Identification Number" required> 
                                    </div>
                                        </div>
                                    <div class="form-group row">
                                    <label for="email" class="col-sm-10 col-form-label text-gray-900 text-large">Email</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control form-control-user" id="email" name="email"
                                            placeholder="Enter Email" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                <label for="password" class="col-sm-10 col-form-label text-gray-900 text-large">Password</label>
                                    <div class="col-sm-12">
                                        <input type="password" class="form-control form-control-user" name="password"
                                            id="password" placeholder="Password" required>
                                    </div>
                                        </div>
                                    <div class="form-group row">
                                    <label for="ic_no" class="col-sm-10 col-form-label text-gray-900 text-large">Confirm Password</label>
                                    <div class="col-sm-12">
                                        <input type="password" class="form-control form-control-user" name="confirm_password"
                                            id="confirm_password" placeholder="Confirm Password" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                <div class="col-sm-12">
                                <button type="submit" name="register" id="register" class="btn btn-primary btn-user btn-block" value="Register"> Register </button>
                            </div>
                            </div>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="/FYP/Login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
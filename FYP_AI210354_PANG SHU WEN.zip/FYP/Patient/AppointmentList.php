<?php
// Start session
session_start();

// Include header and navbar files
include('../Patient/includes/header.php');
include('../Patient/includes/navbar.php');
include('../Patient/includes/topbar.php');

// Include the database connection file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'patient'
if ($_SESSION['role'] !== 'patient') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Check for status message
$status_message = isset($_GET['status']) ? $_GET['status'] : "";

// Display status message if present
if (!empty($status_message)) {
    echo "<p>Status: " . htmlspecialchars($status_message) . "</p>";
}

// Establish database connection
$connection = mysqli_connect('localhost', 'root', '', 'pregnant_system');

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the current logged-in patient's IC
$patient_ic = $_SESSION['patient_ic'];

// Fetch appointment data for the logged-in patient from the database
$sql = "SELECT appoint_id, date, start_time, end_time, remark FROM appointment WHERE patient_ic = ? ORDER BY start_time DESC";
$stmt = mysqli_prepare($connection, $sql);
mysqli_stmt_bind_param($stmt, 's', $patient_ic);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Close the database connection
mysqli_close($connection);
?>


        <!-- Begin Page Content -->
        <div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">APPOINTMENT LIST</h1>
    </div>

    <hr>

    <!-- Content Row -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                    <div class="card-body">
    <table class="table">
        <thead>
            <tr>
                <th>Appointment ID</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Remark</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through each row of data
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?php echo $row['appoint_id']; ?></td>
                    <td><?php echo $row['date']; ?></td>
                    <td><?php echo $row['start_time']; ?></td>
                    <td><?php echo $row['end_time']; ?></td>
                    <td><?php echo $row['remark']; ?></td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
</div>
</div>
</div>
</div>

<?php
include('../Patient/includes/footer.php');
include('../Patient/includes/scripts.php');
?>


<?php
session_start();

// Include header and navbar files
include('../Patient/includes/header.php');
include('../Patient/includes/navbar.php');
include('../Patient/includes/topbar.php');

// Include the database connection file
require('../Config.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['email']) || !isset($_SESSION['role'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: /FYP/Login.php");
    exit();
}

// Check if the user role is 'patient'
if ($_SESSION['role'] !== 'patient') {
    // If the user does not have the appropriate role, redirect to an unauthorized page or show an error
    header("Location: /FYP/Unauthorized.php");
    exit();
}

// Get patient IC
$patient_ic = $_SESSION['patient_ic'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if date, time slot, and remark are provided
    $appointmentDate = $_POST['appointmentDate'];
    $appointmentTime = $_POST['appointmentTime'];
    $appointmentRemark = $_POST['appointmentRemark'];

    if (empty($appointmentDate) || empty($appointmentTime) || empty($appointmentRemark)) {
        // If any of the required fields are empty, display an error message
        echo json_encode(['status' => false, 'msg' => 'Please fill in all fields (date, time slot, and remark) before saving.']);
        exit();
    }

    // Check if the patient already has an appointment for the selected date and time slot
    $sqlCheckExistingAppointment = "SELECT * FROM appointment WHERE patient_ic = ? AND date = ? AND start_time = ?";
    $stmt = $mysqli->prepare($sqlCheckExistingAppointment);
    $stmt->bind_param("sss", $patient_ic, $appointmentDate, $appointmentTime);
    $stmt->execute();
    $resultCheckExistingAppointment = $stmt->get_result();

    if ($resultCheckExistingAppointment->num_rows > 0) {
        // If the patient already has an appointment for the selected date and time slot, update that appointment
        $row = $resultCheckExistingAppointment->fetch_assoc();
        $existingAppointmentId = $row['appoint_id'];

        // Only update time and remark, don't change patient_ic
        $sqlUpdateAppointment = "UPDATE appointment SET start_time = ?, remark = ? WHERE appoint_id = ?";
        $stmt = $mysqli->prepare($sqlUpdateAppointment);
        $stmt->bind_param("ssi", $appointmentTime, $appointmentRemark, $existingAppointmentId);

        if ($stmt->execute()) {
            // Appointment updated successfully
            echo json_encode(['status' => true, 'msg' => 'Appointment updated successfully!', 'updatedAppointment' => $row]);
            exit();
        } else {
            // Error updating appointment
            echo json_encode(['status' => false, 'msg' => 'Error updating appointment: ' . $mysqli->error]);
            exit();
        }
    } else {
        // Insert a new appointment if the patient does not have an existing appointment for the selected date and time slot
        $sqlInsertAppointment = "INSERT INTO appointment (patient_ic, date, start_time, remark, availability) VALUES (?, ?, ?, ?, 0)";
        $stmt = $mysqli->prepare($sqlInsertAppointment);
        $stmt->bind_param("ssss", $patient_ic, $appointmentDate, $appointmentTime, $appointmentRemark);
    
        if ($stmt->execute()) {
            // New appointment inserted successfully
            $insertedAppointmentId = $stmt->insert_id;
            $newAppointment = ['appoint_id' => $insertedAppointmentId, 'start_time' => $appointmentTime, 'end_time' => '', 'remark' => $appointmentRemark];
            echo json_encode(['status' => true, 'msg' => 'New appointment inserted successfully!', 'updatedAppointment' => $newAppointment]);
            exit();
        } else {
            // Error inserting new appointment
            echo json_encode(['status' => false, 'msg' => 'Error inserting new appointment: ' . $mysqli->error]);
            exit();
        }
    }
}

// Fetch distinct dates for which appointments exist
$sqlDates = "SELECT DISTINCT date FROM appointment";
$resultDates = $mysqli->query($sqlDates);

// Initialize an array to store all appointment slots
$allSlots = [];

// Fetch existing appointments for the patient
$existingAppointments = [];
$sqlExisting = "SELECT date, start_time FROM appointment WHERE patient_ic = ?";
$stmt = $mysqli->prepare($sqlExisting);
$stmt->bind_param("s", $patient_ic);
$stmt->execute();
$resultExisting = $stmt->get_result();
while ($row = $resultExisting->fetch_assoc()) {
    $existingAppointments[$row['date']][] = $row['start_time'];
}

// Loop through each distinct date
while ($rowDate = $resultDates->fetch_assoc()) {
    // Fetch appointment slots for the current date
    $currentDate = $rowDate['date'];
    $sqlSlots = "SELECT * FROM appointment WHERE date = ?";
    $stmt = $mysqli->prepare($sqlSlots);
    $stmt->bind_param("s", $currentDate);
    $stmt->execute();
    $resultSlots = $stmt->get_result();

    // Initialize an array to store the appointment slots for the current date
    $slotsForDate = [];

    // Loop through each appointment slot for the current date
    while ($rowSlot = $resultSlots->fetch_assoc()) {
        // Determine if the slot is available, booked by the current patient, or booked by another patient
        $isAvailable = $rowSlot['availability'] == 1;
        $isBookedByCurrentPatient = $rowSlot['patient_ic'] == $patient_ic;

        // Set the title based on availability
        if ($isAvailable) {
            $title = 'Available';
        } elseif ($isBookedByCurrentPatient) {
            $title = 'Booked by You';
        } else {
            $title = 'Unavailable';
        }

        // Add the appointment slot to the array
        $slotsForDate[] = [
            'id' => $rowSlot['appoint_id'], // Use 'appoint_id' as the ID
            'title' => $title, // Set the title based on availability and patient
            'start' => $rowSlot['date'] . 'T' . $rowSlot['start_time'], // Combine date and start time
            'end' => $rowSlot['date'] . 'T' . $rowSlot['end_time'], // Combine date and end time
            'availability' => $rowSlot['availability'], // Set availability status
            'patientIC' => $rowSlot['patient_ic'] // Include patient_ic to check booking status
        ];
    }

    // Add the appointment slots for the current date to the array of all slots
    $allSlots = array_merge($allSlots, $slotsForDate);
}

// Convert all slots data to JSON format for JavaScript consumption
if (!empty($allSlots)) {
    // Encode all slots data, including both available and booked slots
    $slotsJson = json_encode($allSlots);
} else {
    // If no existing slots, set $slotsJson to an empty array
    $slotsJson = json_encode([]);
}

// Close prepared statements
$stmt->close();

// Close database connection
$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Event Calendar</title>

     <!-- Include necessary CSS files -->
     <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css/sb-admin-2.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />

    <style>
        .fc-non-clickable {
            pointer-events: none;
        }
    </style>

    <!-- Include jQuery and FullCalendar scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
 
</head>
<body>   

    <!-- Begin Page Content -->
    <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">APPOINTMENT CALENDAR</h1>
</div>

<hr>

<!-- Content Row -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">           
            <div id="calendar"></div>
        </div>
    </div>
</div>

  <!-- Modal for adding new event -->
  <div class="modal fade" id="confirmAppointmentModal" tabindex="-1" role="dialog" aria-labelledby="confirmAppointmentModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmAppointmentModalLabel">Confirm Appointment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="appointmentForm">
                        <div class="form-group">
                            <label for="appointmentDate">Select Date</label>
                            <input type="date" class="form-control" id="appointmentDate" name="appointmentDate">
                        </div>
                        <div class="form-group">
                            <label for="appointmentTime">Select Time Slot</label>
                            <div id="timeSlotButtons"></div>
                        </div>
                        <div class="form-group">
                            <label for="appointmentRemark">Enter Remark</label>
                            <input type="text" class="form-control" id="appointmentRemark" name="appointmentRemark" placeholder="Enter Remark">
                        </div>
                        <div class="form-group">
    <label for="appointmentTime">Selected Time Slot</label>
    <input type="text" class="form-control" id="appointmentTime" name="appointmentTime" readonly>
</div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Wait for the document to be ready
$(document).ready(function () {
    // Initialize full calendar
$('#calendar').fullCalendar({
    // Set options and callbacks as needed
    // For example, you can set initial events from PHP-generated JSON
    events: <?php echo $slotsJson; ?>,
    
    // Add event click handler
    dayClick: function(date, jsEvent, view) {
        // Open appointment modal when a date is clicked
        openAppointmentModal(date);
    },
    
// Event rendering function
eventRender: function(event, element) {
    // Log event details for debugging
    console.log('Event:', event);

    // Check if the event is booked by the current patient
    var isBookedByCurrentPatient = event.patientIC === '<?php echo $patient_ic; ?>';
    console.log('Is booked by current patient:', isBookedByCurrentPatient);

    // Check if the event's patientIC is empty
    if (event.patientIC === '') {
        // Set the event's patientIC to the current patient IC
        event.patientIC = '<?php echo $patient_ic; ?>';
    }

    // Check if the event is available, booked by the current patient, or booked by another patient
    if (event.availability === 1) {
        // Event is available
        element.css('background-color', '#008000'); // Green color for available
        element.css('border-color', '#008000');
        event.title = 'Available';
    } else {
        // Event is booked
        if (isBookedByCurrentPatient) {
            // Event is booked by the current patient
            element.css('background-color', '#ffcc00'); // Yellow color for booked by current patient
            element.css('border-color', '#ffcc00');
            event.title = 'Booked by You';
        } else {
            // Event is booked by another patient
            element.css('background-color', '#ff0000'); // Red color for booked by another patient
            element.css('border-color', '#ff0000');
            event.title = 'Unavailable';
        }
    }
}

    });
});

// Function to open appointment modal
function openAppointmentModal(date) {
    // Populate date in the form
    $('#appointmentDate').val(date.format('YYYY-MM-DD'));

    // Send an AJAX request to fetch time slots for the selected date
    $.ajax({
        url: 'FetchAppointment.php',
        type: 'POST',
        data: { date: date.format('YYYY-MM-DD') },
        success: function(response) {
            try {
                // Parse JSON response
                var data = JSON.parse(response);

                // Check if response status is true
                if (data && data.status === true && Array.isArray(data.data)) {
                    // Extract time slots from the response data
                    var timeSlots = data.data;

                    // Populate time slot buttons
                    populateTimeSlotButtons(timeSlots);

                    // Show the appointment modal
                    $('#confirmAppointmentModal').modal('show');

                    // Update event availability status in the calendar
                    updateEventAvailabilityStatus(timeSlots);
                } else {
                    // Display error message if response status is not true
                    console.error('Error fetching time slots:', data.msg);
                    alert('Error fetching time slots. ' + data.msg);
                }
            } catch (error) {
                // Display error message if JSON parsing fails
                console.error('Error parsing JSON:', error);
                alert('Error parsing JSON. Please try again.');
            }
        },
        error: function(xhr, status, error) {
            // Display error message if AJAX request fails
            console.error('Error fetching time slots:', error);
            alert('Error fetching time slots. Please try again.');
        }
    });
}

// Function to populate time slot buttons
function populateTimeSlotButtons(timeSlots) {
    var timeSlotButtonsHtml = "";
    timeSlots.forEach(function(timeSlot) {
        // Check if the slot is available
        if (timeSlot.availability === 1) {
            // Slot is available, enable the button
            timeSlotButtonsHtml += '<button type="button" class="btn btn-primary time-slot-btn" data-availability="' + timeSlot.availability + '">' + timeSlot.start + ' - ' + timeSlot.end + '</button>';
        } else {
            // Slot is unavailable, disable the button
            timeSlotButtonsHtml += '<button type="button" class="btn btn-secondary time-slot-btn" disabled>' + timeSlot.start + ' - ' + timeSlot.end + '</button>';
        }
    });
    $('#timeSlotButtons').html(timeSlotButtonsHtml);
}

// Event listener for time slot buttons container
$(document).on('click', '.time-slot-btn', function(event) {
    var selectedTimeSlot = $(this).text();
    var availability = $(this).data('availability');
    $('#appointmentTime').val(selectedTimeSlot);
    event.stopPropagation(); // Prevent the click event from propagating to the modal backdrop

    console.log('Selected Time Slot:', selectedTimeSlot); // Add this line to log the selected time slot
    console.log('Availability:', availability); // Add this line to log the availability
});

// Event listener for the form submission
$('#appointmentForm').submit(function (event) {
    // Prevent the default form submission
    event.preventDefault();

    // Get the form data
    var formData = $(this).serialize();

    // Send an AJAX request to save the appointment
    $.ajax({
        url: 'SaveAppointment.php',
        type: 'POST',
        data: formData,
        success: function (response) {
            // Parse the JSON response
            var data = JSON.parse(response);

            if (data.status === true) {
                // Appointment saved successfully
                alert('Appointment saved successfully!');
                
                // Update the event title to "Booked" in the calendar
                var updatedAppointment = data.updatedAppointment;
                $('#calendar').fullCalendar('clientEvents', function(event) {
                    // Check if the event's start time matches the updated appointment
                    if (event.start.format('YYYY-MM-DD HH:mm:ss') === updatedAppointment.start_time &&
                        event.end.format('YYYY-MM-DD HH:mm:ss') === updatedAppointment.end_time) {
                        // Update the event title to "Booked"
                        event.title = 'Booked';
                        // Update the event background color and border color
                        element.css('background-color', '#f6c23e');
                        element.css('border-color', '#f6c23e');
                        // Update the event in FullCalendar's internal data store
                        $('#calendar').fullCalendar('updateEvent', event);
                    }
                });
                
                // Hide the modal after successful submission
                $('#confirmAppointmentModal').modal('hide');
            } else {
                // Display an error message
                alert('Error saving appointment: ' + data.msg);
            }
        },
        error: function (xhr, status, error) {
            // Display an error message
            alert('Error saving appointment. Please try again.');
            console.error('Error saving appointment:', error);
        }
    });
});

// Function to update event availability status in the calendar
function updateEventAvailabilityStatus(timeSlots) {
    $('#calendar').fullCalendar('clientEvents', function(event) {
        // Check if the event is booked by the current patient
        var isBookedByCurrentPatient = event.patientIC === '<?php echo $patient_ic; ?>';

        // Initialize availability status for the event
        var isAvailable = true; // Assume initially available

        // Loop through the time slots to find a match for the event
        for (var i = 0; i < timeSlots.length; i++) {
            var slot = timeSlots[i];
            var slotStart = moment(slot.start);
            var slotEnd = moment(slot.end);

            // Check if the event overlaps with the current time slot
            if ((event.start.isSameOrAfter(slotStart) && event.start.isBefore(slotEnd)) || // Event starts within slot
                (event.end.isSameOrAfter(slotStart) && event.end.isBefore(slotEnd)) ||     // Event ends within slot
                (event.start.isSameOrBefore(slotStart) && event.end.isSameOrAfter(slotEnd))) { // Event spans the entire slot
                // Check if the time slot is booked
                if (slot.availability === 0) {
                    // Slot is booked
                    if (isBookedByCurrentPatient) {
                        // Slot is booked by the current patient
                        event.title = 'Booked by You';
                        event.backgroundColor = '#ffcc00'; // Yellow color for booked by current patient
                        event.borderColor = '#ffcc00';
                        event.editable = true; // Make the event editable for the current patient
                    } else {
                        // Slot is booked by another patient
                        event.title = 'Unavailable';
                        event.backgroundColor = '#ff0000'; // Red color for booked
                        event.borderColor = '#ff0000';
                        event.editable = false; // Make the event uneditable
                    }
                    isAvailable = false; // Mark the event as unavailable
                    break; // No need to check further
                }
            }
        }

        // If the event is not booked and overlaps with a time slot, mark it as unavailable
        if (!isBookedByCurrentPatient && isAvailable === false) {
            event.title = 'Unavailable'; // Update event title to indicate slot is unavailable
            event.backgroundColor = '#ff0000'; // Red color for unavailable
            event.borderColor = '#ff0000';
            event.editable = false; // Make the event uneditable
        }

        // If the event is not booked and does not overlap with any time slot, mark it as available
        if (isAvailable && !isBookedByCurrentPatient) {
            event.title = 'Available'; // Update event title to indicate slot is available
            event.backgroundColor = '#008000'; // Green color for available
            event.borderColor = '#008000';
            event.editable = true; // Make the event editable
        }

        // Log event details for debugging
        console.log('Event:', event.title, '- Start:', event.start.format(), '- End:', event.end.format(), '- Availability:', event.availability);

        // Update the event in FullCalendar's internal data store
        $('#calendar').fullCalendar('updateEvent', event);
    });
}

</script>

  <!-- Include other necessary scripts -->
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../js/sb-admin-2.min.js"></script>

    
<?php
    
    include('../Patient/includes/footer.php');
    ?>
</body>
</html>
<?php
// Include the database connection file
require('../Config.php');

// Check if the date is provided in the POST request
if(isset($_POST['date'])) {
    // Sanitize the date input to prevent SQL injection
    $selectedDate = $_POST['date'];

    // Prepare and bind the parameter for the query to prevent SQL injection
    $stmt = $mysqli->prepare("SELECT appoint_id, start_time, end_time, availability, patient_ic FROM appointment WHERE date = ?");
    $stmt->bind_param("s", $selectedDate);

    // Execute the query
    if ($stmt->execute()) {
        // Get the result
        $result = $stmt->get_result();

        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch data and format it
            $data_arr = array();
            while ($data_row = $result->fetch_assoc()) {
                $data_arr[] = array(
                    'id' => $data_row['appoint_id'],
                    'start' => $selectedDate . 'T' . $data_row['start_time'], // Combine date and start time
                    'end' => $selectedDate . 'T' . $data_row['end_time'], // Combine date and end time
                    'availability' => (int)$data_row['availability'], // Convert availability to integer
                    'patientIC' => $data_row['patient_ic'] // Patient IC
                );
            }

            // Prepare the success response
            $response = array(
                'status' => true,
                'msg' => 'Data fetched successfully!',
                'data' => $data_arr
            );
        } else {
            // Prepare the response if no rows were returned
            $response = array(
                'status' => false,
                'msg' => 'No appointments found for the selected date'
            );
        }
    } else {
        // Prepare the response if query execution failed
        $response = array(
            'status' => false,
            'msg' => 'Error executing query: ' . $mysqli->error
        );
    }

    // Close the statement
    $stmt->close();
} else {
    // If date is not provided in the POST request, return an error message
    $response = array(
        'status' => false,
        'msg' => 'Date not provided'
    );
}

// Encode response as JSON and output it
echo json_encode($response);

// Close the database connection
$mysqli->close();
?>

<?php
// Establish database connection
require('../Config.php');

session_start();


// Get the patient IC of the currently logged-in patient
$patient_ic = $_SESSION['patient_ic'];

// Check if all required fields are provided
if (isset($_POST['appointmentDate']) && isset($_POST['appointmentTime']) && isset($_POST['appointmentRemark'])) {
    // Sanitize input data to prevent SQL injection
    $appointmentDate = $mysqli->real_escape_string($_POST['appointmentDate']);
    $appointmentTime = $mysqli->real_escape_string($_POST['appointmentTime']);
    $appointmentRemark = $mysqli->real_escape_string($_POST['appointmentRemark']);

    // Construct the datetime for start and end time based on the selected date and time slot
    // Here, we assume that appointmentTime contains both start and end times in the format "start - end"
    // You may need to adjust this based on your actual data format
    $appointmentTimes = explode(' - ', $appointmentTime);
    $startTime = $appointmentTimes[0];
    $endTime = $appointmentTimes[1];

    // Update the appointment in the database with the correct patient IC
    $update_query = "UPDATE appointment SET patient_ic = '$patient_ic', remark = '$appointmentRemark' WHERE date = '$appointmentDate' AND start_time = '$startTime' AND end_time = '$endTime'";

    if ($mysqli->query($update_query) === TRUE) {
        // Appointment successfully updated
        // Now update the availability status of the appointment slot to booked
        $update_availability_query = "UPDATE appointment SET availability = 0 WHERE date = '$appointmentDate' AND start_time = '$startTime' AND end_time = '$endTime'";
        if ($mysqli->query($update_availability_query) === TRUE) {
            // Availability status updated successfully
            $response = array(
                'status' => true,
                'msg' => 'Appointment updated successfully!'
            );
        } else {
            // Error updating availability status
            $response = array(
                'status' => false,
                'msg' => 'Error updating availability status: ' . $mysqli->error
            );
        }

        // Fetch the updated appointment from the database to send back the updated status
        $updatedAppointmentQuery = "SELECT * FROM appointment WHERE date = '$appointmentDate' AND start_time = '$startTime' AND end_time = '$endTime'";
        $result = $mysqli->query($updatedAppointmentQuery);
        $updatedAppointment = $result->fetch_assoc();

        // Encode the updated appointment data along with the response
        $response['updatedAppointment'] = $updatedAppointment;
    } else {
        // Error updating appointment
        $response = array(
            'status' => false,
            'msg' => 'Error updating appointment: ' . $mysqli->error
        );
    }
} else {
    // Required fields not provided
    $response = array(
        'status' => false,
        'msg' => 'Please fill in all fields (date, time slot, and remark) before saving.'
    );
}

// Encode response as JSON and output it
echo json_encode($response);

// Close the database connection
$mysqli->close();
?>
